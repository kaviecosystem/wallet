const NETS={
  56:{name:'BNB Chain',hex:'0x38',sym:'BNB',rpcs:['https://bsc-dataseed.bnbchain.org','https://bsc-rpc.publicnode.com','https://bsc-dataseed1.defibit.io','https://bsc-dataseed1.ninicoin.io'],explorer:'https://bscscan.com',wbnb:'0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',mids:['0x55d398326f99059fF775485246999027B3197955','0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d','0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'],usd:'0x55d398326f99059fF775485246999027B3197955',hub:'0x57C2360E30705B6D9475300cF77266322660C4ca'},
  97:{name:'BNB Testnet',hex:'0x61',sym:'tBNB',rpcs:['https://data-seed-prebsc-1-s1.bnbchain.org:8545','https://bsc-testnet-rpc.publicnode.com'],explorer:'https://testnet.bscscan.com',wbnb:'0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',mids:[],usd:'',hub:''}
};

const ERRS=['error ZeroAddress()','error NoLiquidity()','error FeeTooHigh(uint256,uint256)','error RoundNotOver()','error NothingToClaim()','error ReentrantCall()','error TokenCallFailed(address)'];
const HUB_ABI=['function quoteFee() view returns (uint256)','function payFee(uint256) returns (uint256)','function roundInfo() view returns (uint256,uint256,address,uint256,bool)','function settleRound()','function claim()','function unclaimed(address) view returns (uint256)','function kavi() view returns (address)','function pair() view returns (address)','function router() view returns (address)',...ERRS];
const ERC20_ABI=['function symbol() view returns (string)','function name() view returns (string)','function decimals() view returns (uint8)','function balanceOf(address) view returns (uint256)','function allowance(address,address) view returns (uint256)','function approve(address,uint256) returns (bool)','function transfer(address,uint256) returns (bool)','function transferFrom(address,address,uint256) returns (bool)'];
const ROUTER_ABI=['function getAmountsOut(uint256,address[]) view returns (uint256[])','function swapExactETHForTokensSupportingFeeOnTransferTokens(uint256,address[],address,uint256) payable','function swapExactTokensForETHSupportingFeeOnTransferTokens(uint256,uint256,address[],address,uint256)','function swapExactTokensForTokensSupportingFeeOnTransferTokens(uint256,uint256,address[],address,uint256)'];
const IF_ERC20=new ethers.Interface(ERC20_ABI),IF_HUB=new ethers.Interface(HUB_ABI),IF_ROUTER=new ethers.Interface(ROUTER_ABI);
const FRIENDLY={NoLiquidity:'No KAVI liquidity on PancakeSwap',FeeTooHigh:'KAVI price moved too much. Try again',RoundNotOver:'Round is still running',NothingToClaim:'Nothing to claim',TokenCallFailed:'Token transfer failed',ZeroAddress:'Invalid address'};
const NATIVE=window.KaviNative||null;
const LOCK_AFTER=5*60*1000;

const store={get(k){try{return localStorage.getItem(k)}catch{return null}},set(k,v){try{localStorage.setItem(k,v)}catch{}},del(k){try{localStorage.removeItem(k)}catch{}}};
const S={chain:Number(store.get('kw_chain')||56),meta:{},tokens:[],bnb:0n,kaviBal:0n,fee:0n,round:null,unclaimed:0n,prices:{},priceAt:0,queue:[],busy:false,cat:'All'};
const $=id=>document.getElementById(id);
const net=()=>NETS[S.chain];
const hubAddr=()=>store.get('kw_hub3_'+S.chain)||net().hub;
const short=a=>a?a.slice(0,6)+'…'+a.slice(-4):'';
const eq=(a,b)=>!!a&&!!b&&a.toLowerCase()===b.toLowerCase();
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hostOf=u=>{try{return new URL(u).host}catch{return u||''}};

function fmt(v,dec=18){
  const s=ethers.formatUnits(v,dec);let[i,f='']=s.split('.');
  const max=i==='0'?8:i.length>4?2:4;
  f=f.slice(0,max).replace(/0+$/,'');
  i=i.replace(/\B(?=(\d{3})+(?!\d))/g,',');
  return f?i+'.'+f:i;
}
function kaviMeta(){return S.meta[(S.kavi||'').toLowerCase()]||{symbol:'KAVI',decimals:18}}
function usdFmt(x){
  if(x===null||x===undefined||!isFinite(x))return '';
  if(x===0)return '$0.00';
  if(x<0.01)return '$'+x.toPrecision(2);
  return '$'+x.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
}
const priceKey=a=>(a||'bnb').toLowerCase();
function usdNum(v,dec,addr){
  let p=S.prices[priceKey(addr)];
  if((p===undefined||p===null)&&eq(addr,S.kavi)&&S.fee)p=0.001/Number(ethers.formatUnits(S.fee,dec));
  if(p===undefined||p===null)return null;
  return Number(ethers.formatUnits(v,dec))*p;
}
const usdOf=(v,dec,addr)=>usdFmt(usdNum(v,dec,addr));
const usdOfKavi=v=>v?usdOf(v,kaviMeta().decimals,S.kavi):'';

let toastT;
function toast(msg,type=''){const t=$('toast');t.textContent=msg;t.className='on '+type;clearTimeout(toastT);toastT=setTimeout(()=>t.className=type,type==='err'?5000:3200)}
function show(id){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id===id));const main=id==='s-main';$('accChip').hidden=!main;$('netChip').hidden=!main}

function makeProvider(){
  const custom=store.get('kw_rpc_'+S.chain);
  const list=custom?[custom]:net().rpcs;
  S.rpcIdx=(S.rpcIdx||0)%list.length;
  S.rp=new ethers.JsonRpcProvider(list[S.rpcIdx],S.chain,{staticNetwork:ethers.Network.from(S.chain),batchMaxCount:1});
  if(S.wallet)S.signer=S.wallet.connect(S.rp);
}
function rotateRpc(){S.rpcIdx=(S.rpcIdx||0)+1;makeProvider();initContracts()}

function hasWallet(){return !!store.get('kw_keystore')}
function savedAddress(){return store.get('kw_address')||''}

async function encryptAndSave(w,pw){
  const btn=S.clicked;
  const json=await w.encrypt(pw,p=>{if(btn&&btn.classList.contains('btn'))btn.innerHTML=`<span class="spin"></span>Securing wallet ${Math.round(p*100)}%`});
  store.set('kw_keystore',json);store.set('kw_address',w.address);
}

async function startSession(w){
  S.wallet=w;S.address=w.address;S.lastActive=Date.now();
  makeProvider();
  S.signer=w.connect(S.rp);
  $('accChip').textContent=short(S.address);$('netName').textContent=net().name;
  await route();
}

function lock(){
  S.wallet=null;S.signer=null;clearInterval(S.poll);
  if(NATIVE)try{NATIVE.closeDapp()}catch{}
  $('browser').classList.remove('on');closeSheet();
  $('unlockAddr').textContent=short(savedAddress());$('unlockPw').value='';
  show('s-unlock');
}

function initContracts(){
  if(!S.hubAddr)return;
  S.hub=new ethers.Contract(S.hubAddr,HUB_ABI,S.rp);
  if(S.routerAddr)S.router=new ethers.Contract(S.routerAddr,ROUTER_ABI,S.rp);
}

async function route(){
  const h=hubAddr();
  $('wAddr').textContent=short(S.address);
  $('scanLink').href=net().explorer+'/address/'+S.address;
  show('s-main');
  if(!h||!ethers.isAddress(h)){toast('KaviHub address is not set for this network. Open Settings.','err');return}
  S.hubAddr=h;initContracts();
  for(let attempt=0;attempt<3;attempt++){
    try{
      S.kavi=await S.hub.kavi();
      const [pr,rt]=await Promise.all([S.hub.pair(),S.hub.router()]);
      S.routerAddr=rt;initContracts();
      try{
        const pc=new ethers.Contract(pr,['function token0() view returns (address)','function token1() view returns (address)'],S.rp);
        const [t0,t1]=await Promise.all([pc.token0(),pc.token1()]);
        S.kaviQuote=eq(t0,S.kavi)?t1:t0;
      }catch{}
      break;
    }catch(e){if(attempt===2){toast('Network problem: '+errMsg(e),'err');return}rotateRpc()}
  }
  await refresh();
  clearInterval(S.poll);S.poll=setInterval(refresh,15000);
  renderActivity();
}

function tokKey(){return 'kw_tokens_'+S.chain+'_'+S.address}
function tokenList(){
  let l=null;try{l=JSON.parse(store.get(tokKey())||'null')}catch{}
  if(!Array.isArray(l)){l=[];if(S.kaviQuote)l.push(S.kaviQuote)}
  return [S.kavi,...l.filter(a=>!eq(a,S.kavi))];
}
function saveTokens(l){store.set(tokKey(),JSON.stringify(l.filter(a=>!eq(a,S.kavi))))}

async function meta(addr){
  const k=addr.toLowerCase();
  if(S.meta[k])return S.meta[k];
  const c=new ethers.Contract(addr,ERC20_ABI,S.rp);
  const [symbol,name,decimals]=await Promise.all([c.symbol().catch(()=>'???'),c.name().catch(()=>'Unknown token'),c.decimals().catch(()=>18n)]);
  return S.meta[k]={symbol,name,decimals:Number(decimals)};
}

async function refresh(){
  if(!S.hub||!S.address||!S.kavi)return;
  try{
    const list=tokenList();
    const [bnb,fee,round,unc,bals]=await Promise.all([
      S.rp.getBalance(S.address),
      S.hub.quoteFee().catch(()=>0n),
      S.hub.roundInfo(),
      S.hub.unclaimed(S.address).catch(()=>0n),
      Promise.all(list.map(a=>new ethers.Contract(a,ERC20_ABI,S.rp).balanceOf(S.address).catch(()=>0n)))
    ]);
    S.bnb=bnb;S.fee=fee;S.unclaimed=unc;S.rpcFails=0;
    S.tokens=await Promise.all(list.map(async(a,i)=>({addr:a,bal:bals[i],...(await meta(a))})));
    S.kaviBal=S.tokens[0]?.bal||0n;
    S.round={no:round[0],pot:round[1],lead:round[2],end:Number(round[3]),settle:round[4]};
    render();
    const missing=S.tokens.some(t=>!(priceKey(t.addr) in S.prices));
    if(missing||Date.now()-S.priceAt>60000){await loadPrices();render()}
  }catch(e){console.error(e);S.rpcFails=(S.rpcFails||0)+1;if(S.rpcFails>=2){S.rpcFails=0;rotateRpc()}}
}

async function priceOf(addr,dec){
  const U=net().usd||S.kaviQuote;
  if(!U||!S.router)return null;
  const a=addr||net().wbnb;
  if(eq(a,U))return 1;
  const ud=(await meta(U)).decimals;
  const amt=10n**BigInt(dec);
  const paths=buildPaths(a,U);
  const outs=await Promise.all(paths.map(p=>S.router.getAmountsOut(amt,p).then(o=>o[o.length-1]).catch(()=>null)));
  let best=null;for(const o of outs)if(o!==null&&(best===null||o>best))best=o;
  return best===null?null:Number(ethers.formatUnits(best,ud));
}
async function loadPrices(){
  const items=[{addr:'',decimals:18},...S.tokens];
  const ps=await Promise.all(items.map(t=>priceOf(t.addr,t.decimals).catch(()=>null)));
  items.forEach((t,i)=>{S.prices[priceKey(t.addr)]=ps[i]});
  S.priceAt=Date.now();
}

const COLORS=['#f0b90b','#2ebd85','#3b82f6','#a855f7','#ef4444','#14b8a6','#f97316','#ec4899'];
function icon(sym,addr){
  if(!addr)return `<div class="ic" style="background:#f0b90b;color:#1a1400">B</div>`;
  const c=COLORS[parseInt(addr.slice(2,6),16)%COLORS.length];
  return `<div class="ic" style="background:${c}22;color:${c}">${esc(sym.slice(0,1).toUpperCase())}</div>`;
}

function render(){
  const km=kaviMeta();
  const all=[{addr:'',bal:S.bnb,decimals:18},...S.tokens];
  let total=0,known=0;
  for(const t of all){const u=usdNum(t.bal,t.decimals,t.addr);if(u!==null){total+=u;known++}}
  $('bnbBal').innerHTML=known?usdFmt(total).replace(/^\$/,'<small style="font-size:22px;color:var(--text)">$</small>'):`${fmt(S.bnb)} <small>${net().sym}</small>`;
  $('kaviLine').textContent=`${fmt(S.bnb)} ${net().sym} · ${fmt(S.kaviBal,km.decimals)} ${km.symbol}${S.tokens.length>1?` · +${S.tokens.length-1} more`:''}`;
  $('feeK').textContent=S.fee?`${fmt(S.fee,km.decimals)} ${km.symbol}`:'Unavailable';
  let h=`<button class="row" data-act="token" data-addr=""><div>${icon('B')}</div><div class="n"><b>${net().sym}</b><span>BNB Chain</span></div><div class="v"><b>${fmt(S.bnb)}</b><span>${usdOf(S.bnb,18,'')}</span></div></button>`;
  for(const t of S.tokens){
    h+=`<button class="row" data-act="token" data-addr="${t.addr}">${icon(t.symbol,t.addr)}<div class="n"><b>${esc(t.symbol)}</b><span>${esc(t.name)}</span></div><div class="v"><b>${fmt(t.bal,t.decimals)}</b><span>${usdOf(t.bal,t.decimals,t.addr)}</span></div></button>`;
  }
  $('tokList').innerHTML=h;
  const r=S.round;
  $('rNo').textContent=r.no.toString();
  $('rPot').textContent=`${fmt(r.pot,km.decimals)} ${km.symbol} ${r.pot?'· '+usdOfKavi(r.pot):''}`;
  $('rWin').textContent=`${fmt(r.pot/2n,km.decimals)} ${km.symbol}`;
  const none=r.lead===ethers.ZeroAddress;
  const me=eq(r.lead,S.address);
  $('rLead').innerHTML=none?'—':`${short(r.lead)}${me?'<span class="badge">You</span>':''}`;
  $('jpPot').textContent=`Jackpot ${fmt(r.pot,km.decimals)} ${km.symbol}`;
  $('claimBtn').hidden=!S.unclaimed;
  $('claimBtn').textContent=`Claim ${fmt(S.unclaimed,km.decimals)} ${km.symbol} prize`;
  tick();
}

function tick(){
  const r=S.round;if(!r)return;
  const none=r.lead===ethers.ZeroAddress;
  const left=Math.max(0,r.end-Math.floor(Date.now()/1000));
  const over=!none&&left===0;
  const pd=n=>String(n).padStart(2,'0'),hh=Math.floor(left/3600);
  const t=none?'--:--':hh?`${hh}:${pd(Math.floor(left%3600/60))}:${pd(left%60)}`:`${pd(Math.floor(left/60))}:${pd(left%60)}`;
  $('jpT').textContent=over?'00:00':t;$('jpBig').textContent=over?'00:00':t;
  const me=eq(r.lead,S.address);
  $('jpLead').textContent=none?'Waiting for first transaction':over?(me?'You won! Settle to receive it':'Round over. Settle to pay winner'):me?'You are leading 🏆':`Leader ${short(r.lead)}`;
  $('settleBtn').hidden=!over;
}
setInterval(tick,1000);

function assets(){return [{addr:'',symbol:net().sym,name:'BNB Chain',decimals:18,bal:S.bnb},...S.tokens]}
function assetOpts(sel,includeCustom){
  return assets().map(a=>`<option value="${a.addr}" ${eq(a.addr,sel)||(!a.addr&&!sel)?'selected':''}>${esc(a.symbol)} · ${fmt(a.bal,a.decimals)}</option>`).join('')+(includeCustom?'<option value="custom">Other token (address)…</option>':'');
}
const findAsset=a=>assets().find(x=>eq(x.addr,a)||(!a&&!x.addr));
function feeNote(){
  const km=kaviMeta();
  if(!S.fee)return '<div class="note">KAVI fee is unavailable right now (no pool liquidity), so no fee will be charged. You only pay network gas.</div>';
  const low=S.kaviBal<S.fee;
  return `<div class="note">Network gas in BNB + <b>${fmt(S.fee,km.decimals)} ${km.symbol}</b> fee (≈ $0.001), paid automatically with this transaction.${low?'<br><span class="warn">Not enough KAVI for the fee. Swap some BNB to KAVI first.</span>':''}</div>`;
}

function sheet(title,html,mount){
  S.sheetId=(S.sheetId||0)+1;
  $('sheet').innerHTML=`<div class="grab"></div><div class="sh"><h2>${title}</h2><button class="x" data-act="close"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>${html}`;
  $('bd').classList.add('on');
  mount&&mount();
}
function sheetOpen(){return $('bd').classList.contains('on')}
function closeSheet(){const f=S.sheetClose;S.sheetClose=null;$('bd').classList.remove('on');if(f)f()}
function closeSheetIf(id){if(S.sheetId===id)closeSheet()}
$('bd').addEventListener('click',e=>{if(e.target.id==='bd')closeSheet()});

function errMsg(e){
  if(e?.code==='ACTION_REJECTED'||e?.code===4001)return 'Request rejected';
  let n=e?.revert?.name;
  const data=e?.data||e?.info?.error?.data;
  if(!n&&data){try{n=IF_HUB.parseError(data)?.name}catch{}}
  if(n)return FRIENDLY[n]||n;
  if(e?.code==='INSUFFICIENT_FUNDS')return `Not enough ${net().sym} for network gas`;
  if(e?.code==='CALL_EXCEPTION')return e.reason?('Transaction would fail: '+e.reason):'Transaction would fail';
  return e?.shortMessage||e?.reason||e?.message||'Something went wrong';
}

async function feeCalls(){
  S.fee=await S.hub.quoteFee().catch(()=>0n);
  if(!S.fee)return [];
  const hub=S.hubAddr,maxFee=S.fee*3n/2n;
  const calls=[];
  const allowance=await new ethers.Contract(S.kavi,ERC20_ABI,S.rp).allowance(S.address,hub).catch(()=>0n);
  if(allowance<maxFee)calls.push({to:S.kavi,data:IF_ERC20.encodeFunctionData('approve',[hub,ethers.MaxUint256]),label:'Allow KAVI fee (one time)'});
  calls.push({to:hub,data:IF_HUB.encodeFunctionData('payFee',[maxFee]),label:'KAVI fee',gas:450000n});
  return calls;
}

async function sendCalls(calls,{earlyLast=false}={}){
  let last=null;
  let nonce=await S.rp.send('eth_getTransactionCount',[S.address,'pending']).then(n=>Number(n));
  for(let i=0;i<calls.length;i++){
    const c=calls[i],isLast=i===calls.length-1;
    if(calls.length>1)toast(`Sending ${i+1} of ${calls.length}: ${c.label}`);
    const req={to:c.to,value:c.value||0n,data:c.data||'0x',nonce:nonce++,from:S.address};
    if(c.gas)req.gasLimit=c.gas;
    else{const est=await S.signer.estimateGas(req);req.gasLimit=est*13n/10n+10000n}
    const tx=await S.signer.sendTransaction(req);
    if(isLast&&earlyLast)return {hash:tx.hash,wait:()=>tx.wait().then(rc=>({hash:tx.hash,ok:rc.status===1}))};
    const rc=await tx.wait();
    last={hash:tx.hash,ok:rc.status===1};
    if(!last.ok)return last;
  }
  return last;
}

async function txFlow(actions,{feeAfter=false,noFee=false,earlyLast=false}={}){
  const fees=noFee?[]:await feeCalls();
  if(fees.length&&!feeAfter&&S.kaviBal<S.fee)throw new Error('Not enough KAVI for the fee. Swap some BNB to KAVI first.');
  const calls=feeAfter?[...actions,...fees]:[...fees,...actions];
  return await sendCalls(calls,{earlyLast:earlyLast&&!feeAfter});
}

async function run(label,actions,opts={}){
  const btn=S.clicked?.classList?.contains('btn')?S.clicked:null;
  const old=btn?.innerHTML,sid=S.sheetId;
  try{
    if(btn){btn.disabled=true;btn.innerHTML='<span class="spin"></span>Sending'}
    const res=await txFlow(actions,opts);
    if(res?.hash)addActivity({label,hash:res.hash,ts:Date.now(),status:res.ok?'success':'failed'});
    closeSheetIf(sid);
    toast(res?.ok?label+' confirmed':label+' failed',res?.ok?'ok':'err');
    refresh();
    return res;
  }catch(e){toast(errMsg(e),'err')}
  finally{if(btn){btn.disabled=false;btn.innerHTML=old}}
}

function actKey(){return 'kw_act_'+S.chain+'_'+S.address}
function getAct(){try{return JSON.parse(store.get(actKey())||'[]')}catch{return[]}}
function addActivity(a){const l=getAct();l.unshift(a);store.set(actKey(),JSON.stringify(l.slice(0,50)));renderActivity()}
function setActivity(h,st){const l=getAct();const x=l.find(a=>a.hash===h);if(x)x.status=st;store.set(actKey(),JSON.stringify(l));renderActivity()}
function renderActivity(){
  const l=getAct();
  $('actList').innerHTML=l.length?l.map(a=>`<a class="row" href="${net().explorer}/tx/${a.hash}" target="_blank" rel="noopener"><div class="ic" style="background:var(--card2);color:var(--mut)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 17 17 7M8 7h9v9"/></svg></div><div class="n"><b style="color:var(--text)">${esc(a.label)}</b><span>${new Date(a.ts).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</span></div><span class="st ${a.status}">${a.status}</span></a>`).join(''):'<div class="empty">No transactions yet</div>';
}

function openSend(pre){
  sheet('Send',`
    <div class="f"><label>Asset</label><div class="inp"><select id="sA">${assetOpts(pre)}</select></div></div>
    <div class="f"><label>Recipient</label><div class="inp"><input id="sTo" placeholder="0x…" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div>
    <div class="f"><label><span>Amount</span><span id="sAv"></span></label><div class="inp"><input id="sAmt" inputmode="decimal" placeholder="0.0"><button class="max" data-act="sMax">MAX</button></div></div>
    ${feeNote()}
    <button class="btn" data-act="doSend">Send</button>`,()=>{$('sA').onchange=sAv;sAv()});
}
function sAv(){const a=findAsset($('sA').value);$('sAv').textContent='Available '+fmt(a.bal,a.decimals)+' '+a.symbol}
function spendable(a){
  let v=a.bal;
  if(eq(a.addr,S.kavi))v=v>S.fee?v-S.fee:0n;
  if(!a.addr){const gas=ethers.parseEther('0.002');v=v>gas?v-gas:0n}
  return v;
}
function sMax(){const a=findAsset($('sA').value);$('sAmt').value=ethers.formatUnits(spendable(a),a.decimals)}
async function doSend(){
  const a=findAsset($('sA').value),to=$('sTo').value.trim();
  if(!ethers.isAddress(to))return toast('Enter a valid recipient address','err');
  let amt;try{amt=ethers.parseUnits($('sAmt').value.trim()||'0',a.decimals)}catch{return toast('Invalid amount','err')}
  if(amt<=0n)return toast('Enter an amount','err');
  if(amt>a.bal||(eq(a.addr,S.kavi)&&amt+S.fee>a.bal))return toast('Insufficient balance','err');
  const action=a.addr?{to:a.addr,data:IF_ERC20.encodeFunctionData('transfer',[to,amt]),label:`Send ${a.symbol}`}:{to,value:amt,label:`Send ${a.symbol}`};
  await run(`Send ${$('sAmt').value} ${a.symbol}`,[action]);
}

function openReceive(){
  const qr=qrcode(0,'M');qr.addData(S.address);qr.make();
  sheet('Receive',`
    <div class="qr">${qr.createSvgTag({cellSize:5,margin:1,scalable:true})}</div>
    <div class="mono">${S.address}</div>
    <button class="btn ghost sm" data-act="copy">Copy address</button>
    <div class="gap"></div>
    <div class="note">Only send BNB Chain (BEP-20) assets to this address.</div>`);
}

let swapSlip=1,quoteT,lastQuote=null;
function openSwap(){
  const k=S.tokens.find(t=>eq(t.addr,S.kavi));
  sheet('Swap',`
    <div class="f"><label><span>From</span><span id="wAv"></span></label><div class="inp"><select id="wF">${assetOpts('')}</select></div>
    <div class="inp" style="margin-top:6px"><input id="wAmt" inputmode="decimal" placeholder="0.0"><button class="max" data-act="wMax">MAX</button></div></div>
    <div class="flip"><button data-act="wFlip"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M7 4v16M3 16l4 4 4-4M17 20V4M13 8l4-4 4 4"/></svg></button></div>
    <div class="f"><label>To</label><div class="inp"><select id="wT">${assetOpts(k?k.addr:'',true)}</select></div>
    <div class="inp" id="wCW" style="margin-top:6px;display:none"><input id="wC" placeholder="Token address 0x…" autocomplete="off"></div></div>
    <div class="card" style="margin:0 0 12px"><div class="kv"><span>You receive</span><b id="wOut">—</b></div><div class="kv"><span>Minimum received</span><b id="wMin">—</b></div>
    <div class="kv"><span>Slippage</span><div class="chips">${[0.5,1,3,10].map(s=>`<button data-act="slip" data-v="${s}" class="${s===swapSlip?'on':''}">${s}%</button>`).join('')}</div></div></div>
    ${feeNote()}
    <button class="btn" data-act="doSwap">Swap</button>`,()=>{
      ['wF','wT'].forEach(i=>$(i).onchange=()=>{$('wCW').style.display=$('wT').value==='custom'?'flex':'none';wAv();quoteSoon()});
      $('wAmt').oninput=quoteSoon;$('wC').oninput=quoteSoon;wAv();
    });
}
function wAv(){const a=findAsset($('wF').value);$('wAv').textContent='Balance '+fmt(a.bal,a.decimals)}
function wMax(){const a=findAsset($('wF').value);$('wAmt').value=ethers.formatUnits(spendable(a),a.decimals);quoteSoon()}
function wFlip(){const f=$('wF').value,t=$('wT').value;if(t==='custom')return;$('wF').value=t;$('wT').value=f;wAv();quoteSoon()}
function quoteSoon(){clearTimeout(quoteT);quoteT=setTimeout(quote,350)}
async function swapSides(){
  const W=net().wbnb,f=findAsset($('wF').value);
  let toAddr=$('wT').value,toMeta;
  if(toAddr==='custom'){toAddr=$('wC').value.trim();if(!ethers.isAddress(toAddr))return null;toMeta={addr:toAddr,...(await meta(toAddr))}}
  else toMeta=findAsset(toAddr);
  return{f,fromT:f.addr||W,toT:toAddr||W,toMeta,fromBNB:!f.addr,toBNB:!toAddr};
}
function buildPaths(a,b){
  const W=net().wbnb;
  const mids=[W,S.kaviQuote,...(net().mids||[])].filter((x,i,arr)=>x&&arr.findIndex(y=>eq(x,y))===i);
  const out=[[a,b]];
  for(const m of mids)if(!eq(m,a)&&!eq(m,b))out.push([a,m,b]);
  for(const m1 of mids)for(const m2 of mids){
    if(eq(m1,m2)||eq(m1,a)||eq(m1,b)||eq(m2,a)||eq(m2,b))continue;
    if(eq(m1,W)||eq(m2,W))out.push([a,m1,m2,b]);
  }
  return out;
}
async function quote(){
  lastQuote=null;$('wOut').textContent='—';$('wMin').textContent='—';
  try{
    const s=await swapSides();if(!s)return;
    if(eq(s.fromT,s.toT))return;
    const amt=ethers.parseUnits($('wAmt').value.trim()||'0',s.f.decimals);if(amt<=0n)return;
    $('wOut').innerHTML='<span class="spin" style="display:inline-block"></span>';
    const paths=buildPaths(s.fromT,s.toT);
    const outs=await Promise.all(paths.map(p=>S.router.getAmountsOut(amt,p).then(o=>o[o.length-1]).catch(()=>null)));
    let best=null;
    outs.forEach((out,i)=>{if(out!==null&&(!best||out>best.out))best={path:paths[i],out}});
    if(!best){$('wOut').textContent='No route';return}
    const min=best.out*BigInt(Math.round((100-swapSlip)*100))/10000n;
    lastQuote={...s,amt,path:best.path,min};
    $('wOut').textContent=`${fmt(best.out,s.toMeta.decimals)} ${s.toMeta.symbol}`;
    $('wMin').textContent=`${fmt(min,s.toMeta.decimals)} ${s.toMeta.symbol}`;
  }catch{$('wOut').textContent='—'}
}
async function doSwap(){
  await quote();
  const q=lastQuote;if(!q)return toast('Enter an amount and pick a valid pair','err');
  if(q.amt>q.f.bal)return toast('Insufficient balance','err');
  const fromK=eq(q.f.addr,S.kavi),toK=eq(q.toT,S.kavi);
  if(fromK&&q.amt+S.fee>q.f.bal)return toast('Leave some KAVI for the fee','err');
  const dl=Math.floor(Date.now()/1000)+1200,R=S.routerAddr;
  const actions=[];
  if(q.fromBNB){
    actions.push({to:R,value:q.amt,data:IF_ROUTER.encodeFunctionData('swapExactETHForTokensSupportingFeeOnTransferTokens',[q.min,q.path,S.address,dl]),label:'Swap'});
  }else{
    const al=await new ethers.Contract(q.f.addr,ERC20_ABI,S.rp).allowance(S.address,R).catch(()=>0n);
    if(al<q.amt)actions.push({to:q.f.addr,data:IF_ERC20.encodeFunctionData('approve',[R,q.amt]),label:`Allow ${q.f.symbol} swap`});
    const fn=q.toBNB?'swapExactTokensForETHSupportingFeeOnTransferTokens':'swapExactTokensForTokensSupportingFeeOnTransferTokens';
    actions.push({to:R,data:IF_ROUTER.encodeFunctionData(fn,[q.amt,q.min,q.path,S.address,dl]),label:'Swap'});
  }
  const feeAfter=toK&&S.kaviBal<S.fee;
  const res=await run(`Swap ${$('wAmt').value} ${q.f.symbol} → ${q.toMeta.symbol}`,actions,{feeAfter});
  if(res?.ok&&!q.toBNB){const l=tokenList();if(!l.some(a=>eq(a,q.toT))){l.push(ethers.getAddress(q.toT));saveTokens(l);refresh()}}
}

function openAddToken(){
  sheet('Add token',`
    <div class="f"><label>Token contract address</label><div class="inp"><input id="aT" placeholder="0x…" autocomplete="off" autocapitalize="off"></div></div>
    <div class="card" id="aInfo" style="display:none;margin:0 0 12px"></div>
    <div class="note">Adding a token only shows it in your list. It's free and needs no transaction.</div>
    <button class="btn" data-act="doAdd">Add token</button>`,()=>{
      $('aT').oninput=async()=>{
        const a=$('aT').value.trim(),box=$('aInfo');
        if(!ethers.isAddress(a)){box.style.display='none';return}
        box.style.display='block';box.innerHTML='<div class="kv"><span>Looking up…</span></div>';
        const m=await meta(a);
        box.innerHTML=`<div class="kv"><span>Symbol</span><b>${esc(m.symbol)}</b></div><div class="kv"><span>Name</span><b>${esc(m.name)}</b></div><div class="kv"><span>Decimals</span><b>${m.decimals}</b></div>`;
      };
    });
}
async function addTokenAddr(a){
  const l=tokenList();
  if(l.some(t=>eq(t,a)))return false;
  await meta(a);
  l.push(ethers.getAddress(a));saveTokens(l);refresh();return true;
}
async function doAdd(){
  const a=$('aT').value.trim();
  if(!ethers.isAddress(a))return toast('Enter a valid token address','err');
  if(!await addTokenAddr(a))return toast('Token already added','err');
  closeSheet();toast(`${S.meta[a.toLowerCase()].symbol} added`,'ok');
}

function openToken(addr){
  const a=findAsset(addr);
  const isK=eq(addr,S.kavi);
  sheet(esc(a.symbol),`
    <div style="text-align:center;margin-bottom:14px"><div style="display:flex;justify-content:center;margin:6px 0 14px;transform:scale(1.4)">${icon(a.symbol,a.addr)}</div>
    <div class="amt" style="margin:0">${fmt(a.bal,a.decimals)} <small>${esc(a.symbol)}</small></div><div class="sub">${usdOf(a.bal,a.decimals,a.addr)}</div></div>
    ${a.addr?`<div class="card" style="margin:0 0 12px"><div class="kv"><span>Name</span><b>${esc(a.name)}</b></div><div class="kv"><span>Contract</span><b><a href="${net().explorer}/token/${a.addr}" target="_blank" rel="noopener">${short(a.addr)}</a></b></div><div class="kv"><span>Decimals</span><b>${a.decimals}</b></div></div>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <button class="btn sm" data-act="send" data-addr="${a.addr}">Send</button>
      <button class="btn sm ghost" data-act="receive">Receive</button>
    </div>
    ${a.addr&&!isK?`<div class="gap"></div><button class="btn sm danger" data-act="doRemove" data-addr="${a.addr}">Hide token</button>`:''}`);
}

function openSettings(){
  sheet('Settings',`
    <div class="card" style="margin:0 0 12px">
      <div class="kv"><span>Wallet</span><b><a href="${net().explorer}/address/${S.address}" target="_blank" rel="noopener">${short(S.address)}</a></b></div>
      <div class="kv"><span>Network</span><b>${net().name}</b></div>
    </div>
    <div class="f"><label>Network</label><div class="inp"><select id="stN">${Object.entries(NETS).map(([id,n])=>`<option value="${id}" ${+id===S.chain?'selected':''}>${n.name}</option>`).join('')}</select></div></div>
    <div class="f"><label>KaviHub address</label><div class="inp"><input id="stH" value="${esc(hubAddr()||'')}" placeholder="0x…" autocomplete="off"></div></div>
    <button class="btn" data-act="saveSettings">Save</button>
    <hr>
    <button class="btn ghost sm" data-act="showPhrase">Show recovery phrase</button>
    <div class="gap"></div>
    <button class="btn ghost sm" data-act="lockNow">Lock wallet</button>
    <div class="gap"></div>
    <button class="btn danger sm" data-act="resetAsk">Remove wallet from this phone</button>`);
}
function saveSettings(){
  const n=Number($('stN').value),h=$('stH').value.trim();
  if(h&&!ethers.isAddress(h))return toast('Invalid hub address','err');
  if(h&&!eq(h,net().hub))store.set('kw_hub3_'+n,h);
  const changed=n!==S.chain;
  store.set('kw_chain',n);
  closeSheet();
  if(changed)switchChain(n);else route();
}
function switchChain(n){
  S.chain=n;store.set('kw_chain',n);S.meta={};S.prices={};S.priceAt=0;S.tokens=[];S.kavi=null;S.kaviQuote=null;
  makeProvider();$('netName').textContent=net().name;
  dappEvent('chainChanged',net().hex);
  route();
}

function askPassword(title,note,cb){
  sheet(title,`
    ${note?`<div class="note">${note}</div>`:''}
    <div class="f"><label>Password</label><div class="inp"><input id="askPw" type="password" autocomplete="current-password"></div></div>
    <button class="btn" data-act="askPwGo">Continue</button>`,()=>{S.askCb=cb;setTimeout(()=>$('askPw').focus(),200)});
}
async function askPwGo(){
  const pw=$('askPw').value,btn=S.clicked,old=btn.innerHTML;
  btn.disabled=true;btn.innerHTML='<span class="spin"></span>Checking';
  try{
    const w=await ethers.Wallet.fromEncryptedJson(store.get('kw_keystore'),pw);
    const cb=S.askCb;S.askCb=null;cb(w);
  }catch{toast('Wrong password','err')}
  finally{btn.disabled=false;btn.innerHTML=old}
}

const ONB={};
function goCreate(){ONB.mode='create';$('pw1').value='';$('pw2').value='';show('s-password')}
function goImport(){$('impText').value='';$('impPw1').value='';$('impPw2').value='';show('s-import')}
function checkPw(a,b){
  if(a.length<8){toast('Password must be at least 8 characters','err');return false}
  if(a!==b){toast('Passwords do not match','err');return false}
  return true;
}
function pwNext(){
  const a=$('pw1').value,b=$('pw2').value;
  if(!checkPw(a,b))return;
  ONB.pw=a;ONB.wallet=ethers.Wallet.createRandom();
  const words=ONB.wallet.mnemonic.phrase.split(' ');
  $('words').innerHTML=words.map((w,i)=>`<div class="word"><i>${i+1}</i>${w}</div>`).join('');
  $('savedChk').checked=false;
  show('s-phrase');
}
function phraseNext(){
  if(!$('savedChk').checked)return toast('Please confirm you wrote down the phrase','err');
  const idx=[];while(idx.length<3){const r=Math.floor(Math.random()*12);if(!idx.includes(r))idx.push(r)}
  idx.sort((a,b)=>a-b);ONB.check=idx;
  $('verifyBox').innerHTML=idx.map(i=>`<div class="f"><label>Word #${i+1}</label><div class="inp"><input data-w="${i}" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div>`).join('');
  show('s-verify');
}
async function verifyDone(){
  const words=ONB.wallet.mnemonic.phrase.split(' ');
  const ok=[...document.querySelectorAll('#verifyBox input')].every(inp=>inp.value.trim().toLowerCase()===words[+inp.dataset.w]);
  if(!ok)return toast('Those words don\'t match. Check your phrase.','err');
  const btn=S.clicked;btn.disabled=true;
  try{await encryptAndSave(ONB.wallet,ONB.pw);const w=ONB.wallet;ONB.wallet=null;ONB.pw=null;await startSession(w);toast('Wallet created','ok')}
  catch(e){toast(errMsg(e),'err')}
  finally{btn.disabled=false;btn.innerHTML='Create wallet'}
}
async function doImport(){
  const txt=$('impText').value.trim().replace(/\s+/g,' '),a=$('impPw1').value,b=$('impPw2').value;
  let w;
  try{
    if(/^(0x)?[0-9a-fA-F]{64}$/.test(txt))w=new ethers.Wallet(txt.startsWith('0x')?txt:'0x'+txt);
    else w=ethers.Wallet.fromPhrase(txt.toLowerCase());
  }catch{return toast('That recovery phrase or private key is not valid','err')}
  if(!checkPw(a,b))return;
  const btn=S.clicked;btn.disabled=true;
  try{await encryptAndSave(w,a);await startSession(w);toast('Wallet imported','ok')}
  catch(e){toast(errMsg(e),'err')}
  finally{btn.disabled=false;btn.innerHTML='Import wallet'}
}
async function doUnlock(){
  const pw=$('unlockPw').value,btn=S.clicked;
  if(!pw)return;
  btn.disabled=true;btn.innerHTML='<span class="spin"></span>Unlocking';
  try{
    const w=await ethers.Wallet.fromEncryptedJson(store.get('kw_keystore'),pw,p=>{btn.innerHTML=`<span class="spin"></span>Unlocking ${Math.round(p*100)}%`});
    $('unlockPw').value='';
    await startSession(w);
  }catch{toast('Wrong password','err')}
  finally{btn.disabled=false;btn.innerHTML='Unlock'}
}
function resetAsk(){
  sheet('Remove wallet',`
    <div class="note"><span class="warn">This removes the wallet from this phone.</span> Your funds stay on the blockchain, but you can only get them back with your recovery phrase. Make sure you have it written down.</div>
    <div class="f"><label>Type REMOVE to confirm</label><div class="inp"><input id="rmTxt" autocomplete="off" autocapitalize="characters"></div></div>
    <button class="btn danger" data-act="resetGo">Remove wallet</button>`);
}
function resetGo(){
  if($('rmTxt').value.trim()!=='REMOVE')return toast('Type REMOVE to confirm','err');
  for(const k of Object.keys(localStorage))if(k.startsWith('kw_'))store.del(k);
  S.wallet=null;S.signer=null;S.address=null;clearInterval(S.poll);
  closeSheet();
  if(NATIVE)try{NATIVE.closeDapp()}catch{}
  $('browser').classList.remove('on');
  show('s-welcome');
}

const IMG='https://safe-transaction-assets.safe.global/safe_apps/';
const DAPPS=[
  {name:'PancakeSwap',url:'https://pancakeswap.finance',cat:'Exchange',desc:'Swap, farm and earn on BNB Chain',icon:IMG+'91/icon.png'},
  {name:'1inch',url:'https://1inch.com/swap',cat:'Exchange',desc:'Swap aggregator with the best rates',icon:IMG+'cd741cc7-a093-4c0a-8f4d-0be5f5256884/icon.png'},
  {name:'KyberSwap',url:'https://kyberswap.com/',cat:'Exchange',desc:'Fast, efficient trading and earning',icon:IMG+'40033adc-165c-4b89-bf70-b31384704ce8/icon.png'},
  {name:'Sushi',url:'https://www.sushi.com/',cat:'Exchange',desc:'Swap, earn, lend and borrow',icon:IMG+'35/icon.png'},
  {name:'CoW Swap',url:'https://swap.cow.fi',cat:'Exchange',desc:'Best prices with MEV protection',icon:IMG+'e0ecb7c3-93c1-4598-b9ee-c24d6a798b40/icon.png'},
  {name:'Venus',url:'https://app.venus.io/',cat:'Earn',desc:'Lend and borrow crypto',icon:IMG+'f586f39e-71ac-4772-b988-2bde27edfdeb/icon.png'},
  {name:'Pendle',url:'https://app.pendle.finance/',cat:'Earn',desc:'Trade and fix your yield',icon:IMG+'cbc8f430-40c3-4f19-9f1a-3e8200608ef6/icon.png'},
  {name:'Lagoon',url:'https://app.lagoon.finance/',cat:'Earn',desc:'Managed yield vaults',icon:IMG+'857018a3-758e-4ad1-8d48-dd5f1aac8ab8/icon.png'},
  {name:'Jumper',url:'https://jumper.xyz',cat:'Bridge',desc:'Bridge and swap across chains',icon:IMG+'155/icon.png'},
  {name:'Squid',url:'https://app.squidrouter.com',cat:'Bridge',desc:'Cross-chain swaps in one click',icon:IMG+'121/icon.png'},
  {name:'Rango',url:'https://app.rango.exchange/',cat:'Bridge',desc:'Cross-chain DEX and bridge aggregator',icon:IMG+'49be089d-fb24-4790-a033-dfcafd1964e3/icon.png'},
  {name:'Sablier',url:'https://app.sablier.com/',cat:'Payments',desc:'Token streaming, vesting and airdrops',icon:IMG+'141/icon.png'},
  {name:'Superfluid',url:'https://app.superfluid.org',cat:'Payments',desc:'Stream money every second',icon:IMG+'3ee85376-cff1-497a-a9d8-51c0e5234c6e/icon.png'},
  {name:'Revoke.cash',url:'https://revoke.cash/',cat:'Tools',desc:'Check and revoke token approvals',icon:IMG+'88/icon.png'},
  {name:'Snapshot',url:'https://snapshot.org',cat:'Tools',desc:'Vote on DAO proposals',icon:IMG+'61/icon.png'}
];
const CATS=['All','Exchange','Earn','Bridge','Payments','Tools'];

function dappByUrl(u){const h=hostOf(u);return DAPPS.find(d=>hostOf(d.url)===h)}
function dappIcon(d,size=36){
  const name=d.name||'?',c=COLORS[name.charCodeAt(0)%COLORS.length];
  const letter=`<div class="ic" style="width:${size}px;height:${size}px;border-radius:12px;background:${c}22;color:${c}">${esc(name.slice(0,1).toUpperCase())}</div>`;
  return d.icon?`<img class="dimg" style="width:${size}px;height:${size}px" src="${esc(d.icon)}" alt="" onerror="this.outerHTML=this.dataset.f" data-f='${letter.replace(/'/g,'&#39;')}'>`:letter;
}
function getRecent(){try{return JSON.parse(store.get('kw_recent')||'[]')}catch{return[]}}
function addRecent(u){const l=getRecent().filter(x=>hostOf(x)!==hostOf(u));l.unshift(u);store.set('kw_recent',JSON.stringify(l.slice(0,8)))}

function sitesKey(){return 'kw_sites_'+S.address}
function getSites(){try{return JSON.parse(store.get(sitesKey())||'{}')}catch{return{}}}
function isConnected(origin){return !!getSites()[origin]}
function setConnected(origin,on){const s=getSites();if(on)s[origin]=Date.now();else delete s[origin];store.set(sitesKey(),JSON.stringify(s))}

function openBrowser(){$('browser').classList.add('on');$('bq').value='';renderHome('')}
function bClose(){$('browser').classList.remove('on')}
function openUrl(u){
  addRecent(u);
  if(NATIVE){try{NATIVE.openDapp(u)}catch{toast('Could not open dApp','err')}}
  else window.open(u,'_blank','noopener');
}
function bGo(){
  const q=$('bq').value.trim();if(!q)return;
  let u=q;
  if(!/^https?:\/\//i.test(u)){
    if(/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/.test(u))u='https://'+u;
    else{const hit=DAPPS.find(d=>d.name.toLowerCase().includes(q.toLowerCase()));if(hit)return openUrl(hit.url);renderHome(q);return}
  }
  try{new URL(u)}catch{return toast('Invalid address','err')}
  $('bq').blur();
  openUrl(u);
}
function renderHome(q){
  q=(q||'').toLowerCase();
  $('catBar').innerHTML=CATS.map(c=>`<button class="${c===S.cat?'on':''}" data-act="cat" data-v="${c}">${c}</button>`).join('');
  const list=DAPPS.filter(d=>(S.cat==='All'||d.cat===S.cat)&&(!q||d.name.toLowerCase().includes(q)||d.url.toLowerCase().includes(q)||d.desc.toLowerCase().includes(q)||d.cat.toLowerCase().includes(q)));
  $('dList').innerHTML=list.length?list.map(d=>`<button class="row" data-act="openUrl" data-url="${esc(d.url)}">${dappIcon(d,40)}<div class="n"><b>${esc(d.name)}</b><span>${esc(d.desc)}</span></div><span class="st" style="background:var(--card2);color:var(--mut)">${d.cat}</span></button>`).join(''):`<div class="empty">No dApps found.<br>Type a full address like app.example.com and press Go.</div>`;
  const rec=getRecent().filter(u=>!q||u.toLowerCase().includes(q));
  $('recentH').hidden=!rec.length;
  $('recentList').innerHTML=rec.map(u=>{const d=dappByUrl(u)||{name:hostOf(u)};return `<button class="rc" data-act="openUrl" data-url="${esc(u)}">${dappIcon(d,44)}<span>${esc(d.name)}</span></button>`}).join('');
  const sites=Object.keys(getSites());
  $('sitesH').hidden=!sites.length;
  $('sitesList').innerHTML=sites.map(o=>`<div class="row">${dappIcon({name:hostOf(o)},32)}<div class="n"><b>${esc(hostOf(o))}</b><span>${esc(o)}</span></div><button class="chip" data-act="disconnectSite" data-o="${esc(o)}">Disconnect</button></div>`).join('');
}

function dappReply(nid,reqId,result){if(NATIVE)NATIVE.dappReply(nid,JSON.stringify({id:reqId,result:result===undefined?null:result}))}
function dappError(nid,reqId,code,message){if(NATIVE)NATIVE.dappReply(nid,JSON.stringify({id:reqId,error:{code,message}}))}
function dappEvent(event,data){if(NATIVE)try{NATIVE.dappEvent(JSON.stringify({event,data}))}catch{}}

const READ_OK=/^(eth_(blockNumber|call|estimateGas|gasPrice|maxPriorityFeePerGas|feeHistory|getBalance|getBlockBy(Hash|Number)|getBlockTransactionCountBy(Hash|Number)|getCode|getLogs|getProof|getStorageAt|getTransactionBy(Hash|BlockHashAndIndex|BlockNumberAndIndex)|getTransactionCount|getTransactionReceipt|getUncle.*|protocolVersion|syncing|blobBaseFee)|net_listening|web3_clientVersion|web3_sha3)$/;

async function onDappRequest(nid,raw,origin){
  let req;try{req=JSON.parse(raw)}catch{return}
  const id=req.id,m=req.method,p=Array.isArray(req.params)?req.params:(req.params?[req.params]:[]);
  const ok=r=>dappReply(nid,id,r),bad=(c,msg)=>dappError(nid,id,c,msg);
  if(!S.wallet)return bad(4100,'Kavi Wallet is locked');
  S.lastActive=Date.now();
  const conn=isConnected(origin);
  try{
    switch(m){
      case 'eth_chainId':return ok(net().hex);
      case 'net_version':return ok(String(S.chain));
      case 'eth_accounts':return ok(conn?[S.address]:[]);
      case 'eth_coinbase':return ok(conn?S.address:null);
      case 'eth_requestAccounts':
        if(conn)return ok([S.address]);
        return enqueue({type:'connect',nid,id,origin,after:'accounts'});
      case 'wallet_requestPermissions':
        if(conn)return ok([{parentCapability:'eth_accounts'}]);
        return enqueue({type:'connect',nid,id,origin,after:'perms'});
      case 'wallet_getPermissions':return ok(conn?[{parentCapability:'eth_accounts'}]:[]);
      case 'wallet_revokePermissions':setConnected(origin,false);return ok(null);
      case 'wallet_switchEthereumChain':
      case 'wallet_addEthereumChain':{
        const want=parseInt(p[0]?.chainId,16);
        if(want===S.chain)return ok(null);
        if(NETS[want]&&NETS[want].hub){switchChain(want);toast(`Switched to ${NETS[want].name}`);return ok(null)}
        return bad(4902,'Kavi Wallet supports BNB Chain only');
      }
      case 'wallet_watchAsset':{
        const a=p[0]?.options?.address||req.params?.options?.address;
        if(!a||!ethers.isAddress(a))return bad(-32602,'Invalid token address');
        const added=await addTokenAddr(a);if(added)toast(`${S.meta[a.toLowerCase()].symbol} added to your tokens`,'ok');
        return ok(true);
      }
      case 'eth_sendTransaction':
        if(!conn)return bad(4100,'Site is not connected');
        return enqueue({type:'tx',nid,id,origin,tx:p[0]||{}});
      case 'personal_sign':{
        if(!conn)return bad(4100,'Site is not connected');
        let msg=p[0],addr=p[1];
        if(ethers.isAddress(msg)&&!ethers.isAddress(addr)){const t=msg;msg=addr;addr=t}
        if(addr&&!eq(addr,S.address))return bad(4100,'Unknown account');
        return enqueue({type:'sign',nid,id,origin,msg});
      }
      case 'eth_signTypedData_v4':
      case 'eth_signTypedData_v3':{
        if(!conn)return bad(4100,'Site is not connected');
        if(p[0]&&!eq(p[0],S.address))return bad(4100,'Unknown account');
        const td=typeof p[1]==='string'?JSON.parse(p[1]):p[1];
        return enqueue({type:'typed',nid,id,origin,td});
      }
      case 'eth_sign':
      case 'eth_signTypedData':
        return bad(4200,'This signing method is not supported for security reasons');
      case 'eth_sendRawTransaction':
        return bad(4200,'Not supported');
      default:
        if(READ_OK.test(m))return ok(await S.rp.send(m,p));
        return bad(4200,`Method ${m} is not supported`);
    }
  }catch(e){bad(-32603,errMsg(e))}
}

function enqueue(r){S.queue.push(r);nextReq()}
function nextReq(){
  if(S.busy||!S.queue.length)return;
  S.busy=true;
  if(NATIVE)try{NATIVE.showWallet()}catch{}
  const r=S.queue.shift();S.cur=r;
  (r.type==='connect'?showConnect(r):r.type==='tx'?showTx(r):showSign(r)).catch(e=>{dappError(r.nid,r.id,-32603,errMsg(e));finishReq()});
}
function finishReq(){
  S.sheetClose=null;closeSheet();S.busy=false;S.cur=null;
  if(S.queue.length)return setTimeout(nextReq,250);
  if(NATIVE)try{NATIVE.showDapp()}catch{}
}
function siteHead(origin){
  const d=dappByUrl(origin)||{name:hostOf(origin)};
  return `<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">${dappIcon(d,44)}<div style="min-width:0"><b style="font-size:15px">${esc(d.name)}</b><div class="sub">${esc(origin)}</div></div></div>`;
}

async function showConnect(r){
  sheet('Connect to site',`
    ${siteHead(r.origin)}
    <div class="note">This site wants to connect to your wallet <b>${short(S.address)}</b>. It will see your address and balances, and can ask you to approve transactions. It can't move funds without your approval.</div>
    <div class="grid2"><button class="btn ghost" data-act="reqNo">Cancel</button><button class="btn" data-act="reqYes">Connect</button></div>`);
  S.sheetClose=reqNo;
}
async function describeCall(to,data){
  let d=null;try{d=IF_ERC20.parseTransaction({data})}catch{}
  if(!d||!['approve','transfer','transferFrom'].includes(d.name))return{title:data&&data!=='0x'?'Contract interaction':`Send ${net().sym}`,rows:''};
  const m=await meta(to).catch(()=>({symbol:'tokens',decimals:18}));
  const unl=v=>v>=2n**255n;
  const amt=v=>unl(v)?'Unlimited':`${fmt(v,m.decimals)} ${esc(m.symbol)}`;
  if(d.name==='approve')return{title:`Approve ${m.symbol} spending`,rows:`<div class="kv"><span>Spender</span><b>${short(d.args[0])}</b></div><div class="kv"><span>Amount</span><b${unl(d.args[1])?' style="color:var(--acc)"':''}>${amt(d.args[1])}</b></div>`};
  if(d.name==='transfer')return{title:`Send ${m.symbol}`,rows:`<div class="kv"><span>To</span><b>${short(d.args[0])}</b></div><div class="kv"><span>Amount</span><b>${amt(d.args[1])}</b></div>`};
  return{title:`Transfer ${m.symbol}`,rows:`<div class="kv"><span>From</span><b>${short(d.args[0])}</b></div><div class="kv"><span>To</span><b>${short(d.args[1])}</b></div><div class="kv"><span>Amount</span><b>${amt(d.args[2])}</b></div>`};
}
async function showTx(r){
  const t=r.tx;
  if(t.from&&!eq(t.from,S.address)){dappError(r.nid,r.id,4100,'Unknown account');return finishReq()}
  if(!t.to||!ethers.isAddress(t.to)){dappError(r.nid,r.id,4200,'Contract deployment is not supported');return finishReq()}
  const val=BigInt(t.value||0),data=t.data||t.input||'0x';
  const info=await describeCall(t.to,data);
  r.action={to:ethers.getAddress(t.to),value:val,data,label:info.title};
  if(t.gas||t.gasLimit)try{const g=BigInt(t.gas||t.gasLimit);r.action.gas=g*12n/10n}catch{}
  r.title=info.title;
  let est='';
  try{
    const g=await S.rp.estimateGas({from:S.address,to:r.action.to,value:val,data});
    const fd=await S.rp.getFeeData();const gp=fd.gasPrice||fd.maxFeePerGas||0n;
    if(gp)est=`${fmt(g*gp)} ${net().sym}`;
  }catch(e){r.willFail=errMsg(e)}
  sheet('Confirm transaction',`
    ${siteHead(r.origin)}
    <div class="card" style="margin:0 0 10px">
      <div class="kv"><span>Action</span><b>${esc(info.title)}</b></div>
      ${info.rows}
      <div class="kv"><span>Contract</span><b><a href="${net().explorer}/address/${t.to}" target="_blank" rel="noopener">${short(t.to)}</a></b></div>
      ${val?`<div class="kv"><span>${net().sym} value</span><b>${fmt(val)} ${net().sym}</b></div>`:''}
      ${est?`<div class="kv"><span>Network fee</span><b>≈ ${est}</b></div>`:''}
      ${data!=='0x'?`<div class="kv"><span>Data</span><b style="font-family:ui-monospace,monospace;font-size:12px">${data.slice(0,10)}… · ${(data.length-2)/2} bytes</b></div>`:''}
    </div>
    ${r.willFail?`<div class="note"><span class="warn">This transaction will probably fail: ${esc(r.willFail)}</span></div>`:''}
    ${val>S.bnb?`<div class="note"><span class="warn">You only have ${fmt(S.bnb)} ${net().sym}.</span></div>`:''}
    ${feeNote()}
    <div class="grid2"><button class="btn ghost" data-act="reqNo">Reject</button><button class="btn" data-act="reqYes">Confirm</button></div>`);
  S.sheetClose=reqNo;
}
function readableMsg(m){
  if(typeof m!=='string')return JSON.stringify(m);
  if(ethers.isHexString(m)){try{const s=ethers.toUtf8String(m);if(/^[\x09\x0a\x0d\x20-\x7e -￿]*$/.test(s))return s}catch{}}
  return m;
}
async function showSign(r){
  let body;
  if(r.type==='sign')body=`<div class="card" style="margin:0 0 12px;max-height:220px;overflow:auto;white-space:pre-wrap;word-break:break-word;font-size:13px">${esc(readableMsg(r.msg))}</div>`;
  else{
    const td=r.td||{};
    body=`<div class="card" style="margin:0 0 12px">
      <div class="kv"><span>Type</span><b>${esc(td.primaryType||'Typed data')}</b></div>
      ${td.domain?.name?`<div class="kv"><span>App</span><b>${esc(td.domain.name)}</b></div>`:''}
      ${td.domain?.verifyingContract?`<div class="kv"><span>Contract</span><b>${short(td.domain.verifyingContract)}</b></div>`:''}
      <div style="margin-top:8px;max-height:180px;overflow:auto;white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;font-size:11px;color:var(--mut)">${esc(JSON.stringify(td.message||{},null,2))}</div></div>`;
    if(td.primaryType==='Permit'||td.primaryType==='PermitSingle'||td.primaryType==='PermitBatch')body+='<div class="note"><span class="warn">This signature lets the site spend your tokens. Only sign if you trust it.</span></div>';
  }
  sheet('Signature request',`${siteHead(r.origin)}${body}<div class="note">Signing is free and doesn't send a transaction.</div><div class="grid2"><button class="btn ghost" data-act="reqNo">Reject</button><button class="btn" data-act="reqYes">Sign</button></div>`);
  S.sheetClose=reqNo;
}
async function reqYes(){
  const r=S.cur;if(!r)return;
  const btn=S.clicked;S.sheetClose=null;
  if(btn){btn.disabled=true;btn.innerHTML='<span class="spin"></span>Working'}
  try{
    if(r.type==='connect'){
      setConnected(r.origin,true);
      dappReply(r.nid,r.id,r.after==='perms'?[{parentCapability:'eth_accounts'}]:[S.address]);
      dappEvent('connect',{chainId:net().hex});dappEvent('accountsChanged',[S.address]);
      toast(`Connected to ${hostOf(r.origin)}`,'ok');
    }else if(r.type==='tx'){
      const res=await txFlow([r.action],{earlyLast:true});
      dappReply(r.nid,r.id,res.hash);
      const label=`${(dappByUrl(r.origin)||{name:hostOf(r.origin)}).name}: ${r.title}`;
      addActivity({label,hash:res.hash,ts:Date.now(),status:'pending'});
      toast('Transaction sent');
      (res.wait?res.wait():Promise.resolve(res)).then(x=>{setActivity(res.hash,x.ok?'success':'failed');toast(x.ok?'Transaction confirmed':'Transaction failed',x.ok?'ok':'err');refresh()}).catch(()=>{});
    }else if(r.type==='sign'){
      const m=r.msg;
      const sig=await S.wallet.signMessage(typeof m==='string'&&ethers.isHexString(m)?ethers.getBytes(m):m);
      dappReply(r.nid,r.id,sig);
    }else if(r.type==='typed'){
      const td=r.td||{};const types={...td.types};delete types.EIP712Domain;
      const sig=await S.wallet.signTypedData(td.domain||{},types,td.message||{});
      dappReply(r.nid,r.id,sig);
    }
  }catch(e){dappError(r.nid,r.id,e?.code===4001?4001:-32603,errMsg(e));toast(errMsg(e),'err')}
  finishReq();
}
function reqNo(){
  const r=S.cur;S.sheetClose=null;
  if(r)dappError(r.nid,r.id,4001,'User rejected the request');
  finishReq();
}

window.KaviHost={
  onDappRequest,
  onDappUrl(u){if(/^https?:/.test(u))addRecent(u)},
  goHome(){closeSheet();bClose();document.querySelector('[data-tab=tokens]')&&ACTIONS.tab({dataset:{tab:'tokens'}})},
  onBack(){if(sheetOpen()){closeSheet();return true}if($('browser').classList.contains('on')){bClose();return true}return false},
  onPause(){S.pausedAt=Date.now()},
  onResume(){if(S.wallet&&S.pausedAt&&Date.now()-S.pausedAt>LOCK_AFTER)lock();S.pausedAt=0}
};

const ACTIONS={
  close:closeSheet,
  goCreate,goImport,goWelcome(){show('s-welcome')},pwNext,phraseNext,backPhrase(){show('s-phrase')},verifyDone,doImport,doUnlock,
  forgot(){sheet('Forgot password',`<div class="note">Your password can't be recovered. To get back in, remove the wallet from this phone and import it again with your recovery phrase.</div><button class="btn danger" data-act="resetAsk">Remove wallet and restore</button>`)},
  copy(){const a=S.address;(navigator.clipboard?.writeText(a)||Promise.reject()).then(()=>toast('Address copied','ok'),()=>{if(NATIVE)try{NATIVE.copy(a);toast('Address copied','ok');return}catch{}toast(a)})},
  settings:openSettings,saveSettings,
  showPhrase(){askPassword('Recovery phrase','Never share your recovery phrase with anyone.',w=>{
    const words=w.mnemonic?.phrase?.split(' ');
    sheet('Recovery phrase',words?`<div class="note"><span class="warn">Never share these words. Anyone with them can take your funds.</span></div><div class="words">${words.map((x,i)=>`<div class="word"><i>${i+1}</i>${x}</div>`).join('')}</div>`:'<div class="note">This wallet was imported with a private key, so it has no recovery phrase.</div>');
  })},
  askPwGo,lockNow(){lock()},resetAsk,resetGo,
  send:el=>openSend(el.dataset.addr||''),receive:openReceive,swap:openSwap,addToken:openAddToken,
  dapp:openBrowser,bClose,
  openUrl:el=>openUrl(el.dataset.url),
  cat(el){S.cat=el.dataset.v;renderHome($('bq').value.trim())},
  disconnectSite(el){setConnected(el.dataset.o,false);renderHome($('bq').value.trim());toast('Disconnected')},
  reqYes,reqNo,
  token:el=>openToken(el.dataset.addr),
  tab(el){const t=el.dataset.tab;document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x.dataset.tab===t));document.querySelectorAll('.pane').forEach(p=>p.classList.toggle('on',p.id==='p-'+t))},
  sMax,doSend,wMax,wFlip,doSwap,doAdd,
  slip(el){swapSlip=+el.dataset.v;document.querySelectorAll('[data-act=slip]').forEach(b=>b.classList.toggle('on',b===el));quote()},
  doRemove(el){const l=tokenList().filter(a=>!eq(a,el.dataset.addr));saveTokens(l);closeSheet();toast('Token hidden');refresh()},
  async settle(){await run('Settle jackpot',[{to:S.hubAddr,data:IF_HUB.encodeFunctionData('settleRound',[]),label:'Settle jackpot'}],{noFee:true})},
  async claim(){await run('Claim prize',[{to:S.hubAddr,data:IF_HUB.encodeFunctionData('claim',[]),label:'Claim prize'}],{noFee:true})}
};
$('bForm').addEventListener('submit',e=>{e.preventDefault();bGo()});
$('bq').addEventListener('input',()=>renderHome($('bq').value.trim()));
$('unlockPw').addEventListener('keydown',e=>{if(e.key==='Enter'){S.clicked=document.querySelector('[data-act=doUnlock]');doUnlock()}});
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-act]');if(!el)return;
  const f=ACTIONS[el.dataset.act];if(!f)return;
  if(el.tagName==='A')return;
  e.preventDefault();S.clicked=el;S.lastActive=Date.now();f(el);
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)KaviHost.onPause();else KaviHost.onResume()});

if(hasWallet()){$('unlockAddr').textContent=short(savedAddress());show('s-unlock')}else show('s-welcome');
