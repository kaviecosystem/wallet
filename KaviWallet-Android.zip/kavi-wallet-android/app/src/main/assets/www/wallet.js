'use strict';
const APP_VERSION='2.1';
const NETS={
  56:{name:'BNB Chain',hex:'0x38',sym:'BNB',rpcs:['https://bsc-dataseed.bnbchain.org','https://bsc-rpc.publicnode.com','https://bsc-dataseed1.defibit.io','https://bsc-dataseed1.ninicoin.io','https://1rpc.io/bnb'],explorer:'https://bscscan.com',wbnb:'0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',mids:['0x55d398326f99059fF775485246999027B3197955','0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d','0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'],usd:'0x55d398326f99059fF775485246999027B3197955',gecko:'bsc',hub:'0x57C2360E30705B6D9475300cF77266322660C4ca'},
  97:{name:'BNB Testnet',hex:'0x61',sym:'tBNB',rpcs:['https://data-seed-prebsc-1-s1.bnbchain.org:8545','https://bsc-testnet-rpc.publicnode.com'],explorer:'https://testnet.bscscan.com',wbnb:'0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',mids:[],usd:'',gecko:'',hub:''}
};
const POPULAR=[
  ['0x55d398326f99059fF775485246999027B3197955','USDT','Tether USD'],
  ['0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d','USDC','USD Coin'],
  ['0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c','BTCB','Bitcoin BEP20'],
  ['0x2170Ed0880ac9A755fd29B2688956BD959F933F8','ETH','Ethereum Token'],
  ['0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82','CAKE','PancakeSwap Token'],
  ['0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE','XRP','XRP Token'],
  ['0xbA2aE424d960c26247Dd6c32edC70B295c744C43','DOGE','Dogecoin'],
  ['0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47','ADA','Cardano Token'],
  ['0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402','DOT','Polkadot Token'],
  ['0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD','LINK','ChainLink Token'],
  ['0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3','DAI','Dai Token'],
  ['0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56','BUSD','BUSD Token']
];
const GK='https://api.geckoterminal.com/api/v2';

const ERRS=['error ZeroAddress()','error NoLiquidity()','error FeeTooHigh(uint256,uint256)','error RoundNotOver()','error NothingToClaim()','error ReentrantCall()','error TokenCallFailed(address)'];
const HUB_ABI=['function quoteFee() view returns (uint256)','function payFee(uint256) returns (uint256)','function roundInfo() view returns (uint256,uint256,address,uint256,bool)','function settleRound()','function claim()','function unclaimed(address) view returns (uint256)','function kavi() view returns (address)','function pair() view returns (address)','function router() view returns (address)',...ERRS];
const ERC20_ABI=['function symbol() view returns (string)','function name() view returns (string)','function decimals() view returns (uint8)','function totalSupply() view returns (uint256)','function balanceOf(address) view returns (uint256)','function allowance(address,address) view returns (uint256)','function approve(address,uint256) returns (bool)','function transfer(address,uint256) returns (bool)','function transferFrom(address,address,uint256) returns (bool)','function owner() view returns (address)'];
const ROUTER_ABI=['function getAmountsOut(uint256,address[]) view returns (uint256[])','function swapExactETHForTokensSupportingFeeOnTransferTokens(uint256,address[],address,uint256) payable','function swapExactTokensForETHSupportingFeeOnTransferTokens(uint256,uint256,address[],address,uint256)','function swapExactTokensForTokensSupportingFeeOnTransferTokens(uint256,uint256,address[],address,uint256)'];
const NFT_ABI=['function supportsInterface(bytes4) view returns (bool)','function ownerOf(uint256) view returns (address)','function tokenURI(uint256) view returns (string)','function uri(uint256) view returns (string)','function balanceOf(address,uint256) view returns (uint256)','function name() view returns (string)','function symbol() view returns (string)','function safeTransferFrom(address,address,uint256)','function safeTransferFrom(address,address,uint256,uint256,bytes)'];
const IF_ERC20=new ethers.Interface(ERC20_ABI),IF_HUB=new ethers.Interface(HUB_ABI),IF_ROUTER=new ethers.Interface(ROUTER_ABI),IF_NFT=new ethers.Interface(NFT_ABI);
const FRIENDLY={NoLiquidity:'No KAVI liquidity on PancakeSwap',FeeTooHigh:'KAVI price moved too much. Try again',RoundNotOver:'Round is still running',NothingToClaim:'Nothing to claim',TokenCallFailed:'Token transfer failed',ZeroAddress:'Invalid address'};
const NATIVE=window.KaviNative||null;
const MAXU=2n**255n;

const store={get(k){try{return localStorage.getItem(k)}catch{return null}},set(k,v){try{localStorage.setItem(k,v)}catch{}},del(k){try{localStorage.removeItem(k)}catch{}},json(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v===null||v===undefined?d:v}catch{return d}},put(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};
const S={chain:Number(store.get('kw_chain')||56),meta:{},tokens:[],bnb:0n,kaviBal:0n,fee:0n,round:null,unclaimed:0n,prices:{},priceAt:0,gk:{},gkAt:0,queue:[],busy:false,cat:'All',http:{},hseq:0,pools:{},fx:{USD:1,INR:null}};
const $=id=>document.getElementById(id);
const net=()=>NETS[S.chain];
const hubAddr=()=>store.get('kw_hub3_'+S.chain)||net().hub;
const short=a=>a?a.slice(0,6)+'…'+a.slice(-4):'';
const eq=(a,b)=>!!a&&!!b&&String(a).toLowerCase()===String(b).toLowerCase();
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hostOf=u=>{try{return new URL(u).host}catch{return u||''}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const nat=(fn,...a)=>{if(!NATIVE||typeof NATIVE[fn]!=='function')return undefined;try{return NATIVE[fn](...a)}catch(e){console.warn(fn,e);return undefined}};

function fmt(v,dec=18){
  const s=ethers.formatUnits(v,dec);let[i,f='']=s.split('.');
  const max=i==='0'?8:i.length>4?2:4;
  f=f.slice(0,max).replace(/0+$/,'');
  i=i.replace(/\B(?=(\d{3})+(?!\d))/g,',');
  return f?i+'.'+f:i;
}
const hidden=()=>store.get('kw_hide')==='1';
const mask=s=>hidden()?'****':s;
function curCode(){return store.get('kw_cur')||'USD'}
function curRate(){return curCode()==='INR'?(S.fx.INR||83):1}
function curSym(){return curCode()==='INR'?'₹':'$'}
function curFmt(usd){
  if(usd===null||usd===undefined||!isFinite(usd))return '';
  const x=usd*curRate(),sym=curSym();
  if(x===0)return sym+'0.00';
  if(Math.abs(x)<0.01)return sym+x.toPrecision(2);
  return sym+x.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
}
function priceFmt(usd){
  if(usd===null||usd===undefined||!isFinite(usd))return '—';
  const x=usd*curRate(),sym=curSym();
  if(x>=1)return sym+x.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:x>=1000?2:4});
  if(x===0)return sym+'0';
  return sym+x.toPrecision(4);
}
const chFmt=c=>c===null||c===undefined||!isFinite(c)?'—':(c>=0?'+':'')+c.toFixed(2)+'%';
const priceKey=a=>(a||'bnb').toLowerCase();
function kaviMeta(){return S.meta[(S.kavi||'').toLowerCase()]||{symbol:'KAVI',decimals:18}}
function priceUsd(addr){
  const g=S.gk[priceKey(addr||net().wbnb)];
  if(g&&isFinite(g.price))return g.price;
  let p=S.prices[priceKey(addr)];
  if((p===undefined||p===null)&&eq(addr,S.kavi)&&S.fee)p=0.001/Number(ethers.formatUnits(S.fee,kaviMeta().decimals));
  return p===undefined?null:p;
}
function change24(addr){const g=S.gk[priceKey(addr||net().wbnb)];return g&&isFinite(g.ch)?g.ch:null}
function usdNum(v,dec,addr){const p=priceUsd(addr);return p===null?null:Number(ethers.formatUnits(v,dec))*p}
const valOf=(v,dec,addr)=>curFmt(usdNum(v,dec,addr));

let toastT;
function toast(msg,type=''){const t=$('toast');t.textContent=msg;t.className='on '+type;clearTimeout(toastT);toastT=setTimeout(()=>t.className=type,type==='err'?5000:3200)}
function show(id){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id===id))}

function httpReq(method,url,body){
  if(NATIVE&&typeof NATIVE.httpRequest==='function'){
    return new Promise((res,rej)=>{
      const id='h'+(++S.hseq);
      const t=setTimeout(()=>{if(S.http[id]){delete S.http[id];rej(new Error('Network timeout'))}},25000);
      S.http[id]={res,rej,t};
      try{NATIVE.httpRequest(id,method,url,body||'')}catch(e){clearTimeout(t);delete S.http[id];rej(e)}
    });
  }
  return fetch(url,{method,body:method==='POST'?body:undefined,headers:method==='POST'?{'content-type':'application/json'}:{}}).then(async r=>({status:r.status,body:await r.text()}));
}
async function httpJson(url){const r=await httpReq('GET',url);if(r.status<200||r.status>=300)throw new Error('HTTP '+r.status);return JSON.parse(r.body)}

function rpcUrls(){const c=store.get('kw_rpc_'+S.chain);return c?[c,...net().rpcs.filter(x=>x!==c)]:net().rpcs}
function makeProvider(){
  const list=rpcUrls();
  S.rpcIdx=(S.rpcIdx||0)%list.length;
  const url=list[S.rpcIdx];
  let conn=url;
  if(NATIVE&&typeof NATIVE.httpRequest==='function'){
    conn=new ethers.FetchRequest(url);
    conn.getUrlFunc=async(req)=>{
      const body=req.body?ethers.toUtf8String(req.body):'';
      const r=await httpReq(req.method||'POST',req.url,body);
      return {statusCode:r.status,statusMessage:'',headers:{'content-type':'application/json'},body:ethers.toUtf8Bytes(r.body||'')};
    };
  }
  S.rp=new ethers.JsonRpcProvider(conn,S.chain,{staticNetwork:ethers.Network.from(S.chain),batchMaxCount:1});
  if(S.wallet)S.signer=S.wallet.connect(S.rp);
}
function rotateRpc(){if(store.get('kw_rpc_'+S.chain))return;S.rpcIdx=(S.rpcIdx||0)+1;makeProvider();initContracts()}

const TE=new TextEncoder(),TD=new TextDecoder();
async function deriveKey(pw,saltHex,iter){
  const base=await crypto.subtle.importKey('raw',TE.encode(pw),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt:ethers.getBytes(saltHex),iterations:iter,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function seal(key,obj){
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,TE.encode(JSON.stringify(obj))));
  return {iv:ethers.hexlify(iv),ct:ethers.encodeBase64(ct)};
}
async function unseal(key,box){
  const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:ethers.getBytes(box.iv)},key,ethers.decodeBase64(box.ct));
  return JSON.parse(TD.decode(pt));
}
function getVault(){return store.json('kw_vault',null)}
function saveVault(v){store.put('kw_vault',v)}
function hasVault(){return !!getVault()||!!store.get('kw_keystore')}
function walletsAll(){return (getVault()?.wallets)||[]}
function activeRec(){const w=walletsAll();return w.find(x=>x.id===store.get('kw_active'))||w[0]||null}
async function newVault(pw){
  const salt=ethers.hexlify(crypto.getRandomValues(new Uint8Array(16))),iter=600000;
  const key=await deriveKey(pw,salt,iter);
  const v={v:2,salt,iter,check:await seal(key,'kavi-ok'),wallets:[]};
  saveVault(v);S.vkey=key;return v;
}
async function openVault(pw){
  const v=getVault();
  const key=await deriveKey(pw,v.salt,v.iter);
  let ok=false;try{ok=(await unseal(key,v.check))==='kavi-ok'}catch{}
  if(!ok)throw new Error('Wrong password');
  return key;
}
function uid(){return 'w'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
async function addWalletRec({name,type,address,secret}){
  const v=getVault();
  if(v.wallets.some(w=>eq(w.address,address)))throw new Error('This wallet is already added');
  const rec={id:uid(),name:name||`Wallet ${v.wallets.length+1}`,type,address:ethers.getAddress(address),created:Date.now()};
  if(type!=='watch')rec.box=await seal(S.vkey,secret);
  v.wallets.push(rec);saveVault(v);return rec;
}
async function loadSigner(rec){
  if(rec.type==='watch')return null;
  const sec=await unseal(S.vkey,rec.box);
  if(sec.phrase)return ethers.Wallet.fromPhrase(sec.phrase);
  return new ethers.Wallet(sec.pk);
}
async function secretOf(rec){return rec.type==='watch'?null:unseal(S.vkey,rec.box)}

async function migrateOld(pw){
  const json=store.get('kw_keystore');
  const w=await ethers.Wallet.fromEncryptedJson(json,pw);
  await newVault(pw);
  const rec=await addWalletRec({name:'Wallet 1',type:w.mnemonic?'phrase':'key',address:w.address,secret:w.mnemonic?{phrase:w.mnemonic.phrase}:{pk:w.privateKey}});
  store.set('kw_active',rec.id);store.del('kw_keystore');store.del('kw_address');
  return rec;
}

async function startSession(rec){
  try{bgPull()}catch{}
  S.rec=rec;S.watch=rec.type==='watch';
  S.wallet=await loadSigner(rec);
  S.address=rec.address;S.lastActive=Date.now();
  store.set('kw_active',rec.id);
  S.tokens=[];S.bnb=0n;S.kaviBal=0n;S.nfts=null;
  makeProvider();
  S.signer=S.wallet?S.wallet.connect(S.rp):null;
  show('s-main');
  renderHeader();updateBadge();
  nav(S.tab||'wallet');
  await route();
}
async function switchWallet(id){
  const rec=walletsAll().find(w=>w.id===id);if(!rec)return;
  closeSheet();closePage();
  await startSession(rec);
  dappEvent('accountsChanged',S.dappOrigin&&isConnected(S.dappOrigin)?[S.address]:[]);
  toast(`Switched to ${rec.name}`);
}
function lock(){
  S.wallet=null;S.signer=null;S.vkey=null;clearInterval(S.poll);
  nat('closeDapp');stopScan();
  closeSheet();closePage();
  showUnlock();
}
function showUnlock(){
  const r=activeRec();
  $('unlockAddr').textContent=r?`${r.name} · ${short(r.address)}`:short(store.get('kw_address')||'');
  $('unlockPw').value='';
  $('bioBtn').hidden=bioState()!=='enabled';
  show('s-unlock');
  if(bioState()==='enabled')setTimeout(()=>{if($('s-unlock').classList.contains('on'))bioUnlock()},400);
}

function initContracts(){
  if(!S.hubAddr)return;
  S.hub=new ethers.Contract(S.hubAddr,HUB_ABI,S.rp);
  if(S.routerAddr)S.router=new ethers.Contract(S.routerAddr,ROUTER_ABI,S.rp);
}
async function route(){
  const h=hubAddr();
  renderHeader();
  if(!h||!ethers.isAddress(h)){toast('KaviHub address is not set for this network. Open Me → Advanced.','err');return}
  S.hubAddr=h;initContracts();
  for(let attempt=0;attempt<3;attempt++){
    try{
      S.kavi=await S.hub.kavi();
      const [pr,rt]=await Promise.all([S.hub.pair(),S.hub.router()]);
      S.routerAddr=rt;initContracts();
      try{
        const pc=new ethers.Contract(pr,['function token0() view returns (address)','function token1() view returns (address)'],S.rp);
        const [t0,t1]=await Promise.all([pc.token0(),pc.token1()]);
        S.kaviQuote=eq(t0,S.kavi)?t1:t0;
      }catch{}
      break;
    }catch(e){if(attempt===2){toast('Network problem: '+errMsg(e),'err');return}rotateRpc()}
  }
  await refresh();
  clearInterval(S.poll);S.poll=setInterval(refresh,15000);
  loadFx();
}

function wkey(p){return `kw_${p}_${S.chain}_${S.address}`}
function tokenList(){
  let l=store.json(wkey('tokens'),null);
  if(!Array.isArray(l)){l=store.json('kw_tokens_'+S.chain+'_'+S.address,null)}
  if(!Array.isArray(l)){l=[];if(S.kaviQuote)l.push(S.kaviQuote)}
  return [S.kavi,...l.filter(a=>!eq(a,S.kavi))];
}
function saveTokens(l){store.put(wkey('tokens'),l.filter(a=>!eq(a,S.kavi)))}

async function meta(addr){
  const k=addr.toLowerCase();
  if(S.meta[k])return S.meta[k];
  const c=new ethers.Contract(addr,ERC20_ABI,S.rp);
  const [symbol,name,decimals]=await Promise.all([c.symbol().catch(()=>'???'),c.name().catch(()=>'Unknown token'),c.decimals().catch(()=>18n)]);
  return S.meta[k]={symbol,name,decimals:Number(decimals)};
}

async function refresh(){
  if(!S.hub||!S.address||!S.kavi)return;
  try{
    const list=tokenList();
    const [bnb,fee,round,unc,bals]=await Promise.all([
      S.rp.getBalance(S.address),
      S.hub.quoteFee().catch(()=>0n),
      S.hub.roundInfo(),
      S.hub.unclaimed(S.address).catch(()=>0n),
      Promise.all(list.map(a=>new ethers.Contract(a,ERC20_ABI,S.rp).balanceOf(S.address).catch(()=>0n)))
    ]);
    S.bnb=bnb;S.fee=fee;S.unclaimed=unc;S.rpcFails=0;
    S.tokens=await Promise.all(list.map(async(a,i)=>({addr:a,bal:bals[i],...(await meta(a))})));
    S.kaviBal=S.tokens[0]?.bal||0n;
    S.round={no:round[0],pot:round[1],lead:round[2],end:Number(round[3]),settle:round[4]};
    render();
    const missing=S.tokens.some(t=>!(priceKey(t.addr) in S.prices));
    if(missing||Date.now()-S.priceAt>60000){await loadPrices();render()}
    checkPending();
    notifTick();bgSync();
  }catch(e){console.error(e);S.rpcFails=(S.rpcFails||0)+1;if(S.rpcFails>=2){S.rpcFails=0;rotateRpc()}}
}

function buildPaths(a,b){
  const W=net().wbnb;
  const mids=[W,S.kaviQuote,...(net().mids||[])].filter((x,i,arr)=>x&&arr.findIndex(y=>eq(x,y))===i);
  const out=[[a,b]];
  for(const m of mids)if(!eq(m,a)&&!eq(m,b))out.push([a,m,b]);
  for(const m1 of mids)for(const m2 of mids){
    if(eq(m1,m2)||eq(m1,a)||eq(m1,b)||eq(m2,a)||eq(m2,b))continue;
    if(eq(m1,W)||eq(m2,W))out.push([a,m1,m2,b]);
  }
  return out;
}
async function bestOut(amt,a,b){
  const paths=buildPaths(a,b);
  const outs=await Promise.all(paths.map(p=>S.router.getAmountsOut(amt,p).then(o=>o[o.length-1]).catch(()=>null)));
  let best=null;outs.forEach((o,i)=>{if(o!==null&&(!best||o>best.out))best={path:paths[i],out:o}});
  return best;
}
async function priceOf(addr,dec){
  if(!S.router)return null;
  const a=addr||net().wbnb;
  for(const U of [net().usd,S.kaviQuote].filter((x,i,l)=>x&&l.findIndex(y=>eq(x,y))===i)){
    if(eq(a,U))return 1;
    try{
      const ud=(await meta(U)).decimals;
      const b=await bestOut(10n**BigInt(dec),a,U);
      if(b)return Number(ethers.formatUnits(b.out,ud));
    }catch{}
  }
  return null;
}
async function loadPrices(){
  const items=[{addr:'',decimals:18},...S.tokens];
  const ps=await Promise.all(items.map(t=>priceOf(t.addr,t.decimals).catch(()=>null)));
  items.forEach((t,i)=>{S.prices[priceKey(t.addr)]=ps[i]});
  S.priceAt=Date.now();
  for(const a of alerts())if(a.on&&a.chain===S.chain&&a.token&&!(priceKey(a.token) in S.prices)){try{const m=await meta(a.token);S.prices[priceKey(a.token)]=await priceOf(a.token,m.decimals)}catch{}}
  loadGecko([net().wbnb,...S.tokens.map(t=>t.addr),...alerts().filter(a=>a.on&&a.token).map(a=>a.token)]).then(()=>{render();checkAlerts()}).catch(()=>{});
}
async function loadGecko(addrs,force){
  const g=net().gecko;if(!g)return;
  const need=[...new Set(addrs.map(a=>a.toLowerCase()))].filter(a=>force||!S.gk[a]||Date.now()-S.gk[a].t>60000);
  for(let i=0;i<need.length;i+=30){
    const chunk=need.slice(i,i+30);
    const j=await httpJson(`${GK}/simple/networks/${g}/token_price/${chunk.join(',')}?include_24hr_price_change=true`);
    const at=j?.data?.attributes||{},tp=at.token_prices||{},ch=at.h24_price_change_percentage||{};
    for(const a of chunk){
      const p=tp[a]??tp[Object.keys(tp).find(k=>k.toLowerCase()===a)];
      const c=ch[a]??ch[Object.keys(ch).find(k=>k.toLowerCase()===a)];
      S.gk[a]={price:p!=null?Number(p):NaN,ch:c!=null?Number(c):NaN,t:Date.now()};
    }
  }
}
async function loadFx(){
  if(curCode()!=='INR'||S.fx.INR&&Date.now()-S.fxAt<3600000)return;
  try{const j=await httpJson('https://open.er-api.com/v6/latest/USD');if(j?.rates?.INR){S.fx.INR=Number(j.rates.INR);S.fxAt=Date.now();store.set('kw_fx_inr',String(S.fx.INR));render()}}catch{}
}
S.fx.INR=Number(store.get('kw_fx_inr'))||null;

const COLORS=['#f0b90b','#2ebd85','#3b82f6','#a855f7','#ef4444','#14b8a6','#f97316','#ec4899'];
function icon(sym,addr,size){
  const st=size?`width:${size}px;height:${size}px;font-size:${Math.round(size*0.4)}px;`:'';
  if(!addr)return `<div class="ic" style="${st}background:#f0b90b;color:#1a1400">B</div>`;
  const c=COLORS[parseInt(addr.slice(2,6),16)%COLORS.length];
  return `<div class="ic" style="${st}background:${c}22;color:${c}">${esc(String(sym||'?').slice(0,1).toUpperCase())}</div>`;
}
const EYE_ON='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.2M6.6 6.6C3.7 8.5 2 12 2 12s3.5 7 10 7a9.7 9.7 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';

function renderHeader(){
  if(!S.rec)return;
  $('wName').textContent=S.rec.name;
  $('hAv').textContent=(S.rec.name||'W').slice(0,1).toUpperCase();
  $('wAddr').textContent=short(S.address);
  $('netName').textContent=net().name;
  $('watchTag').hidden=!S.watch;
  $('eyeBtn').innerHTML=hidden()?EYE_OFF:EYE_ON;
  $('smallBtn').textContent=store.get('kw_small')==='1'?'Show all tokens':'Hide small balances';
}
function tokenRow(t){
  const p=priceUsd(t.addr||''),c=change24(t.addr||'');
  const addr=t.addr||'';
  return `<button class="row" data-act="tokenPage" data-addr="${addr}">${addr?icon(t.symbol,addr):`<div>${icon('B')}</div>`}<div class="n"><b>${esc(t.symbol)}</b><span class="tp">${p!==null?priceFmt(p):esc(t.name)}${c!==null?` <i class="${c>=0?'up':'dn'}" style="font-style:normal">${chFmt(c)}</i>`:''}</span></div><div class="v"><b>${mask(fmt(t.bal,t.decimals))}</b><span>${mask(valOf(t.bal,t.decimals,addr))}</span></div></button>`;
}
function render(){
  if(!S.round)return;
  const km=kaviMeta();
  const all=[{addr:'',symbol:net().sym,name:'BNB Chain',bal:S.bnb,decimals:18},...S.tokens];
  let total=0,known=0;
  for(const t of all){const u=usdNum(t.bal,t.decimals,t.addr);if(u!==null){total+=u;known++}}
  $('bnbBal').innerHTML=hidden()?'<span>****</span>':known?curFmt(total).replace(/^(.)/,'<small style="font-size:22px;color:var(--text)">$1</small>'):`${fmt(S.bnb)} <small>${net().sym}</small>`;
  $('feeK').textContent=S.fee?`${fmt(S.fee,km.decimals)} ${km.symbol}`:'Unavailable';
  const small=store.get('kw_small')==='1';
  const rows=all.filter(t=>{if(!small||!t.addr||eq(t.addr,S.kavi))return true;const u=usdNum(t.bal,t.decimals,t.addr);return u===null?t.bal>0n:u>=1});
  $('tokList').innerHTML=rows.map(tokenRow).join('');
  const r=S.round;
  $('rNo').textContent=r.no.toString();
  $('rPot').textContent=`${fmt(r.pot,km.decimals)} ${km.symbol} ${r.pot?'· '+valOf(r.pot,km.decimals,S.kavi):''}`;
  $('rWin').textContent=`${fmt(r.pot/2n,km.decimals)} ${km.symbol}`;
  const none=r.lead===ethers.ZeroAddress;
  const me=eq(r.lead,S.address);
  $('rLead').innerHTML=none?'—':`${short(r.lead)}${me?'<span class="badge">You</span>':''}`;
  $('jpPot').textContent=`Jackpot ${fmt(r.pot,km.decimals)} ${km.symbol}`;
  $('claimBtn').hidden=!S.unclaimed;
  $('claimBtn').textContent=`Claim ${fmt(S.unclaimed,km.decimals)} ${km.symbol} prize`;
  $('pendDot').hidden=!getAct().some(a=>a.status==='pending');
  renderHeader();
  tick();
  if(S.tab==='market')renderMarket();
}
function tick(){
  const r=S.round;if(!r)return;
  const none=r.lead===ethers.ZeroAddress;
  const left=Math.max(0,r.end-Math.floor(Date.now()/1000));
  const over=!none&&left===0;
  const pd=n=>String(n).padStart(2,'0'),hh=Math.floor(left/3600);
  const t=none?'--:--':hh?`${hh}:${pd(Math.floor(left%3600/60))}:${pd(left%60)}`:`${pd(Math.floor(left/60))}:${pd(left%60)}`;
  $('jpT').textContent=over?'00:00':t;$('jpBig').textContent=over?'00:00':t;
  const me=eq(r.lead,S.address);
  $('jpLead').textContent=none?'Waiting for first transaction':over?(me?'You won! Settle to receive it':'Round over. Settle to pay winner'):me?'You are leading 🏆':`Leader ${short(r.lead)}`;
  $('settleBtn').hidden=!over;
}
setInterval(tick,1000);

function assets(){return [{addr:'',symbol:net().sym,name:'BNB Chain',decimals:18,bal:S.bnb},...S.tokens]}
function assetOpts(sel,includeCustom){
  return assets().map(a=>`<option value="${a.addr}" ${eq(a.addr,sel)||(!a.addr&&!sel)?'selected':''}>${esc(a.symbol)} · ${fmt(a.bal,a.decimals)}</option>`).join('')+(includeCustom?'<option value="custom">Other token (address)…</option>':'');
}
const findAsset=a=>assets().find(x=>eq(x.addr,a)||(!a&&!x.addr));

function sheet(title,html,mount){
  S.sheetClose=null;
  S.sheetId=(S.sheetId||0)+1;
  $('sheet').innerHTML=`<div class="grab"></div><div class="sh"><h2>${title}</h2><button class="x" data-act="close"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>${html}`;
  $('bd').classList.add('on');
  mount&&mount();
}
function sheetOpen(){return $('bd').classList.contains('on')}
function closeSheet(){const f=S.sheetClose;S.sheetClose=null;$('bd').classList.remove('on');if(f)f()}
function closeSheetIf(id){if(S.sheetId===id)closeSheet()}
$('bd').addEventListener('click',e=>{if(e.target.id==='bd')closeSheet()});

S.pages=[];
function page(title,html,{onShow,act,key}={}){
  S.pages.push({title,html,onShow,act,key});
  paintPage();
}
function paintPage(){
  const p=S.pages[S.pages.length-1];
  if(!p){$('page').classList.remove('on');return}
  $('pageTtl').textContent=p.title;
  $('pageAct').innerHTML=p.act||'';
  $('pageBody').innerHTML=typeof p.html==='function'?p.html():p.html;
  $('page').classList.add('on');
  $('pageBody').scrollTop=0;
  p.onShow&&p.onShow();
}
function replacePage(title,html,opts={}){S.pages.pop();page(title,html,opts)}
function pageBack(){S.pages.pop();paintPage()}
function closePage(){S.pages=[];paintPage()}
function topPage(){return S.pages[S.pages.length-1]}
function repaintIf(key){const p=topPage();if(p&&p.key===key)paintPage()}

function errMsg(e){
  if(e?.code==='ACTION_REJECTED'||e?.code===4001)return 'Request rejected';
  let n=e?.revert?.name;
  const data=e?.data||e?.info?.error?.data;
  if(!n&&data){try{n=IF_HUB.parseError(data)?.name}catch{}}
  if(n)return FRIENDLY[n]||n;
  if(e?.code==='INSUFFICIENT_FUNDS')return `Not enough ${net().sym} for network gas`;
  if(e?.code==='CALL_EXCEPTION')return e.reason?('Transaction would fail: '+e.reason):'Transaction would fail';
  return e?.shortMessage||e?.reason||e?.message||'Something went wrong';
}
function needSigner(){if(S.watch||!S.wallet){toast('This is a watch-only wallet. Switch to a wallet with a private key to send.','err');return false}return true}

function gasMode(){return store.get('kw_gas')||'standard'}
const GAS_MULT={slow:100n,standard:115n,fast:150n};
async function currentGasPrice(){const fd=await S.rp.getFeeData();return fd.gasPrice||ethers.parseUnits('1','gwei')}
async function gasPriceNow(){
  const m=gasMode();
  if(/^[0-9.]+$/.test(m))return ethers.parseUnits(m,'gwei');
  const gp=await currentGasPrice();
  return gp*(GAS_MULT[m]||115n)/100n;
}
function gasChips(){
  const m=gasMode(),custom=/^[0-9.]+$/.test(m);
  return `<div class="gasc">${['slow','standard','fast'].map(k=>`<button data-act="gasSel" data-v="${k}" class="${m===k?'on':''}">${k[0].toUpperCase()+k.slice(1)}</button>`).join('')}<button data-act="gasSel" data-v="custom" class="${custom?'on':''}">Custom</button></div>
    <div class="inp gcust" id="gasCustomBox" ${custom?'':'hidden'}><input id="gasCustom" inputmode="decimal" placeholder="Gas price" value="${custom?esc(m):''}"><span class="sub">Gwei</span></div>`;
}
function feeNote(mode){
  const km=kaviMeta();
  const fee=!S.fee?'KAVI fee unavailable right now (no pool liquidity), so no KAVI fee will be charged.':`+ <b>${fmt(S.fee,km.decimals)} ${km.symbol}</b> fee (≈ $0.001), paid automatically with this transaction.`;
  const low=S.fee&&S.kaviBal<S.fee;
  const lowMsg=mode==='swap'?'<br>You have no KAVI yet, so when you buy KAVI the fee is paid from the KAVI you receive.':'<br><span class="warn">Not enough KAVI for the fee. Swap some BNB to KAVI first.</span>';
  return `<div class="note">Network gas in ${net().sym} ${fee}${low?lowMsg:''}${gasChips()}</div>`;
}

function getAct(){return store.json(wkey('act'),null)||store.json('kw_act_'+S.chain+'_'+S.address,[])}
function saveAct(l){store.put(wkey('act'),l.slice(0,200))}
function putAct(rec){const l=getAct().filter(a=>a.hash!==rec.hash);l.unshift(rec);saveAct(l);$('pendDot').hidden=!l.some(a=>a.status==='pending');repaintIf('history')}
function setAct(hash,patch){const l=getAct();const x=l.find(a=>a.hash===hash);if(x)Object.assign(x,patch);saveAct(l);$('pendDot').hidden=!l.some(a=>a.status==='pending');repaintIf('history')}
async function waitTx(hash,timeout){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    const rc=await S.rp.getTransactionReceipt(hash).catch(()=>null);
    if(rc)return rc;
    await sleep(1500);
  }
  return null;
}
function finishAct(hash,rc){
  if(!rc)return;
  const a=getAct().find(x=>x.hash===hash);
  setAct(hash,{status:rc.status===1?'success':'failed',block:rc.blockNumber});
  if(a&&!a.aux&&a.status==='pending')pushNotif({kind:'tx',title:rc.status===1?'Transaction confirmed':'Transaction failed',body:a.label,hash,toast:false});
}
async function checkPending(){
  const pend=getAct().filter(a=>a.status==='pending');if(!pend.length)return;
  let latest=null;
  for(const a of pend){
    const rc=await S.rp.getTransactionReceipt(a.hash).catch(()=>null);
    if(rc){finishAct(a.hash,rc);continue}
    if(latest===null)latest=await S.rp.getTransactionCount(S.address,'latest').catch(()=>null);
    if(latest!==null&&a.nonce!==undefined&&latest>a.nonce&&Date.now()-a.ts>15000){
      const other=getAct().find(x=>x.nonce===a.nonce&&x.hash!==a.hash&&(x.status==='success'||x.status==='failed'));
      setAct(a.hash,{status:other?'replaced':'dropped'});
    }
  }
}

function recordApproval(to,data){
  try{
    const d=IF_ERC20.parseTransaction({data});
    if(d?.name!=='approve')return;
    const l=store.json(wkey('appr'),[]).filter(x=>!(eq(x.token,to)&&eq(x.spender,d.args[0])));
    l.unshift({token:ethers.getAddress(to),spender:ethers.getAddress(d.args[0]),ts:Date.now()});
    store.put(wkey('appr'),l.slice(0,100));
  }catch{}
}

async function feeCalls(){
  S.fee=await S.hub.quoteFee().catch(()=>0n);
  if(!S.fee)return [];
  const hub=S.hubAddr,maxFee=S.fee*3n/2n;
  const calls=[];
  const allowance=await new ethers.Contract(S.kavi,ERC20_ABI,S.rp).allowance(S.address,hub).catch(()=>0n);
  if(allowance<maxFee)calls.push({to:S.kavi,data:IF_ERC20.encodeFunctionData('approve',[hub,ethers.MaxUint256]),label:'Allow KAVI fee (one time)'});
  calls.push({to:hub,data:IF_HUB.encodeFunctionData('payFee',[maxFee]),label:'KAVI fee',gas:450000n});
  return calls;
}

async function sendCalls(calls,{earlyLast=false,label='',extra={}}={}){
  if(!S.signer)throw new Error('This is a watch-only wallet. It can\'t send transactions.');
  const gp=await gasPriceNow();
  let nonce=Number(await S.rp.send('eth_getTransactionCount',[S.address,'pending']));
  let last=null;
  const mi=calls.some(c=>c.main)?calls.findIndex(c=>c.main):calls.length-1;
  for(let i=0;i<calls.length;i++){
    const c=calls[i],isLast=i===calls.length-1,isMain=i===mi;
    if(calls.length>1)toast(`Sending ${i+1} of ${calls.length}: ${c.label}`);
    const req={to:c.to,value:c.value||0n,data:c.data||'0x',nonce:nonce++,gasPrice:gp,type:0,chainId:S.chain};
    if(c.gas)req.gasLimit=c.gas;
    else{const est=await S.rp.estimateGas({from:S.address,to:req.to,value:req.value,data:req.data});req.gasLimit=est*13n/10n+10000n}
    const tx=await S.signer.sendTransaction(req);
    if(req.data&&req.data!=='0x')recordApproval(req.to,req.data);
    putAct({hash:tx.hash,label:isMain?(label||c.label):c.label,ts:Date.now(),status:'pending',nonce:req.nonce,to:req.to,value:String(req.value),data:req.data,gasPrice:String(gp),gasLimit:String(req.gasLimit),aux:!isMain,...(isMain?extra:{})});
    if(isLast&&earlyLast)return {hash:tx.hash,wait:()=>waitTx(tx.hash,600000).then(rc=>{finishAct(tx.hash,rc);return {hash:tx.hash,ok:rc?.status===1}})};
    const rc=await waitTx(tx.hash,120000);
    if(!rc){const e=new Error('Transaction is taking long to confirm. Open History to speed it up.');e.pending=true;throw e}
    finishAct(tx.hash,rc);
    last={hash:tx.hash,ok:rc.status===1};
    if(!last.ok)return last;
  }
  return last;
}
async function txFlow(actions,{feeAfter=false,noFee=false,earlyLast=false,label='',extra}={}){
  const fees=noFee?[]:await feeCalls();
  if(fees.length&&!feeAfter&&S.kaviBal<S.fee)throw new Error('Not enough KAVI for the fee. Swap some BNB to KAVI first.');
  const acts=actions.map((a,i)=>i===actions.length-1?{...a,main:true}:a);
  const calls=feeAfter?[...acts,...fees]:[...fees,...acts];
  return await sendCalls(calls,{earlyLast:earlyLast&&!feeAfter,label,extra});
}
async function run(label,actions,opts={}){
  if(!needSigner())return;
  const btn=S.clicked?.classList?.contains('btn')?S.clicked:null;
  const old=btn?.innerHTML,sid=S.sheetId;
  try{
    if(btn){btn.disabled=true;btn.innerHTML='<span class="spin"></span>Sending'}
    const res=await txFlow(actions,{...opts,label});
    closeSheetIf(sid);
    toast(res?.ok?label+' confirmed':label+' failed',res?.ok?'ok':'err');
    refresh();
    return res;
  }catch(e){toast(errMsg(e),'err');if(e.pending)closeSheetIf(sid)}
  finally{if(btn&&btn.isConnected){btn.disabled=false;btn.innerHTML=old}}
}

function recipientBox(id,val=''){
  return `<div class="f"><label><span>Recipient</span><span><button class="max" data-act="scanInto" data-target="${id}">SCAN</button></span></label><div class="inp"><input id="${id}" value="${esc(val)}" placeholder="0x… or contact name" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div><div class="sug" id="${id}Sug"></div>`;
}
function contacts(){return store.json('kw_contacts',[])}
function recents(){const seen=new Set(),out=[];for(const a of getAct())if(a.recipient&&!seen.has(a.recipient.toLowerCase())){seen.add(a.recipient.toLowerCase());out.push(a.recipient)}return out.slice(0,5)}
function nameOf(addr){const c=contacts().find(x=>eq(x.address,addr));if(c)return c.name;const w=walletsAll().find(x=>eq(x.address,addr));return w?w.name:''}
function wireRecipient(id){
  const inp=$(id),box=$(id+'Sug');
  const paint=()=>{
    const q=inp.value.trim().toLowerCase();
    if(ethers.isAddress(inp.value.trim())){const n=nameOf(inp.value.trim());box.innerHTML=n?`<div class="sub" style="padding:0 4px">✓ ${esc(n)}</div>`:'';return}
    const items=[...contacts().map(c=>({n:c.name,a:c.address})),...walletsAll().filter(w=>!eq(w.address,S.address)).map(w=>({n:w.name+' (my wallet)',a:w.address})),...recents().map(a=>({n:'Recent',a}))];
    const seen=new Set();
    const list=items.filter(x=>{const k=x.a.toLowerCase();if(seen.has(k))return false;seen.add(k);return !q||x.n.toLowerCase().includes(q)||k.includes(q)}).slice(0,5);
    box.innerHTML=list.map(x=>`<button data-act="pickAddr" data-target="${id}" data-a="${x.a}"><b>${esc(x.n)}</b><span>${short(x.a)}</span></button>`).join('');
  };
  inp.addEventListener('input',paint);paint();
}
function resolveRecipient(v){
  v=v.trim();if(ethers.isAddress(v))return ethers.getAddress(v);
  const c=contacts().find(x=>x.name.toLowerCase()===v.toLowerCase());return c?c.address:null;
}

function openSend(pre,{to='',amount=''}={}){
  if(!needSigner())return;
  sheet('Send',`
    <div class="f"><label>Asset</label><div class="inp"><select id="sA">${assetOpts(pre)}</select></div></div>
    ${recipientBox('sTo',to)}
    <div class="f"><label><span>Amount</span><span id="sAv"></span></label><div class="inp"><input id="sAmt" inputmode="decimal" placeholder="0.0" value="${esc(amount)}"><button class="max" data-act="sMax">MAX</button></div><div class="sub" id="sVal" style="margin-top:4px"></div></div>
    ${feeNote()}
    <button class="btn" data-act="doSend">Send</button>`,()=>{$('sA').onchange=sAv;$('sAmt').oninput=sAv;sAv();wireRecipient('sTo')});
}
function sAv(){const a=findAsset($('sA').value);$('sAv').textContent='Available '+fmt(a.bal,a.decimals)+' '+a.symbol;let v='';try{const x=ethers.parseUnits($('sAmt').value.trim()||'0',a.decimals);v=x?valOf(x,a.decimals,a.addr):''}catch{}$('sVal').textContent=v?'≈ '+v:''}
function spendable(a){
  let v=a.bal;
  if(eq(a.addr,S.kavi))v=v>S.fee?v-S.fee:0n;
  if(!a.addr){const gas=ethers.parseEther('0.002');v=v>gas?v-gas:0n}
  return v;
}
function sMax(){const a=findAsset($('sA').value);$('sAmt').value=ethers.formatUnits(spendable(a),a.decimals);sAv()}
async function doSend(){
  const a=findAsset($('sA').value),to=resolveRecipient($('sTo').value);
  if(!to)return toast('Enter a valid recipient address or contact name','err');
  let amt;try{amt=ethers.parseUnits($('sAmt').value.trim()||'0',a.decimals)}catch{return toast('Invalid amount','err')}
  if(amt<=0n)return toast('Enter an amount','err');
  if(amt>a.bal||(eq(a.addr,S.kavi)&&amt+S.fee>a.bal))return toast('Insufficient balance','err');
  const action=a.addr?{to:a.addr,data:IF_ERC20.encodeFunctionData('transfer',[to,amt]),label:`Send ${a.symbol}`}:{to,value:amt,label:`Send ${a.symbol}`};
  await run(`Send ${$('sAmt').value} ${a.symbol}`,[action],{extra:{recipient:to,token:a.addr||'',amount:String(amt),kind:'send'}});
}

function eip681(assetAddr,amount,dec){
  if(!amount)return S.address;
  let wei;try{wei=ethers.parseUnits(amount,dec)}catch{return S.address}
  if(!assetAddr)return `ethereum:${S.address}@${S.chain}?value=${wei}`;
  return `ethereum:${assetAddr}@${S.chain}/transfer?address=${S.address}&uint256=${wei}`;
}
function openReceive(){
  sheet('Receive',`
    <div class="qr" id="rQr"></div>
    <div class="mono">${S.address}</div>
    <div class="grid2"><button class="btn ghost sm" data-act="copy">Copy</button><button class="btn ghost sm" data-act="shareAddr">Share</button></div>
    <div class="gap"></div>
    <div class="f"><label>Request an amount (optional)</label><div class="grid2"><div class="inp"><select id="rA">${assetOpts('')}</select></div><div class="inp"><input id="rAmt" inputmode="decimal" placeholder="Amount"></div></div></div>
    <div class="note">Only send BNB Chain (BEP-20) assets to this address.</div>`,()=>{
      const paint=()=>{const a=findAsset($('rA').value);const qr=qrcode(0,'M');qr.addData(eip681(a.addr,$('rAmt').value.trim(),a.decimals));qr.make();$('rQr').innerHTML=qr.createSvgTag({cellSize:5,margin:1,scalable:true})};
      $('rA').onchange=paint;$('rAmt').oninput=paint;paint();
    });
}

let swapSlip=Number(store.get('kw_slip')||1),quoteT,lastQuote=null;
function openSwap(from='',to){
  if(!needSigner())return;
  const k=S.tokens.find(t=>eq(t.addr,S.kavi));
  const toSel=to!==undefined?to:(k?k.addr:'');
  sheet('Swap',`
    <div class="f"><label><span>From</span><span id="wAv"></span></label><div class="inp"><select id="wF">${assetOpts(from)}</select></div>
    <div class="inp" style="margin-top:6px"><input id="wAmt" inputmode="decimal" placeholder="0.0"><button class="max" data-act="wMax">MAX</button></div></div>
    <div class="flip"><button data-act="wFlip"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M7 4v16M3 16l4 4 4-4M17 20V4M13 8l4-4 4 4"/></svg></button></div>
    <div class="f"><label>To</label><div class="inp"><select id="wT">${assetOpts(toSel,true)}</select></div>
    <div class="inp" id="wCW" style="margin-top:6px;display:none"><input id="wC" placeholder="Token address 0x…" autocomplete="off"></div></div>
    <div class="card" style="margin:0 0 12px"><div class="kv"><span>You receive</span><b id="wOut">—</b></div><div class="kv"><span>Minimum received</span><b id="wMin">—</b></div><div class="kv"><span>Route</span><b id="wRoute" style="font-size:12px">—</b></div>
    <div class="kv"><span>Slippage</span><div class="chips">${[0.5,1,3,10].map(s=>`<button data-act="slip" data-v="${s}" class="${s===swapSlip?'on':''}">${s}%</button>`).join('')}</div></div></div>
    ${feeNote('swap')}
    <button class="btn" data-act="doSwap">Swap</button>`,()=>{
      ['wF','wT'].forEach(i=>$(i).onchange=()=>{$('wCW').style.display=$('wT').value==='custom'?'flex':'none';wAv();quoteSoon()});
      $('wAmt').oninput=quoteSoon;$('wC').oninput=quoteSoon;wAv();
    });
}
function wAv(){const a=findAsset($('wF').value);$('wAv').textContent='Balance '+fmt(a.bal,a.decimals)}
function wMax(){const a=findAsset($('wF').value);$('wAmt').value=ethers.formatUnits(spendable(a),a.decimals);quoteSoon()}
function wFlip(){const f=$('wF').value,t=$('wT').value;if(t==='custom')return;$('wF').value=t;$('wT').value=f;wAv();quoteSoon()}
function quoteSoon(){clearTimeout(quoteT);quoteT=setTimeout(quote,350)}
async function swapSides(){
  const W=net().wbnb,f=findAsset($('wF').value);
  let toAddr=$('wT').value,toMeta;
  if(toAddr==='custom'){toAddr=$('wC').value.trim();if(!ethers.isAddress(toAddr))return null;toMeta={addr:toAddr,...(await meta(toAddr))}}
  else toMeta=findAsset(toAddr);
  return{f,fromT:f.addr||W,toT:toAddr||W,toMeta,fromBNB:!f.addr,toBNB:!toAddr};
}
async function symOf(a){if(eq(a,net().wbnb))return 'WBNB';try{return (await meta(a)).symbol}catch{return short(a)}}
async function quote(){
  lastQuote=null;$('wOut').textContent='—';$('wMin').textContent='—';$('wRoute').textContent='—';
  try{
    const s=await swapSides();if(!s)return;
    if(eq(s.fromT,s.toT))return;
    const amt=ethers.parseUnits($('wAmt').value.trim()||'0',s.f.decimals);if(amt<=0n)return;
    $('wOut').innerHTML='<span class="spin" style="display:inline-block"></span>';
    const best=await bestOut(amt,s.fromT,s.toT);
    if(!best){$('wOut').textContent='No route';return}
    const min=best.out*BigInt(Math.round((100-swapSlip)*100))/10000n;
    lastQuote={...s,amt,path:best.path,min};
    $('wOut').textContent=`${fmt(best.out,s.toMeta.decimals)} ${s.toMeta.symbol}`;
    $('wMin').textContent=`${fmt(min,s.toMeta.decimals)} ${s.toMeta.symbol}`;
    $('wRoute').textContent=(await Promise.all(best.path.map(symOf))).join(' → ');
  }catch{$('wOut').textContent='—'}
}
async function doSwap(){
  await quote();
  const q=lastQuote;if(!q)return toast('Enter an amount and pick a valid pair','err');
  if(q.amt>q.f.bal)return toast('Insufficient balance','err');
  const fromK=eq(q.f.addr,S.kavi),toK=eq(q.toT,S.kavi);
  if(fromK&&q.amt+S.fee>q.f.bal)return toast('Leave some KAVI for the fee','err');
  const dl=Math.floor(Date.now()/1000)+1200,R=S.routerAddr;
  const actions=[];
  if(q.fromBNB){
    actions.push({to:R,value:q.amt,data:IF_ROUTER.encodeFunctionData('swapExactETHForTokensSupportingFeeOnTransferTokens',[q.min,q.path,S.address,dl]),label:'Swap'});
  }else{
    const al=await new ethers.Contract(q.f.addr,ERC20_ABI,S.rp).allowance(S.address,R).catch(()=>0n);
    if(al<q.amt)actions.push({to:q.f.addr,data:IF_ERC20.encodeFunctionData('approve',[R,q.amt]),label:`Allow ${q.f.symbol} swap`});
    const fn=q.toBNB?'swapExactTokensForETHSupportingFeeOnTransferTokens':'swapExactTokensForTokensSupportingFeeOnTransferTokens';
    actions.push({to:R,data:IF_ROUTER.encodeFunctionData(fn,[q.amt,q.min,q.path,S.address,dl]),label:'Swap'});
  }
  const feeAfter=toK&&S.kaviBal<S.fee;
  const res=await run(`Swap ${$('wAmt').value} ${q.f.symbol} → ${q.toMeta.symbol}`,actions,{feeAfter,extra:{kind:'swap',token:q.f.addr||'',recv:q.toBNB?'':q.toT}});
  if(res?.ok&&!q.toBNB){const l=tokenList();if(!l.some(a=>eq(a,q.toT))){l.push(ethers.getAddress(q.toT));saveTokens(l);refresh()}}
}

function openAddToken(){
  const have=new Set(tokenList().map(a=>a.toLowerCase()));
  const pop=S.chain===56?POPULAR.filter(p=>!have.has(p[0].toLowerCase())):[];
  sheet('Add token',`
    <div class="f"><label>Token contract address</label><div class="inp"><input id="aT" placeholder="0x…" autocomplete="off" autocapitalize="off"><button class="max" data-act="scanInto" data-target="aT">SCAN</button></div></div>
    <div class="card" id="aInfo" style="display:none;margin:0 0 12px"></div>
    <button class="btn" data-act="doAdd">Add token</button>
    ${pop.length?`<div class="sec">Popular on BNB Chain</div>${pop.map(p=>`<div class="drow"><div class="row">${icon(p[1],p[0])}<div class="n"><b>${p[1]}</b><span>${esc(p[2])}</span></div></div><button class="chip" data-act="addPopular" data-a="${p[0]}">Add</button></div>`).join('')}`:''}
    <div class="note" style="margin-top:12px">Adding a token only shows it in your list. It's free and needs no transaction.</div>`,()=>{
      $('aT').oninput=async()=>{
        const a=$('aT').value.trim(),box=$('aInfo');
        if(!ethers.isAddress(a)){box.style.display='none';return}
        box.style.display='block';box.innerHTML='<div class="kv"><span>Looking up…</span></div>';
        const m=await meta(a);
        box.innerHTML=`<div class="kv"><span>Symbol</span><b>${esc(m.symbol)}</b></div><div class="kv"><span>Name</span><b>${esc(m.name)}</b></div><div class="kv"><span>Decimals</span><b>${m.decimals}</b></div>`;
      };
    });
}
async function addTokenAddr(a){
  const l=tokenList();
  if(l.some(t=>eq(t,a)))return false;
  await meta(a);
  l.push(ethers.getAddress(a));saveTokens(l);refresh();return true;
}
async function doAdd(){
  const a=$('aT').value.trim();
  if(!ethers.isAddress(a))return toast('Enter a valid token address','err');
  if(!await addTokenAddr(a))return toast('Token already added','err');
  closeSheet();toast(`${S.meta[a.toLowerCase()].symbol} added`,'ok');
}

const TFS={'1D':{tf:'hour',agg:1,limit:24},'1W':{tf:'hour',agg:4,limit:42},'1M':{tf:'day',agg:1,limit:30},'1Y':{tf:'day',agg:1,limit:365}};
async function geckoPool(token){
  const k=token.toLowerCase();if(S.pools[k]!==undefined)return S.pools[k];
  const j=await httpJson(`${GK}/networks/${net().gecko}/tokens/${k}/pools?page=1`);
  const p=j?.data?.[0]?.attributes?.address||null;S.pools[k]=p;return p;
}
async function geckoOhlcv(token,tfKey){
  const pool=await geckoPool(token);if(!pool)return null;
  const t=TFS[tfKey];
  const j=await httpJson(`${GK}/networks/${net().gecko}/pools/${pool}/ohlcv/${t.tf}?aggregate=${t.agg}&limit=${t.limit}&currency=usd&token=${token.toLowerCase()}`);
  const l=j?.data?.attributes?.ohlcv_list;if(!Array.isArray(l)||!l.length)return null;
  return l.slice().sort((a,b)=>a[0]-b[0]).map(r=>({t:r[0],c:Number(r[4])}));
}
function chartSvg(pts){
  if(!pts||pts.length<2)return '<div class="empty">No chart data</div>';
  const W=400,H=170,vals=pts.map(p=>p.c),mn=Math.min(...vals),mx=Math.max(...vals),rg=mx-mn||mx||1;
  const xy=pts.map((p,i)=>[i/(pts.length-1)*W,8+(1-(p.c-mn)/rg)*(H-24)]);
  const up=vals[vals.length-1]>=vals[0],col=up?'#2ebd85':'#f6465d';
  const line=xy.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><path d="${line} L${W} ${H} L0 ${H}Z" fill="url(#cg)"/><path d="${line}" fill="none" stroke="${col}" stroke-width="2" vector-effect="non-scaling-stroke"/></svg><div class="lg" style="margin-top:4px"><span>Low ${priceFmt(mn)}</span><span>High ${priceFmt(mx)}</span></div>`;
}
async function tokenInfo(addr){
  const isN=!addr;const t=assets().find(x=>eq(x.addr,addr)||(!addr&&!x.addr));
  if(t)return t;
  const m=await meta(addr);
  const bal=await new ethers.Contract(addr,ERC20_ABI,S.rp).balanceOf(S.address).catch(()=>0n);
  return {addr,bal,...m,notAdded:!isN};
}
async function openTokenPage(addr){
  const t=await tokenInfo(addr);
  const key='token:'+(addr||'bnb');
  S.tf=S.tf||'1D';
  const inList=!addr||tokenList().some(a=>eq(a,addr));
  const isK=eq(addr,S.kavi);
  const html=()=>{
    const p=priceUsd(addr),c=change24(addr);
    const acts=getAct().filter(a=>!a.aux&&(eq(a.token??'',addr)||(!addr&&a.token==='')));
    return `
    <div style="display:flex;align-items:center;gap:12px;margin:4px 0 8px">${addr?icon(t.symbol,addr,44):icon('B','',44)}<div><div class="big2" id="tpPrice">${priceFmt(p)}</div><div id="tpCh" class="${c===null?'sub':c>=0?'up':'dn'}" style="font-weight:600;font-size:13px">${chFmt(c)} · 24h</div></div></div>
    ${net().gecko?`<div id="chartBox" style="min-height:190px"><div class="empty"><span class="spin" style="display:inline-block"></span></div></div><div class="tf">${Object.keys(TFS).map(k=>`<button data-act="tf" data-v="${k}" data-addr="${addr}" class="${S.tf===k?'on':''}">${k}</button>`).join('')}</div>`:''}
    <div class="card" style="margin:0 0 12px"><div class="kv"><span>Your balance</span><b>${mask(fmt(t.bal,t.decimals))} ${esc(t.symbol)}</b></div><div class="kv"><span>Value</span><b>${mask(valOf(t.bal,t.decimals,addr))||'—'}</b></div></div>
    <div class="bt"><button class="btn sm" data-act="send" data-addr="${addr}">Send</button><button class="btn sm ghost" data-act="receive">Receive</button><button class="btn sm ghost" data-act="swapFrom" data-addr="${addr}">Swap</button></div>
    ${!inList?`<button class="btn ghost sm" data-act="addPopular" data-a="${addr}">Add ${esc(t.symbol)} to wallet</button><div class="gap"></div>`:''}
    ${addr?`<div class="gt">Token info</div><div class="grp"><div class="li"><div class="lt"><b>Name</b></div><div class="lv">${esc(t.name)}</div></div><div class="li"><div class="lt"><b>Contract</b></div><a class="lv" href="${net().explorer}/token/${addr}" target="_blank" rel="noopener">${short(addr)}</a></div><div class="li"><div class="lt"><b>Decimals</b></div><div class="lv">${t.decimals}</div></div><button class="li" data-act="copyText" data-t="${addr}"><div class="lt"><b>Copy contract address</b></div></button></div>`:''}
    <div class="gt">Recent activity</div>${acts.length?acts.slice(0,10).map(histRow).join(''):'<div class="empty">No activity yet</div>'}
    ${addr&&!isK&&inList?`<div class="gap"></div><button class="btn sm danger" data-act="doRemove" data-addr="${addr}">Hide token</button>`:''}`;
  };
  page(t.symbol,html,{key,onShow:()=>{loadChart(addr);if(net().gecko)loadGecko([addr||net().wbnb]).then(()=>{if(topPage()?.key===key&&$('tpPrice')){const c=change24(addr);$('tpPrice').textContent=priceFmt(priceUsd(addr));$('tpCh').textContent=chFmt(c)+' · 24h';$('tpCh').className=c===null?'sub':c>=0?'up':'dn'}}).catch(()=>{})}});
}
async function loadChart(addr){
  const box=$('chartBox');if(!box)return;
  const tf=S.tf;
  try{
    const pts=await geckoOhlcv(addr||net().wbnb,tf);
    if($('chartBox')&&S.tf===tf)$('chartBox').innerHTML=chartSvg(pts);
  }catch{if($('chartBox'))$('chartBox').innerHTML='<div class="empty">Chart unavailable right now</div>'}
}

function nftKey(){return wkey('nfts')}
function nftList(){return store.json(nftKey(),[])}
function saveNfts(l){store.put(nftKey(),l)}
function ipfs(u){if(!u)return u;u=String(u);if(u.startsWith('ipfs://'))return 'https://ipfs.io/ipfs/'+u.slice(7).replace(/^ipfs\//,'');if(u.startsWith('ar://'))return 'https://arweave.net/'+u.slice(5);return u}
async function nftMeta(uri){
  uri=ipfs(uri);
  if(uri.startsWith('data:application/json;base64,'))return JSON.parse(TD.decode(ethers.decodeBase64(uri.slice(29))));
  if(uri.startsWith('data:application/json'))return JSON.parse(decodeURIComponent(uri.slice(uri.indexOf(',')+1)));
  if(/^https?:/.test(uri))return httpJson(uri);
  return {};
}
function renderNfts(){
  const l=nftList();
  $('nftList').innerHTML=l.length?`<div class="nftg">${l.map((n,i)=>`<button class="nft" data-act="nftOpen" data-i="${i}"><div class="im">${n.image?`<img src="${esc(ipfs(n.image))}" alt="" loading="lazy" onerror="this.remove()">`:'No image'}</div><b>${esc(n.name||('#'+n.id))}</b><span>${esc(n.col||short(n.c))}${n.std==='1155'?' · ×'+esc(n.amount||'1'):''}</span></button>`).join('')}</div>`:'<div class="empty">No NFTs yet. Add one with its contract address and token ID.</div>';
}
function openAddNft(){
  sheet('Add NFT',`
    <div class="f"><label>NFT contract address</label><div class="inp"><input id="nC" placeholder="0x…" autocomplete="off" autocapitalize="off"></div></div>
    <div class="f"><label>Token ID</label><div class="inp"><input id="nI" inputmode="numeric" placeholder="1234"></div></div>
    <button class="btn" data-act="doAddNft">Add NFT</button>`);
}
async function doAddNft(){
  const c=$('nC').value.trim(),idS=$('nI').value.trim();
  if(!ethers.isAddress(c))return toast('Enter a valid contract address','err');
  let id;try{id=BigInt(idS)}catch{return toast('Enter a valid token ID','err')}
  const btn=S.clicked;btn.disabled=true;btn.innerHTML='<span class="spin"></span>Checking';
  try{
    const nc=new ethers.Contract(c,NFT_ABI,S.rp);
    const [is721,is1155]=await Promise.all([nc.supportsInterface('0x80ac58cd').catch(()=>false),nc.supportsInterface('0xd9b67a26').catch(()=>false)]);
    if(!is721&&!is1155)throw new Error('This is not an ERC-721 or ERC-1155 NFT contract');
    let amount='1',uri='';
    if(is721){const o=await nc.ownerOf(id);if(!eq(o,S.address))throw new Error('This NFT is not owned by your wallet');uri=await nc.tokenURI(id).catch(()=>'')}
    else{const b=await nc['balanceOf(address,uint256)'](S.address,id);if(b===0n)throw new Error('This NFT is not owned by your wallet');amount=b.toString();uri=(await nc.uri(id).catch(()=>'')).replace('{id}',id.toString(16).padStart(64,'0'))}
    const col=await nc.name().catch(()=>'');
    let m={};try{m=uri?await nftMeta(uri):{}}catch{}
    const l=nftList().filter(n=>!(eq(n.c,c)&&n.id===id.toString()));
    l.unshift({c:ethers.getAddress(c),id:id.toString(),std:is721?'721':'1155',amount,name:m.name||`${col||'NFT'} #${id}`,image:m.image||m.image_url||'',desc:m.description||'',col});
    saveNfts(l);closeSheet();renderNfts();toast('NFT added','ok');
  }catch(e){toast(errMsg(e),'err')}
  finally{if(btn.isConnected){btn.disabled=false;btn.innerHTML='Add NFT'}}
}
function openNft(i){
  const n=nftList()[i];if(!n)return;
  page(n.name||'NFT',`
    <div class="nftbig">${n.image?`<img src="${esc(ipfs(n.image))}" alt="">`:'No image'}</div>
    ${n.desc?`<div class="note">${esc(n.desc).slice(0,600)}</div>`:''}
    <div class="grp"><div class="li"><div class="lt"><b>Collection</b></div><div class="lv">${esc(n.col||'—')}</div></div><div class="li"><div class="lt"><b>Token ID</b></div><div class="lv">${esc(n.id.length>14?n.id.slice(0,12)+'…':n.id)}</div></div><div class="li"><div class="lt"><b>Standard</b></div><div class="lv">ERC-${n.std}${n.std==='1155'?' · owned ×'+esc(n.amount):''}</div></div><div class="li"><div class="lt"><b>Contract</b></div><a class="lv" href="${net().explorer}/token/${n.c}?a=${n.id}" target="_blank" rel="noopener">${short(n.c)}</a></div></div>
    <button class="btn" data-act="nftSend" data-i="${i}">Send NFT</button><div class="gap"></div>
    <button class="btn ghost sm" data-act="nftRemove" data-i="${i}">Hide from list</button>`);
}
function openNftSend(i){
  if(!needSigner())return;
  const n=nftList()[i];
  sheet('Send NFT',`
    <div class="note">${esc(n.name)}</div>
    ${recipientBox('nTo')}
    ${n.std==='1155'?`<div class="f"><label>Amount (you own ${esc(n.amount)})</label><div class="inp"><input id="nAmt" inputmode="numeric" value="1"></div></div>`:''}
    ${feeNote()}
    <button class="btn" data-act="doNftSend" data-i="${i}">Send</button>`,()=>wireRecipient('nTo'));
}
async function doNftSend(i){
  const n=nftList()[i];const to=resolveRecipient($('nTo').value);
  if(!to)return toast('Enter a valid recipient','err');
  let data;
  if(n.std==='721')data=IF_NFT.encodeFunctionData('safeTransferFrom(address,address,uint256)',[S.address,to,BigInt(n.id)]);
  else{let a;try{a=BigInt($('nAmt').value.trim())}catch{return toast('Invalid amount','err')}if(a<=0n||a>BigInt(n.amount))return toast('Invalid amount','err');data=IF_NFT.encodeFunctionData('safeTransferFrom(address,address,uint256,uint256,bytes)',[S.address,to,BigInt(n.id),a,'0x']);n.left=(BigInt(n.amount)-a).toString()}
  const res=await run(`Send NFT ${n.name}`,[{to:n.c,data,label:'Send NFT'}],{extra:{recipient:to,kind:'nft'}});
  if(res?.ok){const l=nftList();if(n.std==='721'||n.left==='0')l.splice(i,1);else l[i].amount=n.left;saveNfts(l);renderNfts();closePage()}
}

function spenderName(s){if(eq(s,S.hubAddr))return 'KaviHub (KAVI fee)';if(eq(s,S.routerAddr))return 'PancakeSwap Router';const c=nameOf(s);return c||short(s)}
async function openApprovals(){
  const key='approvals';
  const html=()=>`<div class="note">Token approvals let a contract spend your tokens. Revoke ones you no longer use. Revoking is a transaction and includes the KAVI fee.</div>
    <div id="apList"><div class="empty"><span class="spin" style="display:inline-block"></span></div></div>
    <div class="gt">Check any approval</div>
    <div class="f"><div class="inp"><input id="apT" placeholder="Token address 0x…" autocomplete="off"></div></div>
    <div class="f"><div class="inp"><input id="apS" placeholder="Spender address 0x…" autocomplete="off"></div></div>
    <button class="btn ghost sm" data-act="apCheck">Check allowance</button>`;
  page('Approvals',html,{key,onShow:loadApprovals});
}
async function loadApprovals(){
  const l=store.json(wkey('appr'),[]);
  const rows=await Promise.all(l.map(async a=>{try{const m=await meta(a.token);const v=await new ethers.Contract(a.token,ERC20_ABI,S.rp).allowance(S.address,a.spender);return {...a,m,v}}catch{return null}}));
  const live=rows.filter(r=>r&&r.v>0n);
  if(!$('apList'))return;
  $('apList').innerHTML=live.length?live.map(r=>`<div class="drow"><div class="row">${icon(r.m.symbol,r.token)}<div class="n"><b>${esc(r.m.symbol)} → ${esc(spenderName(r.spender))}</b><span>${r.v>=MAXU?'Unlimited':fmt(r.v,r.m.decimals)+' '+esc(r.m.symbol)}</span></div></div><button class="chip" data-act="revoke" data-t="${r.token}" data-s="${r.spender}">Revoke</button></div>`).join(''):'<div class="empty">No active approvals made from Kavi Wallet</div>';
}
async function apCheck(){
  const t=$('apT').value.trim(),s=$('apS').value.trim();
  if(!ethers.isAddress(t)||!ethers.isAddress(s))return toast('Enter valid token and spender addresses','err');
  const m=await meta(t);const v=await new ethers.Contract(t,ERC20_ABI,S.rp).allowance(S.address,s).catch(()=>0n);
  if(v>0n){const l=store.json(wkey('appr'),[]);if(!l.some(x=>eq(x.token,t)&&eq(x.spender,s))){l.unshift({token:ethers.getAddress(t),spender:ethers.getAddress(s),ts:Date.now()});store.put(wkey('appr'),l)}loadApprovals()}
  toast(v>0n?`Allowance: ${v>=MAXU?'Unlimited':fmt(v,m.decimals)} ${m.symbol}`:'No allowance (0)',v>0n?'':'ok');
}
async function revoke(t,s){
  const m=await meta(t);
  const res=await run(`Revoke ${m.symbol} approval`,[{to:t,data:IF_ERC20.encodeFunctionData('approve',[s,0n]),label:'Revoke approval'}],{extra:{kind:'revoke'}});
  if(res?.ok)loadApprovals();
}

function histRow(a){
  const st=a.status||'pending';
  return `<button class="row" data-act="histOpen" data-h="${a.hash}"><div class="ic" style="background:var(--card2);color:${st==='pending'?'var(--acc)':'var(--mut)'}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${a.kind==='swap'?'<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>':'<path d="M7 17 17 7M8 7h9v9"/>'}</svg></div><div class="n"><b>${esc(a.label)}</b><span>${new Date(a.ts).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}${a.recipient?' · to '+esc(nameOf(a.recipient)||short(a.recipient)):''}</span></div><span class="st ${st}">${st}</span></button>`;
}
function openHistory(){
  S.histTab=S.histTab||'app';
  const key='history';
  const html=()=>{
    const l=getAct().filter(a=>!a.aux||a.status==='pending'||a.status==='failed');
    const pend=l.filter(a=>a.status==='pending').length;
    return `<div class="seg"><button data-act="histTab" data-v="app" class="${S.histTab==='app'?'on':''}">Kavi Wallet${pend?` · ${pend}⏳`:''}</button><button data-act="histTab" data-v="chain" class="${S.histTab==='chain'?'on':''}">All on-chain</button></div>
    ${S.histTab==='app'?(l.length?l.map(histRow).join(''):'<div class="empty">No transactions yet</div>'):'<div id="chainHist"><div class="empty"><span class="spin" style="display:inline-block"></span></div></div>'}
    <a class="add" href="${net().explorer}/address/${S.address}" target="_blank" rel="noopener">View on ${hostOf(net().explorer)}</a>`;
  };
  page('History',html,{key,onShow:()=>{if(S.histTab==='chain')loadChainHist()}});
}
async function loadChainHist(){
  const box=$('chainHist');if(!box)return;
  const k=store.get('kw_scankey');
  if(!k){box.innerHTML=`<div class="note">To see every transaction for this address (including ones made outside Kavi Wallet), add a free Etherscan API key in <b>Me → Explorer API key</b>.</div><button class="btn ghost sm" data-act="scanKey">Add API key</button>`;return}
  try{
    const base=`https://api.etherscan.io/v2/api?chainid=${S.chain}&module=account&address=${S.address}&page=1&offset=40&sort=desc&apikey=${encodeURIComponent(k)}`;
    const [a,b]=await Promise.all([httpJson(base+'&action=txlist'),httpJson(base+'&action=tokentx')]);
    if(a.status==='0'&&typeof a.result==='string'&&!/No transactions/i.test(a.message+a.result))throw new Error(a.result);
    const items=[];
    for(const t of Array.isArray(a.result)?a.result:[])items.push({h:t.hash,ts:+t.timeStamp,in:eq(t.to,S.address),other:eq(t.to,S.address)?t.from:t.to,amt:t.value!=='0'?`${fmt(BigInt(t.value))} ${net().sym}`:(t.functionName||'').split('(')[0]||'Contract call',err:t.isError==='1'});
    for(const t of Array.isArray(b.result)?b.result:[])items.push({h:t.hash,ts:+t.timeStamp,in:eq(t.to,S.address),other:eq(t.to,S.address)?t.from:t.to,amt:`${fmt(BigInt(t.value),Number(t.tokenDecimal)||18)} ${esc(t.tokenSymbol)}`});
    items.sort((x,y)=>y.ts-x.ts);
    if(!$('chainHist'))return;
    $('chainHist').innerHTML=items.length?items.slice(0,60).map(x=>`<a class="row" href="${net().explorer}/tx/${x.h}" target="_blank" rel="noopener"><div class="ic" style="background:var(--card2);color:${x.in?'var(--ok)':'var(--mut)'}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="${x.in?'M17 7 7 17M16 17H7V8':'M7 17 17 7M8 7h9v9'}"/></svg></div><div class="n"><b style="color:var(--text)">${x.in?'Received':'Sent'} ${x.amt}</b><span>${new Date(x.ts*1000).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})} · ${x.in?'from':'to'} ${esc(nameOf(x.other)||short(x.other))}</span></div>${x.err?'<span class="st failed">failed</span>':''}</a>`).join(''):'<div class="empty">No transactions found</div>';
  }catch(e){if($('chainHist'))$('chainHist').innerHTML=`<div class="note"><span class="warn">Could not load history: ${esc(e.message)}</span></div>`}
}
function openHistItem(h){
  const a=getAct().find(x=>x.hash===h);if(!a)return;
  const pend=a.status==='pending';
  sheet(esc(a.label),`
    <div class="card" style="margin:0 0 12px">
      <div class="kv"><span>Status</span><b><span class="st ${a.status}">${a.status}</span></b></div>
      <div class="kv"><span>Time</span><b>${new Date(a.ts).toLocaleString('en-US')}</b></div>
      ${a.recipient?`<div class="kv"><span>To</span><b>${esc(nameOf(a.recipient)||short(a.recipient))}</b></div>`:''}
      <div class="kv"><span>Nonce</span><b>${a.nonce??'—'}</b></div>
      ${a.gasPrice?`<div class="kv"><span>Gas price</span><b>${Number(ethers.formatUnits(BigInt(a.gasPrice),'gwei')).toFixed(3)} Gwei</b></div>`:''}
      <div class="kv"><span>Hash</span><b><a href="${net().explorer}/tx/${a.hash}" target="_blank" rel="noopener">${short(a.hash)}</a></b></div>
    </div>
    ${pend&&!S.watch?`<div class="note">This transaction hasn't confirmed yet. You can pay a higher network fee to speed it up, or cancel it (a cancel also needs network gas).</div><div class="grid2"><button class="btn ghost" data-act="txCancel" data-h="${a.hash}">Cancel</button><button class="btn" data-act="txSpeed" data-h="${a.hash}">Speed up</button></div>`:''}
    ${a.recipient&&!contacts().some(c=>eq(c.address,a.recipient))&&!walletsAll().some(w=>eq(w.address,a.recipient))?`<div class="gap"></div><button class="btn ghost sm" data-act="saveContact" data-a="${a.recipient}">Save recipient to address book</button>`:''}`);
}
async function replaceTx(h,cancel){
  if(!needSigner())return;
  const a=getAct().find(x=>x.hash===h);if(!a)return;
  const btn=S.clicked;btn.disabled=true;btn.innerHTML='<span class="spin"></span>Sending';
  try{
    const rc=await S.rp.getTransactionReceipt(h);if(rc){finishAct(h,rc);closeSheet();return toast('Already confirmed','ok')}
    const cur=await currentGasPrice();
    let gp=BigInt(a.gasPrice||0)*13n/10n+1n;if(gp<cur*11n/10n)gp=cur*11n/10n;
    const req=cancel?{to:S.address,value:0n,data:'0x',nonce:a.nonce,gasLimit:21000n,gasPrice:gp,type:0,chainId:S.chain}:{to:a.to,value:BigInt(a.value||0),data:a.data||'0x',nonce:a.nonce,gasLimit:BigInt(a.gasLimit||300000),gasPrice:gp,type:0,chainId:S.chain};
    const tx=await S.signer.sendTransaction(req);
    setAct(h,{status:'replaced'});
    putAct({hash:tx.hash,label:cancel?`Cancel: ${a.label}`:a.label+' (sped up)',ts:Date.now(),status:'pending',nonce:a.nonce,to:req.to,value:String(req.value),data:req.data,gasPrice:String(gp),gasLimit:String(req.gasLimit),kind:a.kind,token:a.token,recipient:cancel?undefined:a.recipient});
    closeSheet();toast(cancel?'Cancel sent':'Speed-up sent');
    const r2=await waitTx(tx.hash,180000);finishAct(tx.hash,r2);
    if(r2)toast(r2.status===1?(cancel?'Transaction cancelled':'Transaction confirmed'):'Transaction failed',r2.status===1?'ok':'err');
    refresh();
  }catch(e){toast(errMsg(e),'err')}
  finally{if(btn.isConnected){btn.disabled=false;btn.innerHTML=cancel?'Cancel':'Speed up'}}
}

function openBatch(){
  if(!needSigner())return;
  page('Batch send',`
    <div class="f"><label>Asset</label><div class="inp"><select id="bA">${assetOpts('')}</select></div></div>
    <div class="f"><label>Recipients — one per line: address, amount</label><div class="inp"><textarea id="bL" style="min-height:150px" placeholder="0xabc…, 1.5&#10;0xdef…, 2"></textarea></div></div>
    <div id="bSum" class="card" style="margin:0 0 12px;display:none"></div>
    ${feeNote()}
    <button class="btn" data-act="doBatch">Review &amp; send</button>`,{onShow:()=>{$('bL').oninput=batchSum;$('bA').onchange=batchSum}});
}
function parseBatch(){
  const a=findAsset($('bA').value);const out=[],bad=[];
  $('bL').value.split('\n').map(x=>x.trim()).filter(Boolean).forEach((line,i)=>{
    const m=line.split(/[\s,;]+/).filter(Boolean);
    const to=m[0]&&resolveRecipient(m[0]);let amt=null;try{amt=ethers.parseUnits(m[1]||'',a.decimals)}catch{}
    if(!to||!amt||amt<=0n)bad.push(i+1);else out.push({to,amt,raw:m[1]});
  });
  return {a,out,bad,total:out.reduce((s,x)=>s+x.amt,0n)};
}
function batchSum(){
  const {a,out,bad,total}=parseBatch();const box=$('bSum');
  if(!out.length&&!bad.length){box.style.display='none';return}
  box.style.display='block';
  box.innerHTML=`<div class="kv"><span>Recipients</span><b>${out.length}</b></div><div class="kv"><span>Total</span><b>${fmt(total,a.decimals)} ${esc(a.symbol)}</b></div><div class="kv"><span>KAVI fees</span><b>${out.length} × ${fmt(S.fee,kaviMeta().decimals)} KAVI</b></div>${bad.length?`<div class="kv"><span class="warn">Invalid lines</span><b class="warn">${bad.join(', ')}</b></div>`:''}`;
}
async function doBatch(){
  const {a,out,bad,total}=parseBatch();
  if(bad.length)return toast(`Fix invalid lines: ${bad.join(', ')}`,'err');
  if(!out.length)return toast('Add at least one recipient','err');
  if(total>a.bal)return toast('Insufficient balance','err');
  if(S.fee&&S.kaviBal<S.fee*BigInt(out.length)+(eq(a.addr,S.kavi)?total:0n))return toast('Not enough KAVI for all the fees','err');
  const btn=S.clicked;btn.disabled=true;
  let done=0;
  try{
    for(const r of out){
      btn.innerHTML=`<span class="spin"></span>Sending ${done+1} of ${out.length}`;
      const action=a.addr?{to:a.addr,data:IF_ERC20.encodeFunctionData('transfer',[r.to,r.amt]),label:`Send ${a.symbol}`}:{to:r.to,value:r.amt,label:`Send ${a.symbol}`};
      const res=await txFlow([action],{label:`Batch ${done+1}/${out.length}: ${r.raw} ${a.symbol}`,extra:{recipient:r.to,token:a.addr||'',kind:'send'}});
      if(!res?.ok)throw new Error(`Transfer ${done+1} failed`);
      done++;await refresh();
    }
    toast(`Sent to ${done} recipients`,'ok');closePage();
  }catch(e){toast(`${done} of ${out.length} sent. ${errMsg(e)}`,'err')}
  finally{if(btn.isConnected){btn.disabled=false;btn.innerHTML='Review &amp; send'}}
}

function openSignTool(){
  if(!needSigner())return;
  page('Sign message',`<div class="f"><label>Message</label><div class="inp"><textarea id="smT" style="min-height:120px"></textarea></div></div><button class="btn" data-act="doSignTool">Sign</button><div id="smOut" style="margin-top:12px"></div>`);
}
async function doSignTool(){
  const m=$('smT').value;if(!m)return toast('Type a message','err');
  const sig=await S.wallet.signMessage(m);
  $('smOut').innerHTML=`<div class="sub" style="margin-bottom:6px">Signature</div><div class="mono2">${sig}</div><button class="btn ghost sm" data-act="copyText" data-t="${sig}">Copy signature</button>`;
}
function openVerifyTool(){
  page('Verify message',`<div class="f"><label>Message</label><div class="inp"><textarea id="vmT"></textarea></div></div><div class="f"><label>Signature</label><div class="inp"><textarea id="vmS" placeholder="0x…"></textarea></div></div><div class="f"><label>Expected address (optional)</label><div class="inp"><input id="vmA" placeholder="0x…"></div></div><button class="btn" data-act="doVerifyTool">Verify</button><div id="vmOut" style="margin-top:12px"></div>`);
}
function doVerifyTool(){
  try{
    const a=ethers.verifyMessage($('vmT').value,$('vmS').value.trim());const exp=$('vmA').value.trim();
    $('vmOut').innerHTML=exp?(eq(a,exp)?`<div class="okbox">Valid. Signed by ${a}</div>`:`<div class="warnbox">Signed by ${a}, which does not match the expected address.</div>`):`<div class="okbox">Signed by ${a}</div>`;
  }catch{$('vmOut').innerHTML='<div class="warnbox">Invalid signature</div>'}
}
function openTokenCheck(){
  page('Token check',`<div class="note">Check a token contract before you buy or approve it.</div><div class="f"><div class="inp"><input id="tcA" placeholder="Token address 0x…" autocomplete="off"><button class="max" data-act="scanInto" data-target="tcA">SCAN</button></div></div><button class="btn" data-act="doTokenCheck">Check</button><div id="tcOut" style="margin-top:12px"></div>`);
}
async function doTokenCheck(){
  const a=$('tcA').value.trim();if(!ethers.isAddress(a))return toast('Enter a valid address','err');
  const out=$('tcOut');out.innerHTML='<div class="empty"><span class="spin" style="display:inline-block"></span></div>';
  const warn=[],good=[];
  const code=await S.rp.getCode(a).catch(()=>'0x');
  if(code==='0x'){out.innerHTML='<div class="warnbox">This address is not a contract. It is not a token.</div>';return}
  const c=new ethers.Contract(a,ERC20_ABI,S.rp);
  const [sym,name,dec,sup,own]=await Promise.all([c.symbol().catch(()=>null),c.name().catch(()=>null),c.decimals().catch(()=>null),c.totalSupply().catch(()=>null),c.owner().catch(()=>undefined)]);
  if(sym===null||dec===null){out.innerHTML='<div class="warnbox">This contract does not behave like a standard BEP-20 token.</div>';return}
  if(sup===null)warn.push('No totalSupply() function. This is not a fully standard token.');
  const d=Number(dec);
  if(own===undefined)good.push('No owner() function found');
  else if(own===ethers.ZeroAddress)good.push('Ownership renounced');
  else warn.push(`Contract has an owner (${short(own)}) who may be able to change it`);
  let p=null;try{p=await priceOf(a,d)}catch{}
  if(p===null)warn.push('No PancakeSwap liquidity found. You may not be able to sell it.');else good.push('Tradable on PancakeSwap');
  const known=POPULAR.find(x=>eq(x[0],a))||eq(a,S.kavi);
  if(known)good.push('Listed in Kavi Wallet\'s known tokens');
  const clash=POPULAR.find(x=>x[1].toLowerCase()===String(sym).toLowerCase()&&!eq(x[0],a));
  if(clash)warn.push(`Uses the symbol ${sym} but is NOT the well-known ${sym} contract. Possible fake.`);
  out.innerHTML=`<div class="card" style="margin:0 0 12px"><div class="kv"><span>Name</span><b>${esc(name)}</b></div><div class="kv"><span>Symbol</span><b>${esc(sym)}</b></div><div class="kv"><span>Decimals</span><b>${d}</b></div><div class="kv"><span>Total supply</span><b>${sup===null?'—':fmt(sup,d)}</b></div><div class="kv"><span>Price</span><b>${p!==null?priceFmt(p):'—'}</b></div></div>${warn.map(w=>`<div class="warnbox">⚠ ${esc(w)}</div>`).join('')}${good.map(w=>`<div class="okbox">✓ ${esc(w)}</div>`).join('')}<div class="sub">This check is basic and can't prove a token is safe.</div>`;
}

function openContacts(){
  page('Address book',()=>{const l=contacts();return `${l.length?`<div class="grp">${l.map((c,i)=>`<button class="li" data-act="contactEdit" data-i="${i}"><div class="lic">${esc(c.name.slice(0,1).toUpperCase())}</div><div class="lt"><b>${esc(c.name)}</b><span>${c.address}</span></div></button>`).join('')}</div>`:'<div class="empty">No contacts yet</div>'}<button class="btn" data-act="contactEdit" data-i="-1">Add contact</button>`},{key:'contacts'});
}
function contactEdit(i,addr=''){
  const c=i>=0?contacts()[i]:{name:'',address:addr};
  sheet(i>=0?'Edit contact':'New contact',`<div class="f"><label>Name</label><div class="inp"><input id="cN" value="${esc(c.name)}" maxlength="30"></div></div><div class="f"><label>Address</label><div class="inp"><input id="cA" value="${esc(c.address)}" autocomplete="off" autocapitalize="off"><button class="max" data-act="scanInto" data-target="cA">SCAN</button></div></div><button class="btn" data-act="contactSave" data-i="${i}">Save</button>${i>=0?'<div class="gap"></div><button class="btn danger sm" data-act="contactDel" data-i="'+i+'">Delete</button>':''}`);
}
function contactSave(i){
  const n=$('cN').value.trim(),a=$('cA').value.trim();
  if(!n)return toast('Enter a name','err');if(!ethers.isAddress(a))return toast('Enter a valid address','err');
  const l=contacts();const rec={name:n,address:ethers.getAddress(a)};
  if(i>=0)l[i]=rec;else{if(l.some(x=>eq(x.address,a)))return toast('Address already saved','err');l.push(rec)}
  l.sort((x,y)=>x.name.localeCompare(y.name));store.put('kw_contacts',l);closeSheet();repaintIf('contacts');toast('Contact saved','ok');
}

function marketItems(){
  const map=new Map();
  const add=(a,sym,name)=>{const k=a.toLowerCase();if(!map.has(k))map.set(k,{addr:a,sym,name})};
  if(S.kavi)add(S.kavi,kaviMeta().symbol,'Kavi');
  add(net().wbnb,'BNB','BNB');
  if(S.chain===56)POPULAR.forEach(p=>add(p[0],p[1],p[2]));
  S.tokens.forEach(t=>add(t.addr,t.symbol,t.name));
  if(S.mExtra)add(S.mExtra.addr,S.mExtra.sym,S.mExtra.name);
  return [...map.values()];
}
function renderMarket(){
  const q=($('mq').value||'').trim().toLowerCase();
  const items=marketItems().filter(x=>!q||x.sym.toLowerCase().includes(q)||x.name.toLowerCase().includes(q)||x.addr.toLowerCase()===q);
  $('mList').innerHTML=items.length?items.map(x=>{
    const isB=eq(x.addr,net().wbnb);const p=priceUsd(isB?'':x.addr),c=change24(isB?'':x.addr);
    return `<button class="mrow" data-act="tokenPage" data-addr="${isB?'':x.addr}"><div class="nm">${isB?icon('B','',34):icon(x.sym,x.addr,34)}<div style="min-width:0"><b>${esc(x.sym)}</b><span>${esc(x.name)}</span></div></div><div class="pr">${priceFmt(p)}</div><div class="chg ${c===null?'na':c>=0?'up':'dn'}">${chFmt(c)}</div></button>`}).join(''):`<div class="empty">No tokens found${ethers.isAddress(q)?'':'. Paste a token address to look it up.'}</div>`;
  $('mSrc').textContent=net().gecko?'Prices: GeckoTerminal & PancakeSwap':'';
}
async function loadMarket(force){
  renderMarket();
  const items=marketItems();
  await Promise.all(items.filter(x=>!(priceKey(x.addr) in S.prices)&&!eq(x.addr,net().wbnb)).map(async x=>{try{const m=await meta(x.addr);S.prices[priceKey(x.addr)]=await priceOf(x.addr,m.decimals)}catch{}}));
  renderMarket();
  try{await loadGecko(items.map(x=>x.addr),force);renderMarket()}catch{}
}
async function marketSearch(){
  const q=$('mq').value.trim();
  if(ethers.isAddress(q)){try{const m=await meta(q);S.mExtra={addr:ethers.getAddress(q),sym:m.symbol,name:m.name};await loadMarket()}catch{}}
  renderMarket();
}

const DAPPS=[
  {name:'Kavi Ecosystem',url:'https://kaviecosystem.github.io/newkaviecosystem/',cat:'Kavi',desc:'Official Kavi ecosystem dApp'},
  {name:'PancakeSwap',url:'https://pancakeswap.finance',cat:'Exchange',desc:'Swap, farm and earn on BNB Chain',icon:'https://safe-transaction-assets.safe.global/safe_apps/91/icon.png'},
  {name:'1inch',url:'https://1inch.com/swap',cat:'Exchange',desc:'Swap aggregator with the best rates',icon:'https://safe-transaction-assets.safe.global/safe_apps/cd741cc7-a093-4c0a-8f4d-0be5f5256884/icon.png'},
  {name:'KyberSwap',url:'https://kyberswap.com/',cat:'Exchange',desc:'Fast, efficient trading and earning',icon:'https://safe-transaction-assets.safe.global/safe_apps/40033adc-165c-4b89-bf70-b31384704ce8/icon.png'},
  {name:'Sushi',url:'https://www.sushi.com/',cat:'Exchange',desc:'Swap, earn, lend and borrow',icon:'https://safe-transaction-assets.safe.global/safe_apps/35/icon.png'},
  {name:'CoW Swap',url:'https://swap.cow.fi',cat:'Exchange',desc:'Best prices with MEV protection',icon:'https://safe-transaction-assets.safe.global/safe_apps/e0ecb7c3-93c1-4598-b9ee-c24d6a798b40/icon.png'},
  {name:'Venus',url:'https://app.venus.io/',cat:'Earn',desc:'Lend and borrow crypto',icon:'https://safe-transaction-assets.safe.global/safe_apps/f586f39e-71ac-4772-b988-2bde27edfdeb/icon.png'},
  {name:'Pendle',url:'https://app.pendle.finance/',cat:'Earn',desc:'Trade and fix your yield',icon:'https://safe-transaction-assets.safe.global/safe_apps/cbc8f430-40c3-4f19-9f1a-3e8200608ef6/icon.png'},
  {name:'Lagoon',url:'https://app.lagoon.finance/',cat:'Earn',desc:'Managed yield vaults',icon:'https://safe-transaction-assets.safe.global/safe_apps/857018a3-758e-4ad1-8d48-dd5f1aac8ab8/icon.png'},
  {name:'Jumper',url:'https://jumper.xyz',cat:'Bridge',desc:'Bridge and swap across chains',icon:'https://safe-transaction-assets.safe.global/safe_apps/155/icon.png'},
  {name:'Squid',url:'https://app.squidrouter.com',cat:'Bridge',desc:'Cross-chain swaps in one click',icon:'https://safe-transaction-assets.safe.global/safe_apps/121/icon.png'},
  {name:'Rango',url:'https://app.rango.exchange/',cat:'Bridge',desc:'Cross-chain DEX and bridge aggregator',icon:'https://safe-transaction-assets.safe.global/safe_apps/49be089d-fb24-4790-a033-dfcafd1964e3/icon.png'},
  {name:'Sablier',url:'https://app.sablier.com/',cat:'Payments',desc:'Token streaming, vesting and airdrops',icon:'https://safe-transaction-assets.safe.global/safe_apps/141/icon.png'},
  {name:'Superfluid',url:'https://app.superfluid.org',cat:'Payments',desc:'Stream money every second',icon:'https://safe-transaction-assets.safe.global/safe_apps/3ee85376-cff1-497a-a9d8-51c0e5234c6e/icon.png'},
  {name:'Revoke.cash',url:'https://revoke.cash/',cat:'Tools',desc:'Check and revoke token approvals',icon:'https://safe-transaction-assets.safe.global/safe_apps/88/icon.png'},
  {name:'Snapshot',url:'https://snapshot.org',cat:'Tools',desc:'Vote on DAO proposals',icon:'https://safe-transaction-assets.safe.global/safe_apps/61/icon.png'}
];
const CATS=['All','Kavi','Exchange','Earn','Bridge','Payments','Tools'];
function dappByUrl(u){const h=hostOf(u);return DAPPS.find(d=>hostOf(d.url)===h&&(d.cat!=='Kavi'||String(u).includes('/newkaviecosystem')))||DAPPS.find(d=>hostOf(d.url)===h)}
function dappIcon(d,size=36){
  const name=d.name||'?',c=d.cat==='Kavi'?'#f0b90b':COLORS[name.charCodeAt(0)%COLORS.length];
  const letter=`<div class="ic" style="width:${size}px;height:${size}px;border-radius:12px;background:${d.cat==='Kavi'?'#f0b90b':c+'22'};color:${d.cat==='Kavi'?'#1a1400':c}">${esc(name.slice(0,1).toUpperCase())}</div>`;
  return d.icon?`<img class="dimg" style="width:${size}px;height:${size}px" src="${esc(d.icon)}" alt="" onerror="this.outerHTML=this.dataset.f" data-f='${letter.replace(/'/g,'&#39;')}'>`:letter;
}
function getRecent(){return store.json('kw_recent',[])}
function addRecent(u){const l=getRecent().filter(x=>x!==u);l.unshift(u);store.put('kw_recent',l.slice(0,10))}
function getFavs(){return store.json('kw_favs',[])}
function isFav(u){return getFavs().some(f=>f.url===u)}
function toggleFav(u,title){let l=getFavs();if(l.some(f=>f.url===u))l=l.filter(f=>f.url!==u);else l.unshift({url:u,title:title||(dappByUrl(u)?.name)||hostOf(u)});store.put('kw_favs',l);renderDiscover($('bq').value.trim());return l.some(f=>f.url===u)}
function sitesKey(){return 'kw_sites_'+S.address}
function getSites(){return store.json(sitesKey(),{})}
function isConnected(origin){return !!getSites()[origin]}
function setConnected(origin,on){const s=getSites();if(on)s[origin]=Date.now();else delete s[origin];store.put(sitesKey(),s)}

function openUrl(u){
  addRecent(u);
  if(NATIVE&&typeof NATIVE.openDapp==='function'){try{NATIVE.openDapp(u)}catch{toast('Could not open dApp','err')}}
  else window.open(u,'_blank','noopener');
}
function bGo(){
  const q=$('bq').value.trim();if(!q)return;
  let u=q;
  if(!/^https?:\/\//i.test(u)){
    if(/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/.test(u))u='https://'+u;
    else{const hit=DAPPS.find(d=>d.name.toLowerCase().includes(q.toLowerCase()));if(hit)return openUrl(hit.url);renderDiscover(q);return}
  }
  try{new URL(u)}catch{return toast('Invalid address','err')}
  $('bq').blur();openUrl(u);
}
function renderDiscover(q){
  q=(q||'').toLowerCase();
  $('catBar').innerHTML=CATS.map(c=>`<button class="${c===S.cat?'on':''}" data-act="cat" data-v="${c}">${c}</button>`).join('');
  const list=DAPPS.filter(d=>(S.cat==='All'||d.cat===S.cat)&&(!q||d.name.toLowerCase().includes(q)||d.url.toLowerCase().includes(q)||d.desc.toLowerCase().includes(q)||d.cat.toLowerCase().includes(q)));
  $('dList').innerHTML=list.length?list.map(d=>`<div class="drow"><button class="row" data-act="openUrl" data-url="${esc(d.url)}">${dappIcon(d,40)}<div class="n"><b>${esc(d.name)}</b><span>${esc(d.desc)}</span></div></button><button class="star ${isFav(d.url)?'on':''}" data-act="favToggle" data-url="${esc(d.url)}" aria-label="Favorite"><svg width="18" height="18" viewBox="0 0 24 24" fill="${isFav(d.url)?'currentColor':'none'}" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/></svg></button></div>`).join(''):`<div class="empty">No dApps found.<br>Type a full address like app.example.com and press Go.</div>`;
  const tile=u=>{const d=dappByUrl(u)||{name:(getFavs().find(f=>f.url===u)?.title)||hostOf(u)};return `<button class="rc" data-act="openUrl" data-url="${esc(u)}">${dappIcon(d,44)}<span>${esc(d.name)}</span></button>`};
  const fav=getFavs().filter(f=>!q||f.url.toLowerCase().includes(q)||f.title.toLowerCase().includes(q));
  $('favH').hidden=!fav.length;$('favList').innerHTML=fav.map(f=>tile(f.url)).join('');
  const rec=getRecent().filter(u=>!q||u.toLowerCase().includes(q));
  $('recentH').hidden=!rec.length;$('recentList').innerHTML=rec.map(tile).join('');
  const sites=S.address?Object.keys(getSites()):[];
  $('sitesH').hidden=!sites.length;
  $('sitesList').innerHTML=sites.map(o=>`<div class="drow"><div class="row">${dappIcon(dappByUrl(o)||{name:hostOf(o)},32)}<div class="n"><b>${esc(hostOf(o))}</b><span>${esc(o)}</span></div></div><button class="chip" data-act="disconnectSite" data-o="${esc(o)}">Disconnect</button></div>`).join('');
}

function dappReply(nid,reqId,result){nat('dappReply',nid,JSON.stringify({id:reqId,result:result===undefined?null:result}))}
function dappError(nid,reqId,code,message){nat('dappReply',nid,JSON.stringify({id:reqId,error:{code,message}}))}
function dappEvent(event,data){nat('dappEvent',JSON.stringify({event,data}))}
const READ_OK=/^(eth_(blockNumber|call|estimateGas|gasPrice|maxPriorityFeePerGas|feeHistory|getBalance|getBlockBy(Hash|Number)|getBlockTransactionCountBy(Hash|Number)|getCode|getLogs|getProof|getStorageAt|getTransactionBy(Hash|BlockHashAndIndex|BlockNumberAndIndex)|getTransactionCount|getTransactionReceipt|getUncle.*|protocolVersion|syncing|blobBaseFee)|net_listening|web3_clientVersion|web3_sha3)$/;

async function onDappRequest(nid,raw,origin){
  let req;try{req=JSON.parse(raw)}catch{return}
  const id=req.id,m=req.method,p=Array.isArray(req.params)?req.params:(req.params?[req.params]:[]);
  const ok=r=>dappReply(nid,id,r),bad=(c,msg)=>dappError(nid,id,c,msg);
  if(!S.address||!S.vkey)return bad(4100,'Kavi Wallet is locked');
  S.lastActive=Date.now();S.dappOrigin=origin;
  const conn=isConnected(origin);
  try{
    switch(m){
      case 'eth_chainId':return ok(net().hex);
      case 'net_version':return ok(String(S.chain));
      case 'eth_accounts':return ok(conn?[S.address]:[]);
      case 'eth_coinbase':return ok(conn?S.address:null);
      case 'eth_requestAccounts':if(conn)return ok([S.address]);return enqueue({type:'connect',nid,id,origin,after:'accounts'});
      case 'wallet_requestPermissions':if(conn)return ok([{parentCapability:'eth_accounts'}]);return enqueue({type:'connect',nid,id,origin,after:'perms'});
      case 'wallet_getPermissions':return ok(conn?[{parentCapability:'eth_accounts'}]:[]);
      case 'wallet_revokePermissions':setConnected(origin,false);return ok(null);
      case 'wallet_switchEthereumChain':
      case 'wallet_addEthereumChain':{
        const want=parseInt(p[0]?.chainId,16);
        if(want===S.chain)return ok(null);
        if(NETS[want]&&(store.get('kw_hub3_'+want)||NETS[want].hub)){switchChain(want);toast(`Switched to ${NETS[want].name}`);return ok(null)}
        return bad(4902,'Kavi Wallet supports BNB Chain only');
      }
      case 'wallet_watchAsset':{
        const o=p[0]?.options||req.params?.options||{};const a=o.address;
        if(o.tokenId!==undefined||(p[0]?.type||req.params?.type||'').toUpperCase().startsWith('ERC7')||(p[0]?.type||'').toUpperCase()==='ERC1155')return bad(4200,'Add NFTs from the NFTs tab');
        if(!a||!ethers.isAddress(a))return bad(-32602,'Invalid token address');
        const added=await addTokenAddr(a);if(added)toast(`${S.meta[a.toLowerCase()].symbol} added to your tokens`,'ok');
        return ok(true);
      }
      case 'eth_sendTransaction':
        if(!conn)return bad(4100,'Site is not connected');
        if(S.watch)return bad(4100,'This is a watch-only wallet');
        return enqueue({type:'tx',nid,id,origin,tx:p[0]||{}});
      case 'personal_sign':{
        if(!conn)return bad(4100,'Site is not connected');
        if(S.watch)return bad(4100,'This is a watch-only wallet');
        let msg=p[0],addr=p[1];
        if(ethers.isAddress(msg)&&!ethers.isAddress(addr)){const t=msg;msg=addr;addr=t}
        if(addr&&!eq(addr,S.address))return bad(4100,'Unknown account');
        return enqueue({type:'sign',nid,id,origin,msg});
      }
      case 'eth_signTypedData_v4':
      case 'eth_signTypedData_v3':{
        if(!conn)return bad(4100,'Site is not connected');
        if(S.watch)return bad(4100,'This is a watch-only wallet');
        if(p[0]&&!eq(p[0],S.address))return bad(4100,'Unknown account');
        const td=typeof p[1]==='string'?JSON.parse(p[1]):p[1];
        return enqueue({type:'typed',nid,id,origin,td});
      }
      case 'eth_sign':case 'eth_signTypedData':return bad(4200,'This signing method is not supported for security reasons');
      case 'eth_sendRawTransaction':return bad(4200,'Not supported');
      default:
        if(READ_OK.test(m))return ok(await S.rp.send(m,p));
        return bad(4200,`Method ${m} is not supported`);
    }
  }catch(e){bad(-32603,errMsg(e))}
}
function enqueue(r){S.queue.push(r);nextReq()}
function nextReq(){
  if(S.busy||!S.queue.length)return;
  S.busy=true;nat('showWallet');
  const r=S.queue.shift();S.cur=r;
  (r.type==='connect'?showConnect(r):r.type==='tx'?showTx(r):showSign(r)).catch(e=>{dappError(r.nid,r.id,-32603,errMsg(e));finishReq()});
}
function finishReq(){
  S.sheetClose=null;closeSheet();S.busy=false;S.cur=null;
  if(S.queue.length)return setTimeout(nextReq,250);
  nat('showDapp');
}
function siteHead(origin){
  const d=dappByUrl(origin)||{name:hostOf(origin)};
  return `<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">${dappIcon(d,44)}<div style="min-width:0"><b style="font-size:15px">${esc(d.name)}</b><div class="sub">${esc(origin)}</div></div></div>`;
}
async function showConnect(r){
  sheet('Connect to site',`${siteHead(r.origin)}
    <div class="note">This site wants to connect to <b>${esc(S.rec.name)}</b> (${short(S.address)}). It will see your address and balances, and can ask you to approve transactions. It can't move funds without your approval.${S.watch?'<br><span class="warn">This is a watch-only wallet, so the site can only read.</span>':''}</div>
    <div class="grid2"><button class="btn ghost" data-act="reqNo">Cancel</button><button class="btn" data-act="reqYes">Connect</button></div>`);
  S.sheetClose=reqNo;
}
async function describeCall(to,data){
  let d=null;try{d=IF_ERC20.parseTransaction({data})}catch{}
  if(!d||!['approve','transfer','transferFrom'].includes(d.name))return{title:data&&data!=='0x'?'Contract interaction':`Send ${net().sym}`,rows:''};
  const m=await meta(to).catch(()=>({symbol:'tokens',decimals:18}));
  const amt=v=>v>=MAXU?'Unlimited':`${fmt(v,m.decimals)} ${esc(m.symbol)}`;
  if(d.name==='approve')return{title:`Approve ${m.symbol} spending`,rows:`<div class="kv"><span>Spender</span><b>${esc(spenderName(d.args[0]))}</b></div><div class="kv"><span>Amount</span><b${d.args[1]>=MAXU?' style="color:var(--acc)"':''}>${amt(d.args[1])}</b></div>`};
  if(d.name==='transfer')return{title:`Send ${m.symbol}`,rows:`<div class="kv"><span>To</span><b>${esc(nameOf(d.args[0])||short(d.args[0]))}</b></div><div class="kv"><span>Amount</span><b>${amt(d.args[1])}</b></div>`};
  return{title:`Transfer ${m.symbol}`,rows:`<div class="kv"><span>From</span><b>${short(d.args[0])}</b></div><div class="kv"><span>To</span><b>${short(d.args[1])}</b></div><div class="kv"><span>Amount</span><b>${amt(d.args[2])}</b></div>`};
}
async function showTx(r){
  const t=r.tx;
  if(t.from&&!eq(t.from,S.address)){dappError(r.nid,r.id,4100,'Unknown account');return finishReq()}
  if(!t.to||!ethers.isAddress(t.to)){dappError(r.nid,r.id,4200,'Contract deployment is not supported');return finishReq()}
  const val=BigInt(t.value||0),data=t.data||t.input||'0x';
  const info=await describeCall(t.to,data);
  r.action={to:ethers.getAddress(t.to),value:val,data,label:info.title};
  if(t.gas||t.gasLimit)try{r.action.gas=BigInt(t.gas||t.gasLimit)*12n/10n}catch{}
  r.title=info.title;
  let est='';
  try{
    const g=await S.rp.estimateGas({from:S.address,to:r.action.to,value:val,data});
    const gp=await gasPriceNow();est=`${fmt(g*gp)} ${net().sym}`;
  }catch(e){r.willFail=errMsg(e)}
  sheet('Confirm transaction',`${siteHead(r.origin)}
    <div class="card" style="margin:0 0 10px">
      <div class="kv"><span>Action</span><b>${esc(info.title)}</b></div>
      ${info.rows}
      <div class="kv"><span>Contract</span><b><a href="${net().explorer}/address/${t.to}" target="_blank" rel="noopener">${short(t.to)}</a></b></div>
      ${val?`<div class="kv"><span>${net().sym} value</span><b>${fmt(val)} ${net().sym}${valOf(val,18,'')?' · '+valOf(val,18,''):''}</b></div>`:''}
      ${est?`<div class="kv"><span>Network fee</span><b>≈ ${est}</b></div>`:''}
      ${data!=='0x'?`<div class="kv"><span>Data</span><b style="font-family:ui-monospace,monospace;font-size:12px">${data.slice(0,10)}… · ${(data.length-2)/2} bytes</b></div>`:''}
    </div>
    ${r.willFail?`<div class="warnbox">This transaction will probably fail: ${esc(r.willFail)}</div>`:''}
    ${val>S.bnb?`<div class="warnbox">You only have ${fmt(S.bnb)} ${net().sym}.</div>`:''}
    ${feeNote()}
    <div class="grid2"><button class="btn ghost" data-act="reqNo">Reject</button><button class="btn" data-act="reqYes">Confirm</button></div>`);
  S.sheetClose=reqNo;
}
function readableMsg(m){
  if(typeof m!=='string')return JSON.stringify(m);
  if(ethers.isHexString(m)){try{const s=ethers.toUtf8String(m);if(/^[\x09\x0a\x0d\x20-\x7e -￿]*$/.test(s))return s}catch{}}
  return m;
}
async function showSign(r){
  let body;
  if(r.type==='sign')body=`<div class="card" style="margin:0 0 12px;max-height:220px;overflow:auto;white-space:pre-wrap;word-break:break-word;font-size:13px">${esc(readableMsg(r.msg))}</div>`;
  else{
    const td=r.td||{};
    body=`<div class="card" style="margin:0 0 12px"><div class="kv"><span>Type</span><b>${esc(td.primaryType||'Typed data')}</b></div>${td.domain?.name?`<div class="kv"><span>App</span><b>${esc(td.domain.name)}</b></div>`:''}${td.domain?.verifyingContract?`<div class="kv"><span>Contract</span><b>${short(td.domain.verifyingContract)}</b></div>`:''}<div style="margin-top:8px;max-height:180px;overflow:auto;white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,monospace;font-size:11px;color:var(--mut)">${esc(JSON.stringify(td.message||{},null,2))}</div></div>`;
    if(/^Permit/.test(td.primaryType||''))body+='<div class="warnbox">This signature lets the site spend your tokens. Only sign if you trust it.</div>';
  }
  sheet('Signature request',`${siteHead(r.origin)}${body}<div class="note">Signing is free and doesn't send a transaction.</div><div class="grid2"><button class="btn ghost" data-act="reqNo">Reject</button><button class="btn" data-act="reqYes">Sign</button></div>`);
  S.sheetClose=reqNo;
}
async function reqYes(){
  const r=S.cur;if(!r)return;
  const btn=S.clicked;S.sheetClose=null;
  if(btn){btn.disabled=true;btn.innerHTML='<span class="spin"></span>Working'}
  try{
    if(r.type==='connect'){
      setConnected(r.origin,true);
      dappReply(r.nid,r.id,r.after==='perms'?[{parentCapability:'eth_accounts'}]:[S.address]);
      dappEvent('connect',{chainId:net().hex});dappEvent('accountsChanged',[S.address]);
      toast(`Connected to ${hostOf(r.origin)}`,'ok');renderDiscover($('bq').value.trim());
    }else if(r.type==='tx'){
      const label=`${(dappByUrl(r.origin)||{name:hostOf(r.origin)}).name}: ${r.title}`;
      const res=await txFlow([r.action],{earlyLast:true,label,extra:{kind:'dapp'}});
      dappReply(r.nid,r.id,res.hash);
      toast('Transaction sent');
      (res.wait?res.wait():Promise.resolve(res)).then(x=>{toast(x.ok?'Transaction confirmed':'Transaction failed',x.ok?'ok':'err');refresh()}).catch(()=>{});
    }else if(r.type==='sign'){
      const m=r.msg;
      dappReply(r.nid,r.id,await S.wallet.signMessage(typeof m==='string'&&ethers.isHexString(m)?ethers.getBytes(m):m));
    }else if(r.type==='typed'){
      const td=r.td||{};const types={...td.types};delete types.EIP712Domain;
      dappReply(r.nid,r.id,await S.wallet.signTypedData(td.domain||{},types,td.message||{}));
    }
  }catch(e){dappError(r.nid,r.id,e?.code===4001?4001:-32603,errMsg(e));toast(errMsg(e),'err')}
  finishReq();
}
function reqNo(){const r=S.cur;S.sheetClose=null;if(r)dappError(r.nid,r.id,4001,'User rejected the request');finishReq()}

function bioState(){const s=nat('bioStatus');return typeof s==='string'?s:'unavailable'}
function bioCall(op,arg){
  return new Promise(res=>{
    S.bioRes=res;
    const r=op==='enable'?nat('bioEnable',arg):nat('bioUnlock');
    if(r===undefined&&!(NATIVE&&typeof NATIVE[op==='enable'?'bioEnable':'bioUnlock']==='function'))res({ok:false,error:'Fingerprint is not available'});
  });
}
async function bioUnlock(){
  const r=await bioCall('unlock');
  if(r.ok&&r.pw){await unlockWith(r.pw,null)}
  else if(r.error&&!/cancel/i.test(r.error))toast(r.error,'err');
  if(r.invalidated){toast('Fingerprints changed. Unlock with your password and turn fingerprint on again.','err');$('bioBtn').hidden=true}
}

function autoLockMin(){return Number(store.get('kw_autolock')||5)}
async function unlockWith(pw,btn){
  try{
    if(!getVault()&&store.get('kw_keystore')){
      if(btn)btn.innerHTML='<span class="spin"></span>Upgrading wallet';
      const rec=await migrateOld(pw);
      await startSession(rec);return true;
    }
    S.vkey=await openVault(pw);
    const rec=activeRec();
    if(!rec)throw new Error('No wallet found');
    $('unlockPw').value='';
    await startSession(rec);
    return true;
  }catch(e){toast(/wrong|invalid password|incorrect/i.test(e.message)?'Wrong password':errMsg(e),'err');return false}
}
async function doUnlock(){
  const pw=$('unlockPw').value,btn=S.clicked;
  if(!pw)return;
  btn.disabled=true;btn.innerHTML='<span class="spin"></span>Unlocking';
  await unlockWith(pw,btn);
  btn.disabled=false;btn.innerHTML='Unlock';
}
function askPassword(title,note,cb){
  sheet(title,`${note?`<div class="note">${note}</div>`:''}<div class="f"><label>Password</label><div class="inp"><input id="askPw" type="password" autocomplete="current-password"></div></div><button class="btn" data-act="askPwGo">Continue</button>`,()=>{S.askCb=cb;setTimeout(()=>$('askPw')?.focus(),200)});
}
async function askPwGo(){
  const pw=$('askPw').value,btn=S.clicked,old=btn.innerHTML;
  btn.disabled=true;btn.innerHTML='<span class="spin"></span>Checking';
  let ok=false;
  try{await openVault(pw);ok=true}catch{toast('Wrong password','err')}
  if(btn.isConnected){btn.disabled=false;btn.innerHTML=old}
  if(ok){const cb=S.askCb;S.askCb=null;cb(pw)}
}

const ONB={};
function goCreate(){closeSheet();closePage();ONB.mode=S.vkey?'add':'create';if(S.vkey)return makePhrase();$('pw1').value='';$('pw2').value='';show('s-password')}
function goImport(mode='phrase'){
  closeSheet();closePage();
  ONB.imp=mode;$('impText').value='';$('impName').value='';$('impPw1').value='';$('impPw2').value='';
  $('impPwBox').hidden=!!S.vkey;impMode(mode);show('s-import');
}
function impMode(v){
  ONB.imp=v;
  document.querySelectorAll('#impSeg button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
  $('impLbl').textContent=v==='phrase'?'Recovery phrase (12 or 24 words)':v==='key'?'Private key':'Wallet address to watch';
  $('impText').placeholder=v==='phrase'?'word1 word2 word3 …':'0x…';
  $('impScan').hidden=v==='phrase';
  $('impNote').hidden=v!=='watch';
}
function onbBack(){if(S.vkey){show('s-main')}else show('s-welcome')}
function checkPw(a,b){
  if(a.length<8){toast('Password must be at least 8 characters','err');return false}
  if(a!==b){toast('Passwords do not match','err');return false}
  return true;
}
function pwNext(){const a=$('pw1').value,b=$('pw2').value;if(!checkPw(a,b))return;ONB.pw=a;makePhrase()}
function makePhrase(){
  ONB.wallet=ethers.Wallet.createRandom();
  const words=ONB.wallet.mnemonic.phrase.split(' ');
  $('words').innerHTML=words.map((w,i)=>`<div class="word"><i>${i+1}</i>${w}</div>`).join('');
  $('savedChk').checked=false;show('s-phrase');
}
function phraseNext(){
  if(!$('savedChk').checked)return toast('Please confirm you wrote down the phrase','err');
  const idx=[];while(idx.length<3){const r=Math.floor(Math.random()*12);if(!idx.includes(r))idx.push(r)}
  idx.sort((a,b)=>a-b);
  $('verifyBox').innerHTML=idx.map(i=>`<div class="f"><label>Word #${i+1}</label><div class="inp"><input data-w="${i}" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div>`).join('');
  show('s-verify');
}
async function verifyDone(){
  const words=ONB.wallet.mnemonic.phrase.split(' ');
  const ok=[...document.querySelectorAll('#verifyBox input')].every(inp=>inp.value.trim().toLowerCase()===words[+inp.dataset.w]);
  if(!ok)return toast('Those words don\'t match. Check your phrase.','err');
  const btn=S.clicked;btn.disabled=true;btn.innerHTML='<span class="spin"></span>Creating';
  try{
    if(!S.vkey)await newVault(ONB.pw);
    const rec=await addWalletRec({name:'',type:'phrase',address:ONB.wallet.address,secret:{phrase:ONB.wallet.mnemonic.phrase}});
    ONB.wallet=null;ONB.pw=null;
    await startSession(rec);toast('Wallet created','ok');
  }catch(e){toast(errMsg(e),'err')}
  finally{btn.disabled=false;btn.innerHTML='Create wallet'}
}
async function doImport(){
  const txt=$('impText').value.trim().replace(/\s+/g,' '),name=$('impName').value.trim();
  let rec;
  try{
    if(ONB.imp==='watch'){
      if(!ethers.isAddress(txt))throw new Error('Enter a valid wallet address');
      rec={type:'watch',address:ethers.getAddress(txt)};
    }else if(ONB.imp==='key'){
      if(!/^(0x)?[0-9a-fA-F]{64}$/.test(txt))throw new Error('That private key is not valid');
      const w=new ethers.Wallet(txt.startsWith('0x')?txt:'0x'+txt);rec={type:'key',address:w.address,secret:{pk:w.privateKey}};
    }else{
      let w;try{w=ethers.Wallet.fromPhrase(txt.toLowerCase())}catch{throw new Error('That recovery phrase is not valid')}
      rec={type:'phrase',address:w.address,secret:{phrase:w.mnemonic.phrase}};
    }
  }catch(e){return toast(e.message,'err')}
  if(!S.vkey&&!checkPw($('impPw1').value,$('impPw2').value))return;
  const btn=S.clicked;btn.disabled=true;btn.innerHTML='<span class="spin"></span>Adding';
  try{
    if(!S.vkey)await newVault($('impPw1').value);
    const r=await addWalletRec({name,...rec});
    await startSession(r);toast('Wallet added','ok');
  }catch(e){toast(errMsg(e),'err')}
  finally{btn.disabled=false;btn.innerHTML='Add wallet'}
}

function walletPicker(){
  const l=walletsAll();
  sheet('Wallets',`${l.map(w=>`<button class="li" data-act="switchWallet" data-id="${w.id}"><div class="wav" style="width:34px;height:34px;border-radius:10px">${esc(w.name.slice(0,1).toUpperCase())}</div><div class="lt"><b>${esc(w.name)} ${w.type==='watch'?'<span class="pill">Watch</span>':''}</b><span>${w.address}</span></div>${w.id===S.rec.id?'<span class="pill acc">Active</span>':''}</button>`).join('')}
    <div class="gap"></div><div class="grid2"><button class="btn ghost sm" data-act="manageWallets">Manage</button><button class="btn sm" data-act="addWalletMenu">Add wallet</button></div>`);
}
function addWalletMenu(){
  sheet('Add wallet',`<div class="grp">
    <button class="li" data-act="goCreate"><div class="lic">+</div><div class="lt"><b>Create new wallet</b><span>New recovery phrase</span></div></button>
    <button class="li" data-act="goImport" data-v="phrase"><div class="lic">⤓</div><div class="lt"><b>Import recovery phrase</b><span>12 or 24 words</span></div></button>
    <button class="li" data-act="goImport" data-v="key"><div class="lic">🔑</div><div class="lt"><b>Import private key</b><span>64-character key</span></div></button>
    <button class="li" data-act="goImport" data-v="watch"><div class="lic">👁</div><div class="lt"><b>Watch an address</b><span>View only, can't send</span></div></button></div>`);
}
function manageWallets(){
  closeSheet();
  page('Manage wallets',()=>`<div class="grp">${walletsAll().map(w=>`<button class="li" data-act="walletDetail" data-id="${w.id}"><div class="wav" style="width:34px;height:34px;border-radius:10px">${esc(w.name.slice(0,1).toUpperCase())}</div><div class="lt"><b>${esc(w.name)} ${w.type==='watch'?'<span class="pill">Watch</span>':''}${w.id===S.rec?.id?' <span class="pill acc">Active</span>':''}</b><span>${w.address}</span></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8b949e" stroke-width="2"><path d="m9 6 6 6-6 6"/></svg></button>`).join('')}</div><button class="btn" data-act="addWalletMenu">Add wallet</button>`,{key:'wallets'});
}
function walletDetail(id){
  const w=walletsAll().find(x=>x.id===id);if(!w)return;
  page(w.name,()=>{const x=walletsAll().find(y=>y.id===id)||w;return `
    <div class="card" style="margin:0 0 12px;text-align:center"><div class="wav" style="width:52px;height:52px;border-radius:16px;margin:4px auto 10px;font-size:22px">${esc(x.name.slice(0,1).toUpperCase())}</div><b style="font-size:17px">${esc(x.name)}</b><div class="mono2" style="margin:10px 0 0">${x.address}</div></div>
    <div class="grp">
      <button class="li" data-act="renameWallet" data-id="${id}"><div class="lt"><b>Rename</b></div><div class="lv">${esc(x.name)}</div></button>
      ${x.id!==S.rec?.id?`<button class="li" data-act="switchWallet" data-id="${id}"><div class="lt"><b>Switch to this wallet</b></div></button>`:''}
      <button class="li" data-act="copyText" data-t="${x.address}"><div class="lt"><b>Copy address</b></div></button>
    </div>
    ${x.type!=='watch'?`<div class="gt">Backup</div><div class="grp">
      ${x.type==='phrase'?`<button class="li" data-act="showPhrase" data-id="${id}"><div class="lt"><b>Show recovery phrase</b><span>12 words</span></div></button>`:''}
      <button class="li" data-act="exportKey" data-id="${id}"><div class="lt"><b>Export private key</b></div></button>
      <button class="li" data-act="exportKeystore" data-id="${id}"><div class="lt"><b>Export keystore file</b><span>JSON protected by a password</span></div></button>
    </div>`:''}
    <div class="gap"></div><button class="btn danger sm" data-act="removeWallet" data-id="${id}">Remove wallet</button>`},{key:'wallet:'+id});
}
function renameWallet(id){
  const w=walletsAll().find(x=>x.id===id);
  sheet('Rename wallet',`<div class="f"><div class="inp"><input id="rnN" value="${esc(w.name)}" maxlength="24"></div></div><button class="btn" data-act="doRename" data-id="${id}">Save</button>`);
}
function doRename(id){
  const n=$('rnN').value.trim();if(!n)return toast('Enter a name','err');
  const v=getVault();const w=v.wallets.find(x=>x.id===id);w.name=n;saveVault(v);
  if(S.rec?.id===id)S.rec.name=n;
  closeSheet();renderHeader();replacePage(n,topPage().html,{key:topPage().key});toast('Renamed','ok');
}
function showSecret(id,kind){
  const w=walletsAll().find(x=>x.id===id);
  askPassword(kind==='phrase'?'Recovery phrase':'Private key',`Never share your ${kind==='phrase'?'recovery phrase':'private key'}. Anyone with it can take your funds.`,async()=>{
    const sec=await secretOf(w);
    if(kind==='phrase'){
      const words=sec.phrase.split(' ');
      sheet('Recovery phrase',`<div class="warnbox">Never share these words. Kavi Wallet will never ask for them.</div><div class="words">${words.map((x,i)=>`<div class="word"><i>${i+1}</i>${x}</div>`).join('')}</div>`);
    }else{
      const pk=sec.pk||ethers.Wallet.fromPhrase(sec.phrase).privateKey;
      sheet('Private key',`<div class="warnbox">Never share your private key. Anyone with it can take your funds.</div><div class="mono2">${pk}</div><button class="btn ghost sm" data-act="copyText" data-t="${pk}">Copy</button>`);
    }
  });
}
function exportKeystore(id){
  const w=walletsAll().find(x=>x.id===id);
  askPassword('Export keystore','Enter your Kavi Wallet password. The keystore file will be protected with this same password.',async pw=>{
    const btn=S.clicked;
    sheet('Export keystore','<div class="empty"><span class="spin" style="display:inline-block"></span><div id="ksP" style="margin-top:8px">Encrypting…</div></div>');
    const sec=await secretOf(w);
    const wal=sec.pk?new ethers.Wallet(sec.pk):ethers.Wallet.fromPhrase(sec.phrase);
    const json=await wal.encrypt(pw,p=>{if($('ksP'))$('ksP').textContent=`Encrypting ${Math.round(p*100)}%`});
    S.ksJson=json;
    sheet('Export keystore',`<div class="note">Keystore for <b>${esc(w.name)}</b>. It can be imported into most wallets with your password.</div><div class="mono2" style="max-height:160px;overflow:auto">${esc(json)}</div><div class="grid2"><button class="btn ghost sm" data-act="copyKs">Copy</button><button class="btn sm" data-act="shareKs">Share / save</button></div>`);
  });
}
function removeWallet(id){
  const w=walletsAll().find(x=>x.id===id);
  sheet('Remove wallet',`<div class="warnbox">Remove <b>${esc(w.name)}</b> from this phone? Funds stay on the blockchain, but you can only get them back with its recovery phrase or private key.</div><div class="f"><label>Type REMOVE to confirm</label><div class="inp"><input id="rmTxt" autocomplete="off" autocapitalize="characters"></div></div><button class="btn danger" data-act="doRemoveWallet" data-id="${id}">Remove</button>`);
}
async function doRemoveWallet(id){
  if($('rmTxt').value.trim()!=='REMOVE')return toast('Type REMOVE to confirm','err');
  const v=getVault();v.wallets=v.wallets.filter(x=>x.id!==id);saveVault(v);
  closeSheet();closePage();
  if(!v.wallets.length){return resetAll()}
  if(S.rec?.id===id)await startSession(v.wallets[0]);
  toast('Wallet removed');
}
function resetAll(){
  for(const k of Object.keys(localStorage))if(k.startsWith('kw_'))store.del(k);
  nat('bioDisable');
  S.wallet=null;S.signer=null;S.address=null;S.vkey=null;S.rec=null;clearInterval(S.poll);
  closeSheet();closePage();nat('closeDapp');
  show('s-welcome');
}
function changePassword(){
  sheet('Change password',`<div class="f"><label>Current password</label><div class="inp"><input id="cp0" type="password"></div></div><div class="f"><label>New password (at least 8 characters)</label><div class="inp"><input id="cp1" type="password"></div></div><div class="f"><label>Confirm new password</label><div class="inp"><input id="cp2" type="password"></div></div><button class="btn" data-act="doChangePw">Change password</button>`);
}
async function doChangePw(){
  const o=$('cp0').value,a=$('cp1').value,b=$('cp2').value;
  if(!checkPw(a,b))return;
  const btn=S.clicked;btn.disabled=true;btn.innerHTML='<span class="spin"></span>Updating';
  try{
    const oldKey=await openVault(o);
    const v=getVault();
    const salt=ethers.hexlify(crypto.getRandomValues(new Uint8Array(16)));
    const key=await deriveKey(a,salt,v.iter);
    for(const w of v.wallets)if(w.box)w.box=await seal(key,await unseal(oldKey,w.box));
    v.salt=salt;v.check=await seal(key,'kavi-ok');
    saveVault(v);S.vkey=key;
    const hadBio=bioState()==='enabled';
    if(hadBio)nat('bioDisable');
    closeSheet();toast(hadBio?'Password changed. Turn fingerprint unlock on again in Security.':'Password changed','ok');repaintIf('me');renderMe();
  }catch(e){toast(/Wrong/.test(e.message)?'Current password is wrong':errMsg(e),'err')}
  finally{if(btn.isConnected){btn.disabled=false;btn.innerHTML='Change password'}}
}
async function toggleBio(){
  const st=bioState();
  if(st==='unavailable')return toast('Fingerprint unlock is not available on this phone','err');
  if(st==='enabled'){nat('bioDisable');renderMe();return toast('Fingerprint unlock turned off')}
  askPassword('Fingerprint unlock','Enter your password, then touch the fingerprint sensor.',async pw=>{
    closeSheet();
    const r=await bioCall('enable',pw);
    if(r.ok)toast('Fingerprint unlock is on','ok');else if(r.error)toast(r.error,'err');
    renderMe();
  });
}

function sw(on){return `<span class="sw ${on?'on':''}"></span>`}
function li(act,title,{sub='',val='',ic='',extra=''}={}){return `<button class="li" data-act="${act}" ${extra}>${ic?`<div class="lic">${ic}</div>`:''}<div class="lt"><b>${title}</b>${sub?`<span>${sub}</span>`:''}</div>${val?`<div class="lv">${val}</div>`:''}</button>`}
const IC={
  wal:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="6" width="18" height="14" rx="3"/><path d="M16 13h2"/></svg>',
  book:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4h12a2 2 0 0 1 2 2v14H7a2 2 0 0 1-2-2z"/><circle cx="12" cy="10" r="2.5"/><path d="M8.5 16a3.5 3.5 0 0 1 7 0"/></svg>',
  shield:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg>',
  clock:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>',
  multi:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h9M10 7l5 5-5 5M19 5v14"/></svg>',
  pen:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
  check:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg>',
  search:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5"/></svg>',
  finger:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 11v3M8.5 8.5a5 5 0 0 1 8 4v1.5M7 13v1a5 5 0 0 0 1.5 3.5M12 4a8 8 0 0 1 8 8v1M4 12a8 8 0 0 1 3-6.2"/></svg>',
  key:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3"/></svg>',
  lock:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  coin:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M14.5 9.5c-.5-1-1.5-1.5-2.5-1.5-1.5 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1 2-2.5 2c-1 0-2-.5-2.5-1.5M12 6.5v11"/></svg>',
  eye:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  net:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4a12 12 0 0 1 0 16M12 4a12 12 0 0 0 0 16"/></svg>',
  gas:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 20V5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v15M4 20h11M14 9h2a2 2 0 0 1 2 2v5a1.5 1.5 0 0 0 3 0V8l-3-3M7 8h5"/></svg>',
  info:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8h.01"/></svg>',
  link:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
  hist:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4M12 8v4l3 2"/></svg>'
};
function renderMe(){
  if(!S.rec)return;
  const bio=bioState(),g=gasMode();
  $('meBody').innerHTML=`
    <button class="card" data-act="walletDetail" data-id="${S.rec.id}" style="display:flex;align-items:center;gap:12px;width:100%;text-align:left;margin:0 0 6px"><div class="wav" style="width:46px;height:46px;border-radius:14px;font-size:20px">${esc(S.rec.name.slice(0,1).toUpperCase())}</div><div style="min-width:0;flex:1"><b style="font-size:16px">${esc(S.rec.name)}</b>${S.watch?' <span class="pill">Watch</span>':''}<div class="sub" style="overflow:hidden;text-overflow:ellipsis">${S.address}</div></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8b949e" stroke-width="2"><path d="m9 6 6 6-6 6"/></svg></button>
    <div class="gt">Wallet</div><div class="grp">
      ${li('manageWallets','Manage wallets',{ic:IC.wal,val:walletsAll().length})}
      ${li('contacts','Address book',{ic:IC.book,val:contacts().length||''})}
      ${li('history','Transaction history',{ic:IC.hist})}
      ${li('approvals','Token approvals',{ic:IC.shield,sub:'See and revoke spending permissions'})}
      ${li('sitesPage','Connected sites',{ic:IC.link,val:Object.keys(getSites()).length||''})}
    </div>
    <div class="gt">Tools</div><div class="grp">
      ${li('batch','Batch send',{ic:IC.multi,sub:'Send to many addresses at once'})}
      ${li('tokenCheck','Token check',{ic:IC.search,sub:'Spot fake or risky tokens'})}
      ${li('signTool','Sign message',{ic:IC.pen})}
      ${li('verifyTool','Verify message',{ic:IC.check})}
    </div>
    <div class="gt">Security</div><div class="grp">
      <button class="li" data-act="toggleBio"><div class="lic">${IC.finger}</div><div class="lt"><b>Fingerprint unlock</b>${bio==='unavailable'?'<span>Not available on this phone</span>':''}</div>${sw(bio==='enabled')}</button>
      ${li('changePassword','Change password',{ic:IC.key})}
      ${li('autoLock','Auto-lock',{ic:IC.clock,val:autoLockMin()+' min'})}
      <button class="li" data-act="toggleHide"><div class="lic">${IC.eye}</div><div class="lt"><b>Hide balances</b></div>${sw(hidden())}</button>
      ${li('lockNow','Lock wallet now',{ic:IC.lock})}
    </div>
    <div class="gt">Preferences</div><div class="grp">
      ${li('notifSettings','Notifications',{ic:BELL.replace('width="16" height="16"','width="18" height="18"'),val:notifs().filter(x=>!x.read).length?notifs().filter(x=>!x.read).length+' new':''})}
      ${li('currency','Currency',{ic:IC.coin,val:curCode()})}
      <button class="li" data-act="toggleSmall"><div class="lic">${IC.eye}</div><div class="lt"><b>Hide small balances</b><span>Tokens worth less than $1</span></div>${sw(store.get('kw_small')==='1')}</button>
      ${li('netPicker','Network',{ic:IC.net,val:net().name})}
      ${li('nodes','RPC node',{ic:IC.net,val:hostOf(rpcUrls()[S.rpcIdx||0])})}
      ${li('gasDefault','Default network fee speed',{ic:IC.gas,val:/^[0-9.]/.test(g)?g+' Gwei':g[0].toUpperCase()+g.slice(1)})}
      ${li('scanKey','Explorer API key',{ic:IC.search,val:store.get('kw_scankey')?'Set':'Not set',sub:'For full on-chain history'})}
    </div>
    <div class="gt">About</div><div class="grp">
      ${li('advanced','Advanced',{ic:IC.info,sub:'KaviHub contract'})}
      <div class="li"><div class="lic">${IC.info}</div><div class="lt"><b>Version</b></div><div class="lv">${APP_VERSION}${nat('appVersion')?' ('+esc(nat('appVersion'))+')':''}</div></div>
    </div>
    <div class="gap"></div><button class="btn danger sm" data-act="resetAsk">Remove all wallets from this phone</button><div class="gap"></div>`;
}
function sitesPage(){
  page('Connected sites',()=>{const s=Object.keys(getSites());return s.length?s.map(o=>`<div class="drow"><div class="row">${dappIcon(dappByUrl(o)||{name:hostOf(o)},32)}<div class="n"><b>${esc(hostOf(o))}</b><span>${esc(o)}</span></div></div><button class="chip" data-act="disconnectSite" data-o="${esc(o)}">Disconnect</button></div>`).join(''):'<div class="empty">No connected sites</div>'},{key:'sites'});
}
function pickSheet(title,opts,cur,act){
  sheet(title,`<div class="grp">${opts.map(([v,l,s])=>`<button class="li" data-act="${act}" data-v="${esc(v)}"><div class="lt"><b>${l}</b>${s?`<span>${s}</span>`:''}</div>${String(cur)===String(v)?'<span class="pill acc">✓</span>':''}</button>`).join('')}</div>`);
}
async function nodesPage(){
  const list=[...new Set([...(store.get('kw_rpc_'+S.chain)?[store.get('kw_rpc_'+S.chain)]:[]),...net().rpcs])];
  const cur=rpcUrls()[S.rpcIdx||0];
  page('RPC node',`<div class="note">Choose the network node Kavi Wallet uses. Lower latency is faster.</div><div class="grp">${list.map(u=>`<button class="li" data-act="pickNode" data-v="${esc(u)}"><div class="lt"><b>${esc(hostOf(u))}</b><span>${esc(u)}</span></div><div class="lv" data-ping="${esc(u)}">…</div>${u===cur?'<span class="pill acc">✓</span>':''}</button>`).join('')}</div><button class="btn ghost sm" data-act="customNode">Add custom RPC</button>${store.get('kw_rpc_'+S.chain)?'<div class="gap"></div><button class="btn ghost sm" data-act="autoNode">Use automatic selection</button>':''}`,{onShow:()=>{
    list.forEach(async u=>{const t=Date.now();let txt='offline';try{const r=await httpReq('POST',u,JSON.stringify({jsonrpc:'2.0',id:1,method:'eth_blockNumber',params:[]}));if(r.status===200&&JSON.parse(r.body).result)txt=(Date.now()-t)+' ms'}catch{}const el=document.querySelector(`[data-ping="${CSS.escape(u)}"]`);if(el)el.textContent=txt});
  }});
}
function switchChain(n){
  S.chain=n;store.set('kw_chain',n);S.meta={};S.prices={};S.priceAt=0;S.tokens=[];S.kavi=null;S.kaviQuote=null;S.round=null;S.rpcIdx=0;S.pools={};
  makeProvider();renderHeader();
  dappEvent('chainChanged',net().hex);
  route();
}

let scanCb=null,scanStream=null,scanRaf=0;
function startScan(cb){
  scanCb=cb;$('scanner').classList.add('on');
  if(!navigator.mediaDevices?.getUserMedia){return}
  navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}}).then(st=>{
    scanStream=st;const v=$('scanVid');v.srcObject=st;v.play().catch(()=>{});
    const c=document.createElement('canvas'),ctx=c.getContext('2d',{willReadFrequently:true});
    const loop=()=>{
      if(!scanStream)return;
      if(v.readyState>=2&&v.videoWidth){
        const w=Math.min(640,v.videoWidth),h=Math.round(v.videoHeight*w/v.videoWidth);
        c.width=w;c.height=h;ctx.drawImage(v,0,0,w,h);
        const r=jsQR(ctx.getImageData(0,0,w,h).data,w,h,{inversionAttempts:'dontInvert'});
        if(r&&r.data){const f=scanCb;stopScan();f&&f(r.data);return}
      }
      scanRaf=requestAnimationFrame(loop);
    };
    loop();
  }).catch(()=>toast('Camera not available. Use "From photo" or allow camera permission.','err'));
}
function stopScan(){
  cancelAnimationFrame(scanRaf);
  if(scanStream){scanStream.getTracks().forEach(t=>t.stop());scanStream=null}
  $('scanner').classList.remove('on');scanCb=null;
}
function scanFromFile(file){
  const img=new Image();
  img.onload=()=>{
    const c=document.createElement('canvas'),w=Math.min(1200,img.width),h=Math.round(img.height*w/img.width);
    c.width=w;c.height=h;const ctx=c.getContext('2d');ctx.drawImage(img,0,0,w,h);
    const r=jsQR(ctx.getImageData(0,0,w,h).data,w,h);
    URL.revokeObjectURL(img.src);
    if(r&&r.data){const f=scanCb;stopScan();f&&f(r.data)}else toast('No QR code found in that photo','err');
  };
  img.onerror=()=>toast('Could not read that image','err');
  img.src=URL.createObjectURL(file);
}
function parseQr(t){
  t=String(t).trim();
  if(ethers.isAddress(t))return{address:ethers.getAddress(t)};
  const m=/^(?:ethereum|bnb|binance):(?:pay-)?(0x[0-9a-fA-F]{40})(?:@(\d+))?(?:\/(\w+))?(?:\?(.*))?$/i.exec(t);
  if(m){
    const q=new URLSearchParams(m[4]||'');const target=ethers.getAddress(m[1]);
    if((m[3]||'').toLowerCase()==='transfer'&&q.get('address')&&ethers.isAddress(q.get('address')))return{address:ethers.getAddress(q.get('address')),token:target,raw:q.get('uint256'),chain:m[2]};
    return{address:target,raw:q.get('value'),chain:m[2]};
  }
  if(/^https?:\/\//i.test(t))return{url:t};
  if(/^0x[0-9a-fA-F]{40}/.test(t)&&ethers.isAddress(t.slice(0,42)))return{address:ethers.getAddress(t.slice(0,42))};
  return{text:t};
}
async function handleScanMain(t){
  const r=parseQr(t);
  if(r.url){sheet('Open link?',`<div class="mono2">${esc(r.url)}</div><button class="btn" data-act="openUrl" data-url="${esc(r.url)}">Open in Discover</button>`);return}
  if(r.address){
    let asset='',amount='';
    if(r.token){if(!tokenList().some(a=>eq(a,r.token)))await addTokenAddr(r.token).catch(()=>{});asset=r.token}
    if(r.raw){try{const dec=asset?(await meta(asset)).decimals:18;amount=ethers.formatUnits(BigInt(r.raw.replace(/e(\d+)$/,(x,e)=>'0'.repeat(+e))),dec)}catch{}}
    await refresh();
    return openSend(asset,{to:r.address,amount});
  }
  sheet('Scanned text',`<div class="mono2">${esc(r.text)}</div><button class="btn ghost sm" data-act="copyText" data-t="${esc(r.text)}">Copy</button>`);
}

function nav(tab){
  S.tab=tab;
  document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===tab));
  document.querySelectorAll('.tabpage').forEach(p=>p.classList.toggle('on',p.id==='t-'+tab));
  window.scrollTo(0,0);
  if(tab==='market')loadMarket();
  if(tab==='discover')renderDiscover($('bq').value.trim());
  if(tab==='me')renderMe();
  if(tab==='wallet'&&$('p-nfts').classList.contains('on'))renderNfts();
}
function wtab(t){
  document.querySelectorAll('.tabs .tab').forEach(x=>x.classList.toggle('on',x.dataset.tab===t));
  document.querySelectorAll('#t-wallet .pane').forEach(p=>p.classList.toggle('on',p.id==='p-'+t));
  if(t==='nfts')renderNfts();
}
function copyText(t,msg='Copied'){
  const done=()=>toast(msg,'ok');
  if(NATIVE&&typeof NATIVE.copy==='function'){nat('copy',t);return done()}
  (navigator.clipboard?.writeText(t)||Promise.reject()).then(done,()=>toast(t));
}

const NKINDS={tx:'Transaction updates',incoming:'Incoming transfers',jackpot:'Jackpot alerts',ending:'Jackpot ending soon',price:'Price alerts'};
const NDEF={tx:true,incoming:true,jackpot:true,ending:false,price:true,bg:true};
function nprefs(){return {...NDEF,...store.json('kw_nprefs',{})}}
function notifs(){return store.json('kw_notifs',[])}
function updateBadge(){const n=notifs().filter(x=>!x.read).length;const b=$('nBadge');if(!b)return;b.hidden=!n;b.textContent=n>9?'9+':String(n)}
function pushNotif(n,{silent=false}={}){
  const p=nprefs();if(p[n.kind]===false)return;
  const l=notifs();
  const item={id:'n'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),ts:Date.now(),read:false,...n};
  l.unshift(item);store.put('kw_notifs',l.slice(0,100));updateBadge();repaintIf('notifs');
  if(silent)return;
  if(document.hidden||S.pausedAt)nat('notify',item.title,item.body||'',item.id);
  else if(n.toast!==false)toast(item.title+(item.body?' · '+item.body:''),'ok');
}
const jpKey=()=>'kw_jp_'+S.chain;
const snapKey=()=>'kw_snap_'+S.chain;
function myAddrs(){return walletsAll().map(w=>w.address.toLowerCase())}
function checkIncoming(){
  if(!S.address||!S.tokens.length)return;
  const all=store.json(snapKey(),{}),k=S.address.toLowerCase(),prev=all[k];
  const cur={ts:Date.now(),bnb:String(S.bnb),t:{}};
  S.tokens.forEach(t=>cur.t[t.addr.toLowerCase()]=String(t.bal));
  all[k]=cur;store.put(snapKey(),all);
  if(!prev)return;
  const since=(prev.ts||0)-90000;
  const skip=new Set(getAct().filter(a=>a.ts>=since&&a.recv!==undefined).map(a=>(a.recv||'bnb').toLowerCase()));
  const who=`${S.rec?.name||'Wallet'} · ${short(S.address)}`;
  const chk=(key,nv,ov,sym,dec)=>{
    if(ov===undefined||skip.has(key))return;
    let d;try{d=BigInt(nv)-BigInt(ov)}catch{return}
    if(d>0n)pushNotif({kind:'incoming',title:`Received ${fmt(d,dec)} ${sym}`,body:who,addr:S.address});
  };
  chk('bnb',cur.bnb,prev.bnb,net().sym,18);
  for(const t of S.tokens)chk(t.addr.toLowerCase(),cur.t[t.addr.toLowerCase()],prev.t?.[t.addr.toLowerCase()],t.symbol,t.decimals);
}
function checkJackpot(){
  const r=S.round;if(!r)return;
  const prev=store.json(jpKey(),null),mine=myAddrs(),km=kaviMeta(),zero=ethers.ZeroAddress.toLowerCase();
  const cur={round:r.no.toString(),leader:r.lead.toLowerCase(),endWarn:prev?.endWarn||'',wonWarn:prev?.wonWarn||''};
  const pot=`${fmt(r.pot,km.decimals)} ${km.symbol}`;
  if(prev){
    if(prev.round===cur.round&&mine.includes(prev.leader)&&prev.leader!==cur.leader&&cur.leader!==zero&&!mine.includes(cur.leader))
      pushNotif({kind:'jackpot',title:'Someone overtook you in the jackpot',body:`Pot ${pot}. Make a transaction to lead again.`});
    if(BigInt(cur.round)>BigInt(prev.round)&&mine.includes(prev.leader)&&prev.wonWarn!==prev.round)
      pushNotif({kind:'jackpot',title:`You won jackpot round ${prev.round}! 🏆`,body:'Your prize was sent to your wallet.'});
  }
  const left=r.end-Math.floor(Date.now()/1000);
  if(cur.leader!==zero&&left<=0&&mine.includes(cur.leader)&&cur.wonWarn!==cur.round){
    pushNotif({kind:'jackpot',title:`You won jackpot round ${cur.round}! 🏆`,body:'Open the Jackpot tab and tap Settle to receive your prize.'});cur.wonWarn=cur.round;
  }
  if(r.pot>0n&&left>0&&left<=300&&!mine.includes(cur.leader)&&cur.endWarn!==cur.round){
    pushNotif({kind:'ending',title:'Jackpot ends in under 5 minutes',body:`Pot ${pot}. Make a transaction to become the last player.`});cur.endWarn=cur.round;
  }
  store.put(jpKey(),cur);
}
function alerts(){return store.json('kw_alerts',[])}
function checkAlerts(){
  const l=alerts();let ch=false;
  for(const a of l){
    if(!a.on||a.chain!==S.chain)continue;
    const p=priceUsd(a.token);if(p===null||!isFinite(p))continue;
    if((a.dir==='above'&&p>=a.price)||(a.dir==='below'&&p<=a.price)){
      a.on=false;a.hit=Date.now();ch=true;
      pushNotif({kind:'price',title:`${a.sym} is ${a.dir} $${a.price}`,body:`Price now ${priceFmt(p)}`});
    }
  }
  if(ch){store.put('kw_alerts',l);repaintIf('alerts');bgSync()}
}
function notifTick(){try{checkJackpot();checkIncoming();checkAlerts()}catch(e){console.warn(e)}}

function metaCacheSave(){try{const m={};for(const[k,v]of Object.entries(S.meta))if(v&&v.symbol!=='???')m[k]={symbol:v.symbol,decimals:v.decimals};store.put('kw_meta_'+S.chain,m)}catch{}}
let bgT=0;
function bgSync(force){
  if(!NATIVE||typeof NATIVE.bgSync!=='function'||!S.hubAddr||!S.kavi)return;
  if(!force&&Date.now()-bgT<30000)return;
  bgT=Date.now();metaCacheSave();
  const mc=store.json('kw_meta_'+S.chain,{});
  const wallets=walletsAll().map(w=>{
    let l=store.json(`kw_tokens_${S.chain}_${w.address}`,null);if(!Array.isArray(l))l=S.kaviQuote?[S.kaviQuote]:[];
    const list=[S.kavi,...l.filter(a=>!eq(a,S.kavi))];
    return {address:w.address,name:w.name,tokens:list.map(a=>({a,s:mc[a.toLowerCase()]?.symbol||'tokens',d:mc[a.toLowerCase()]?.decimals??18}))};
  });
  const cfg={v:1,chain:S.chain,rpcs:rpcUrls(),hub:S.hubAddr,kavi:S.kavi,kaviSym:kaviMeta().symbol,kaviDec:kaviMeta().decimals,sym:net().sym,gecko:net().gecko,wbnb:net().wbnb,
    prefs:nprefs(),wallets,alerts:alerts().filter(a=>a.on&&a.chain===S.chain),snap:store.json(snapKey(),{}),jp:store.json(jpKey(),null)};
  nat('bgSync',JSON.stringify(cfg));
}
function bgPull(){
  const raw=nat('bgPull');if(!raw)return;
  let o;try{o=JSON.parse(raw)}catch{return}
  const al=alerts();let ach=false;
  for(const e of o.events||[]){
    if(e.alertId){const a=al.find(x=>x.id===e.alertId);if(a){a.on=false;a.hit=e.ts;ach=true}}
    if(e.title)pushNotif({kind:e.kind||'incoming',title:e.title,body:e.body||'',ts:e.ts||Date.now()},{silent:true});
  }
  if(ach)store.put('kw_alerts',al);
  if(o.snap&&typeof o.snap==='object'){
    const loc=store.json(snapKey(),{});
    for(const[k,v]of Object.entries(o.snap))if(!loc[k]||(v.ts||0)>(loc[k].ts||0))loc[k]=v;
    store.put(snapKey(),loc);
  }
  if(o.jp&&o.jp.round){const loc=store.json(jpKey(),null);if(!loc||BigInt(o.jp.round)>=BigInt(loc.round))store.put(jpKey(),{...loc,...o.jp})}
}

const BELL='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15zM10 20a2 2 0 0 0 4 0"/></svg>';
const NICON={tx:'<path d="M7 17 17 7M8 7h9v9"/>',incoming:'<path d="M17 7 7 17M16 17H7V8"/>',jackpot:'<path d="M8 4h8v4a4 4 0 0 1-8 0zM6 5H4v2a3 3 0 0 0 3 3M18 5h2v2a3 3 0 0 1-3 3M12 12v4M8 20h8M10 16h4v4h-4z"/>',ending:'<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',price:'<path d="M4 19V5M4 19h16M8 15l4-4 3 3 5-6"/>'};
function openNotifs(){
  page('Notifications',()=>{
    const l=notifs();
    return (l.length?l.map(n=>`<button class="row nrow ${n.read?'':'unread'}" data-act="notifOpen" data-id="${n.id}"><div class="ic" style="background:${n.kind==='incoming'?'rgba(46,189,133,.15)':n.kind==='jackpot'||n.kind==='ending'?'rgba(240,185,11,.15)':'var(--card2)'};color:${n.kind==='incoming'?'var(--ok)':n.kind==='jackpot'||n.kind==='ending'?'var(--acc)':'var(--mut)'}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${NICON[n.kind]||NICON.tx}</svg></div><div class="n"><b>${esc(n.title)}</b><span>${esc(n.body||'')}</span><span>${new Date(n.ts).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</span></div>${n.read?'':'<i class="udot"></i>'}</button>`).join(''):'<div class="empty">No notifications yet</div>')
      +(l.length?'<div class="gap"></div><div class="grid2"><button class="btn ghost sm" data-act="notifReadAll">Mark all read</button><button class="btn ghost sm" data-act="notifClear">Clear all</button></div>':'');
  },{key:'notifs',act:`<button class="ib2" data-act="notifSettings" aria-label="Notification settings"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>`});
}
function notifPermState(){const s=nat('notifStatus');return typeof s==='string'?s:(NATIVE?'unavailable':'granted')}
function openNotifSettings(){
  page('Notification settings',()=>{
    const p=nprefs(),st=notifPermState();
    return `${st==='denied'||st==='ask'?`<div class="warnbox">Phone notifications are turned off for Kavi Wallet. You'll still see them in the app.</div><button class="btn sm" data-act="notifAllow">Allow notifications</button><div class="gap"></div>`:''}
    <div class="grp">${Object.entries(NKINDS).map(([k,l])=>`<button class="li" data-act="nToggle" data-k="${k}"><div class="lt"><b>${l}</b><span>${{tx:'Confirmed and failed transactions',incoming:'BNB and tokens received',jackpot:'Overtaken or won',ending:'Last 5 minutes of a round',price:'When a token reaches your price'}[k]}</span></div>${sw(p[k])}</button>`).join('')}</div>
    <div class="grp"><button class="li" data-act="alertsPage"><div class="lt"><b>Manage price alerts</b><span>${alerts().filter(a=>a.on).length} active</span></div><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8b949e" stroke-width="2"><path d="m9 6 6 6-6 6"/></svg></button></div>
    <div class="grp"><button class="li" data-act="nToggle" data-k="bg"><div class="lt"><b>Check when app is closed</b><span>About every 15 minutes, uses a little data and battery</span></div>${sw(p.bg)}</button></div>`;
  },{key:'nset'});
}
function alertAssets(){
  const m=new Map();
  assets().forEach(a=>m.set((a.addr||'').toLowerCase(),{addr:a.addr,symbol:a.symbol}));
  if(S.chain===56)POPULAR.forEach(p=>{if(!m.has(p[0].toLowerCase()))m.set(p[0].toLowerCase(),{addr:p[0],symbol:p[1]})});
  return [...m.values()];
}
function openAlerts(){
  page('Price alerts',()=>{
    const l=alerts().filter(a=>a.chain===S.chain);
    return `<div class="note">Get notified when a token goes above or below a price (in USD). Each alert fires once.</div>
    <div class="f"><label>Token</label><div class="inp"><select id="alT">${alertAssets().map(a=>`<option value="${a.addr}">${esc(a.symbol)}</option>`).join('')}</select></div><div class="sub" id="alNow" style="margin-top:4px"></div></div>
    <div class="seg" id="alDir"><button data-act="alDir" data-v="above" class="on">Goes above</button><button data-act="alDir" data-v="below">Goes below</button></div>
    <div class="f"><label>Price (USD)</label><div class="inp"><span class="sub">$</span><input id="alP" inputmode="decimal" placeholder="0.00"></div></div>
    <button class="btn" data-act="alAdd">Add alert</button>
    <div class="gt">Your alerts</div>
    ${l.length?l.map(a=>`<div class="drow"><div class="row"><div class="ic" style="background:var(--card2);color:${a.on?'var(--acc)':'var(--mut)'}">${a.dir==='above'?'↑':'↓'}</div><div class="n"><b>${esc(a.sym)} ${a.dir} $${a.price}</b><span>${a.on?'Active':'Triggered '+new Date(a.hit||Date.now()).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</span></div></div><button class="chip" data-act="alDel" data-id="${a.id}">Delete</button></div>`).join(''):'<div class="empty">No price alerts</div>'}`;
  },{key:'alerts',onShow:()=>{const f=()=>{const a=$('alT').value;const p=priceUsd(a);$('alNow').textContent=p!==null?'Current price '+priceFmt(p):'';};$('alT').onchange=f;f();S.alDir='above'}});
}
function alAdd(){
  const a=$('alT').value,v=Number($('alP').value.trim());
  if(!(v>0))return toast('Enter a price','err');
  const sym=alertAssets().find(x=>eq(x.addr,a)||(!a&&!x.addr))?.symbol||'Token';
  const l=alerts();l.unshift({id:'a'+Date.now().toString(36),chain:S.chain,token:a,sym,dir:S.alDir||'above',price:v,on:true,created:Date.now()});
  store.put('kw_alerts',l.slice(0,50));
  const st=notifPermState();if(st==='ask')nat('notifPermission');
  paintPage();toast('Price alert added','ok');bgSync(true);
  if(a&&!(priceKey(a) in S.prices))meta(a).then(m=>priceOf(a,m.decimals)).then(p=>{S.prices[priceKey(a)]=p;checkAlerts()}).catch(()=>{});
  if(net().gecko)loadGecko([a||net().wbnb]).then(checkAlerts).catch(()=>{});else checkAlerts();
}

window.KaviHost={
  onDappRequest,
  onDappUrl(u){if(/^https?:/.test(u))addRecent(u)},
  onHttp(id,status,body){const p=S.http[id];if(!p)return;clearTimeout(p.t);delete S.http[id];if(status<=0)p.rej(new Error(body||'Network error'));else p.res({status,body})},
  onBio(json){let r;try{r=JSON.parse(json)}catch{r={ok:false}}const f=S.bioRes;S.bioRes=null;f&&f(r)},
  addFavorite(url,title){const on=toggleFav(url,title);toast(on?'Added to favorites':'Removed from favorites','ok');return on},
  isFavorite(url){return isFav(url)},
  disconnectSite(origin){setConnected(origin,false);renderDiscover($('bq')?.value.trim()||'');toast('Disconnected from '+hostOf(origin))},
  goHome(){closeSheet();closePage();nav('wallet')},
  onBack(){if($('scanner').classList.contains('on')){stopScan();return true}if(S.vkey&&['s-phrase','s-verify','s-import','s-password'].some(id=>$(id).classList.contains('on'))){show('s-main');return true}if(sheetOpen()){closeSheet();return true}if(S.pages.length){pageBack();return true}if(S.tab&&S.tab!=='wallet'&&$('s-main').classList.contains('on')){nav('wallet');return true}return false},
  onPause(){S.pausedAt=Date.now();bgSync(true)},
  onResume(){const was=S.pausedAt;S.pausedAt=0;if(S.vkey&&was&&Date.now()-was>autoLockMin()*60000){lock();return}bgPull();updateBadge();if(S.vkey)refresh()},
  onNotifPerm(){repaintIf('nset')},
};

const ACTIONS={
  close:closeSheet,pageBack,
  goCreate,goImport:el=>goImport(el.dataset.v||'phrase'),impMode:el=>impMode(el.dataset.v),onbBack,pwNext,phraseNext,backPhrase(){show('s-phrase')},verifyDone,doImport,doUnlock,bioUnlock,
  forgot(){sheet('Forgot password',`<div class="note">Your password can't be recovered. To get back in, remove the wallets from this phone and import them again with their recovery phrases.</div><button class="btn danger" data-act="resetAsk">Remove wallets and restore</button>`)},
  resetAsk(){sheet('Remove all wallets',`<div class="warnbox">This removes every wallet from this phone. Your funds stay on the blockchain, but you can only get them back with your recovery phrases or private keys.</div><div class="f"><label>Type REMOVE to confirm</label><div class="inp"><input id="rmTxt" autocomplete="off" autocapitalize="characters"></div></div><button class="btn danger" data-act="resetGo">Remove everything</button>`)},
  resetGo(){if($('rmTxt').value.trim()!=='REMOVE')return toast('Type REMOVE to confirm','err');resetAll()},
  nav:el=>nav(el.dataset.v),wtab:el=>wtab(el.dataset.tab),
  copy(){copyText(S.address,'Address copied')},copyText:el=>copyText(el.dataset.t),
  shareAddr(){if(nat('share',S.address,'My Kavi Wallet address')===undefined&&!(NATIVE&&NATIVE.share))copyText(S.address,'Address copied')},
  copyKs(){copyText(S.ksJson,'Keystore copied')},shareKs(){if(NATIVE&&NATIVE.share)nat('share',S.ksJson,'Kavi Wallet keystore');else copyText(S.ksJson,'Keystore copied')},
  toggleHide(){store.set('kw_hide',hidden()?'0':'1');render();renderHeader();if(S.tab==='me')renderMe()},
  toggleSmall(){store.set('kw_small',store.get('kw_small')==='1'?'0':'1');render();if(S.tab==='me')renderMe()},
  walletPicker,addWalletMenu,manageWallets,walletDetail:el=>walletDetail(el.dataset.id),switchWallet:el=>switchWallet(el.dataset.id),
  renameWallet:el=>renameWallet(el.dataset.id),doRename:el=>doRename(el.dataset.id),
  showPhrase:el=>showSecret(el.dataset.id,'phrase'),exportKey:el=>showSecret(el.dataset.id,'key'),exportKeystore:el=>exportKeystore(el.dataset.id),
  removeWallet:el=>removeWallet(el.dataset.id),doRemoveWallet:el=>doRemoveWallet(el.dataset.id),
  askPwGo,lockNow(){lock()},changePassword,doChangePw,toggleBio,
  autoLock(){pickSheet('Auto-lock',[[1,'1 minute'],[5,'5 minutes'],[15,'15 minutes'],[60,'1 hour']],autoLockMin(),'setAutoLock')},
  setAutoLock(el){store.set('kw_autolock',el.dataset.v);closeSheet();renderMe()},
  currency(){pickSheet('Currency',[['USD','US Dollar ($)'],['INR','Indian Rupee (₹)']],curCode(),'setCur')},
  async setCur(el){store.set('kw_cur',el.dataset.v);closeSheet();await loadFx();render();renderMe()},
  netPicker(){pickSheet('Network',Object.entries(NETS).map(([id,n])=>[id,n.name,(store.get('kw_hub3_'+id)||n.hub)?'':'KaviHub not set']),S.chain,'setNet')},
  setNet(el){const n=Number(el.dataset.v);closeSheet();if(n===S.chain)return;if(!(store.get('kw_hub3_'+n)||NETS[n].hub))toast('Set the KaviHub address for this network in Me → Advanced','err');switchChain(n);renderMe()},
  nodes:nodesPage,
  pickNode(el){store.set('kw_rpc_'+S.chain,el.dataset.v);S.rpcIdx=0;makeProvider();initContracts();pageBack();toast('Node changed','ok');refresh();renderMe()},
  autoNode(){store.del('kw_rpc_'+S.chain);S.rpcIdx=0;makeProvider();initContracts();pageBack();renderMe();toast('Automatic node selection','ok')},
  customNode(){sheet('Custom RPC',`<div class="f"><label>RPC URL (https)</label><div class="inp"><input id="crU" placeholder="https://…" autocomplete="off" autocapitalize="off"></div></div><button class="btn" data-act="saveCustomNode">Test &amp; save</button>`)},
  async saveCustomNode(){const u=$('crU').value.trim();if(!/^https:\/\//.test(u))return toast('Enter an https URL','err');try{const r=await httpReq('POST',u,JSON.stringify({jsonrpc:'2.0',id:1,method:'eth_chainId',params:[]}));if(parseInt(JSON.parse(r.body).result,16)!==S.chain)throw new Error('This node is for a different network');store.set('kw_rpc_'+S.chain,u);S.rpcIdx=0;makeProvider();initContracts();closeSheet();pageBack();renderMe();toast('Custom node saved','ok')}catch(e){toast(e.message||'Node not reachable','err')}},
  gasDefault(){pickSheet('Default network fee speed',[['slow','Slow','Cheapest, may take longer'],['standard','Standard','Recommended'],['fast','Fast','Higher fee, confirms sooner']],gasMode(),'setGasDefault')},
  setGasDefault(el){store.set('kw_gas',el.dataset.v);closeSheet();renderMe()},
  gasSel(el){const v=el.dataset.v;document.querySelectorAll('.gasc button').forEach(b=>b.classList.toggle('on',b===el));const box=$('gasCustomBox');if(v==='custom'){box.hidden=false;const i=$('gasCustom');i.focus();i.oninput=()=>{if(/^[0-9]*\.?[0-9]+$/.test(i.value.trim())&&Number(i.value)>0)store.set('kw_gas',i.value.trim())};if(/^[0-9]*\.?[0-9]+$/.test(i.value.trim()))store.set('kw_gas',i.value.trim())}else{box.hidden=true;store.set('kw_gas',v)}},
  scanKey(){sheet('Explorer API key',`<div class="note">Get a free API key at etherscan.io (it works for BNB Chain). It's used only to load your full transaction history.</div><div class="f"><div class="inp"><input id="skK" value="${esc(store.get('kw_scankey')||'')}" placeholder="API key" autocomplete="off" autocapitalize="off"></div></div><button class="btn" data-act="saveScanKey">Save</button>`)},
  saveScanKey(){const k=$('skK').value.trim();if(k)store.set('kw_scankey',k);else store.del('kw_scankey');closeSheet();renderMe();repaintIf('history');toast('Saved','ok')},
  advanced(){sheet('Advanced',`<div class="f"><label>KaviHub address (${net().name})</label><div class="inp"><input id="stH" value="${esc(hubAddr()||'')}" placeholder="0x…" autocomplete="off"></div></div><button class="btn" data-act="saveHub">Save</button>`)},
  saveHub(){const h=$('stH').value.trim();if(h&&!ethers.isAddress(h))return toast('Invalid address','err');if(!h||eq(h,net().hub))store.del('kw_hub3_'+S.chain);else store.set('kw_hub3_'+S.chain,h);closeSheet();S.kavi=null;route();toast('Saved','ok')},
  send:el=>openSend(el.dataset.addr||''),receive:openReceive,swap:()=>openSwap(),swapFrom:el=>openSwap(el.dataset.addr||'',el.dataset.addr?'':undefined),
  addToken:openAddToken,doAdd,
  async addPopular(el){const a=el.dataset.a;if(await addTokenAddr(a)){toast(`${S.meta[a.toLowerCase()].symbol} added`,'ok');if(sheetOpen())openAddToken();if(topPage()?.key?.startsWith('token:'))pageBack()}else toast('Already added')},
  tokenPage:el=>openTokenPage(el.dataset.addr||''),
  tf(el){S.tf=el.dataset.v;document.querySelectorAll('.tf button').forEach(b=>b.classList.toggle('on',b===el));$('chartBox').innerHTML='<div class="empty"><span class="spin" style="display:inline-block"></span></div>';loadChart(el.dataset.addr||'')},
  doRemove(el){const l=tokenList().filter(a=>!eq(a,el.dataset.addr));saveTokens(l);closeSheet();closePage();toast('Token hidden');refresh()},
  sMax,doSend,wMax,wFlip,doSwap,
  slip(el){swapSlip=+el.dataset.v;store.set('kw_slip',swapSlip);document.querySelectorAll('[data-act=slip]').forEach(b=>b.classList.toggle('on',b===el));quote()},
  pickAddr(el){$(el.dataset.target).value=el.dataset.a;$(el.dataset.target).dispatchEvent(new Event('input'))},
  notifs:openNotifs,notifSettings:openNotifSettings,alertsPage:openAlerts,alAdd,
  notifOpen(el){const l=notifs();const n=l.find(x=>x.id===el.dataset.id);if(!n)return;n.read=true;store.put('kw_notifs',l);updateBadge();if(n.hash&&getAct().some(a=>a.hash===n.hash))openHistItem(n.hash);else paintPage()},
  notifReadAll(){const l=notifs();l.forEach(x=>x.read=true);store.put('kw_notifs',l);updateBadge();paintPage()},
  notifClear(){store.put('kw_notifs',[]);updateBadge();paintPage()},
  nToggle(el){const k=el.dataset.k,p=nprefs();p[k]=!p[k];store.put('kw_nprefs',p);if(p[k]&&notifPermState()==='ask')nat('notifPermission');paintPage();bgSync(true)},
  notifAllow(){if(nat('notifPermission')==='settings')toast('Turn on notifications for Kavi Wallet in phone Settings');},
  alDir(el){S.alDir=el.dataset.v;document.querySelectorAll('#alDir button').forEach(b=>b.classList.toggle('on',b===el))},
  alDel(el){store.put('kw_alerts',alerts().filter(a=>a.id!==el.dataset.id));paintPage();bgSync(true)},
  history:openHistory,histTab(el){S.histTab=el.dataset.v;paintPage()},histOpen:el=>openHistItem(el.dataset.h),
  txSpeed:el=>replaceTx(el.dataset.h,false),txCancel:el=>replaceTx(el.dataset.h,true),
  saveContact:el=>{closeSheet();contactEdit(-1,el.dataset.a)},
  addNft:()=>{if(S.watch)return needSigner();openAddNft()},doAddNft,nftOpen:el=>openNft(+el.dataset.i),nftSend:el=>openNftSend(+el.dataset.i),doNftSend:el=>doNftSend(+el.dataset.i),
  nftRemove(el){const l=nftList();l.splice(+el.dataset.i,1);saveNfts(l);closePage();renderNfts()},
  approvals:openApprovals,apCheck,revoke:el=>revoke(el.dataset.t,el.dataset.s),
  batch:openBatch,doBatch,signTool:openSignTool,doSignTool,verifyTool:openVerifyTool,doVerifyTool,tokenCheck:openTokenCheck,doTokenCheck,
  contacts:openContacts,contactEdit:el=>contactEdit(+el.dataset.i),contactSave:el=>contactSave(+el.dataset.i),
  contactDel(el){const l=contacts();l.splice(+el.dataset.i,1);store.put('kw_contacts',l);closeSheet();repaintIf('contacts')},
  sitesPage,
  marketRefresh(){loadMarket(true)},
  openUrl:el=>{closeSheet();openUrl(el.dataset.url)},
  favToggle(el){const on=toggleFav(el.dataset.url);toast(on?'Added to favorites':'Removed from favorites')},
  cat(el){S.cat=el.dataset.v;renderDiscover($('bq').value.trim())},
  disconnectSite(el){setConnected(el.dataset.o,false);renderDiscover($('bq').value.trim());repaintIf('sites');toast('Disconnected')},
  reqYes,reqNo,
  scanMain(){startScan(handleScanMain)},
  scanInto(el){const id=el.dataset.target;startScan(t=>{const r=parseQr(t);const inp=$(id);if(!inp)return;inp.value=r.address||r.text||r.url||t;inp.dispatchEvent(new Event('input'))})},
  scanClose:stopScan,scanPhoto(){$('scanFile').click()},
  async settle(){await run('Settle jackpot',[{to:S.hubAddr,data:IF_HUB.encodeFunctionData('settleRound',[]),label:'Settle jackpot'}],{noFee:true,extra:{recv:S.kavi}})},
  async claim(){await run('Claim prize',[{to:S.hubAddr,data:IF_HUB.encodeFunctionData('claim',[]),label:'Claim prize'}],{noFee:true,extra:{recv:S.kavi}})}
};
$('scanFile').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(f)scanFromFile(f)});
$('bForm').addEventListener('submit',e=>{e.preventDefault();bGo()});
$('bq').addEventListener('input',()=>renderDiscover($('bq').value.trim()));
let mT;$('mq').addEventListener('input',()=>{clearTimeout(mT);mT=setTimeout(marketSearch,300)});
$('unlockPw').addEventListener('keydown',e=>{if(e.key==='Enter'){S.clicked=document.querySelector('[data-act=doUnlock]');doUnlock()}});
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-act]');if(!el)return;
  const f=ACTIONS[el.dataset.act];if(!f)return;
  if(el.tagName==='A')return;
  e.preventDefault();S.clicked=el;S.lastActive=Date.now();
  Promise.resolve().then(()=>f(el)).catch(err=>{console.error(err);toast(errMsg(err),'err')});
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)KaviHost.onPause();else KaviHost.onResume()});

if(hasVault())showUnlock();else show('s-welcome');
