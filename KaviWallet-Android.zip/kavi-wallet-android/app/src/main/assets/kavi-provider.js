(function () {
  if (window.__kaviProvider) return;
  var bridge = window.kaviBridge;
  if (!bridge) return;
  window.__kaviProvider = true;

  var seq = 0, pending = {}, listeners = {}, state = { chainId: null, accounts: [] };

  function err(code, message) { var e = new Error(message); e.code = code; return e; }

  function emit(ev, data) {
    (listeners[ev] || []).slice().forEach(function (fn) { try { fn(data); } catch (x) {} });
  }

  function onMessage(e) {
    var d;
    try { d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data; } catch (x) { return; }
    if (!d) return;
    if (d.event) {
      if (d.event === 'chainChanged') { state.chainId = d.data; emit('chainChanged', d.data); emit('networkChanged', String(parseInt(d.data, 16))); }
      else if (d.event === 'accountsChanged') { state.accounts = d.data || []; emit('accountsChanged', state.accounts); }
      else emit(d.event, d.data);
      return;
    }
    var p = pending[d.id];
    if (!p) return;
    delete pending[d.id];
    if (d.error) p.reject(err(d.error.code || -32603, d.error.message || 'Request failed'));
    else p.resolve(d.result);
  }

  if (typeof bridge.addEventListener === 'function') bridge.addEventListener('message', onMessage);
  else bridge.onmessage = onMessage;

  function call(method, params) {
    return new Promise(function (resolve, reject) {
      var id = ++seq;
      pending[id] = { resolve: resolve, reject: reject };
      bridge.postMessage(JSON.stringify({ id: id, method: method, params: params === undefined ? [] : params }));
    });
  }

  var provider = {
    isKaviWallet: true,
    isMetaMask: true,
    _metamask: { isUnlocked: function () { return Promise.resolve(true); } },
    get chainId() { return state.chainId; },
    get networkVersion() { return state.chainId ? String(parseInt(state.chainId, 16)) : null; },
    get selectedAddress() { return state.accounts[0] || null; },
    request: function (args) {
      if (!args || typeof args.method !== 'string') return Promise.reject(err(-32600, 'Invalid request'));
      var m = args.method;
      return call(m, args.params).then(function (r) {
        if (m === 'eth_chainId') state.chainId = r;
        if ((m === 'eth_requestAccounts' || m === 'eth_accounts') && Array.isArray(r)) {
          var changed = (r[0] || null) !== (state.accounts[0] || null);
          state.accounts = r;
          if (changed && m === 'eth_requestAccounts') emit('accountsChanged', r);
        }
        return r;
      });
    },
    enable: function () { return this.request({ method: 'eth_requestAccounts' }); },
    send: function (a, b) {
      if (typeof a === 'string') return this.request({ method: a, params: b });
      if (typeof b === 'function') { this.sendAsync(a, b); return; }
      return this.request(a);
    },
    sendAsync: function (payload, cb) {
      this.request(payload).then(function (r) { cb(null, { id: payload.id, jsonrpc: '2.0', result: r }); }, function (e) { cb(e, { id: payload.id, jsonrpc: '2.0', error: { code: e.code, message: e.message } }); });
    },
    isConnected: function () { return true; },
    on: function (ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); return this; },
    once: function (ev, fn) { var self = this; function w(d) { self.removeListener(ev, w); fn(d); } return this.on(ev, w); },
    addListener: function (ev, fn) { return this.on(ev, fn); },
    removeListener: function (ev, fn) { listeners[ev] = (listeners[ev] || []).filter(function (f) { return f !== fn; }); return this; },
    off: function (ev, fn) { return this.removeListener(ev, fn); },
    removeAllListeners: function (ev) { if (ev) delete listeners[ev]; else listeners = {}; return this; }
  };

  call('eth_chainId').then(function (c) { state.chainId = c; emit('connect', { chainId: c }); }, function () {});
  call('eth_accounts').then(function (a) { if (Array.isArray(a)) state.accounts = a; }, function () {});

  try { Object.defineProperty(window, 'ethereum', { value: provider, writable: false, configurable: false }); }
  catch (x) { try { window.ethereum = provider; } catch (y) {} }

  var icon = 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#f0b90b"/><text x="32" y="44" font-family="Arial" font-weight="700" font-size="34" text-anchor="middle" fill="#1a1400">K</text></svg>');
  var detail = Object.freeze({ info: Object.freeze({ uuid: '4c3f2a1b-5d6e-4f70-8a9b-0c1d2e3f4a5b', name: 'Kavi Wallet', icon: icon, rdns: 'app.kaviwallet' }), provider: provider });
  function announce() { window.dispatchEvent(new CustomEvent('eip6963:announceProvider', { detail: detail })); }
  window.addEventListener('eip6963:requestProvider', announce);
  announce();
  window.dispatchEvent(new Event('ethereum#initialized'));
})();
