package app.kaviwallet;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class WidgetWorker extends Worker {
    public WidgetWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            KaviWidgets.refreshNow(getApplicationContext());
        } catch (Exception ignored) {
        }
        return Result.success();
    }
}
