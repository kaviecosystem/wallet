package app.kaviwallet;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class KaviWorker extends Worker {
    static final String PREFS = "kavi_bg";
    private static final String SEL_BALANCE_OF = "0x70a08231";
    private static final String SEL_ROUND_INFO = "0xcace12e6";

    private JSONArray rpcs;
    private JSONArray events;
    private SharedPreferences sp;

    public KaviWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        if (MainActivity.foreground) return Result.success();
        Context ctx = getApplicationContext();
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            JSONObject cfg = new JSONObject(sp.getString("cfg", "{}"));
            JSONObject prefs = cfg.optJSONObject("prefs");
            if (prefs == null || !prefs.optBoolean("bg", true)) return Result.success();
            rpcs = cfg.optJSONArray("rpcs");
            if (rpcs == null || rpcs.length() == 0) return Result.success();
            events = new JSONArray(sp.getString("events", "[]"));
            JSONObject snap = new JSONObject(sp.getString("snap", "{}"));
            JSONArray wallets = cfg.optJSONArray("wallets");
            if (wallets == null) wallets = new JSONArray();
            Set<String> mine = new HashSet<>();
            for (int i = 0; i < wallets.length(); i++) mine.add(wallets.getJSONObject(i).getString("address").toLowerCase(Locale.ROOT));

            if (prefs.optBoolean("incoming", true)) checkIncoming(ctx, cfg, wallets, snap);
            if (prefs.optBoolean("jackpot", true)) checkJackpot(ctx, cfg, mine);
            if (prefs.optBoolean("price", true)) checkAlerts(ctx, cfg);

            while (events.length() > 50) events.remove(0);
            sp.edit().putString("snap", snap.toString()).putString("events", events.toString()).putString("cfg", cfg.toString()).apply();
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private void checkIncoming(Context ctx, JSONObject cfg, JSONArray wallets, JSONObject snap) throws Exception {
        String sym = cfg.optString("sym", "BNB");
        for (int i = 0; i < wallets.length(); i++) {
            JSONObject w = wallets.getJSONObject(i);
            String addr = w.getString("address").toLowerCase(Locale.ROOT);
            String name = w.optString("name", "Wallet");
            JSONObject prev = snap.optJSONObject(addr);
            JSONObject cur = new JSONObject();
            JSONObject t = new JSONObject();
            String bnb = hexToDec(rpc("eth_getBalance", new JSONArray().put(addr).put("latest")));
            cur.put("bnb", bnb);
            JSONArray tokens = w.optJSONArray("tokens");
            if (tokens == null) tokens = new JSONArray();
            for (int j = 0; j < tokens.length(); j++) {
                JSONObject tk = tokens.getJSONObject(j);
                String ta = tk.getString("a").toLowerCase(Locale.ROOT);
                try {
                    t.put(ta, hexToDec(ethCall(ta, SEL_BALANCE_OF + pad(addr))));
                } catch (Exception ignored) {
                }
            }
            cur.put("t", t);
            cur.put("ts", System.currentTimeMillis());
            if (prev != null) {
                String body = name + " · " + addr.substring(0, 6) + "…" + addr.substring(addr.length() - 4);
                notifyIncrease(ctx, prev.optString("bnb", null), bnb, sym, 18, body);
                JSONObject pt = prev.optJSONObject("t");
                for (int j = 0; j < tokens.length(); j++) {
                    JSONObject tk = tokens.getJSONObject(j);
                    String ta = tk.getString("a").toLowerCase(Locale.ROOT);
                    if (pt == null || !pt.has(ta) || !t.has(ta)) continue;
                    notifyIncrease(ctx, pt.optString(ta, null), t.optString(ta), tk.optString("s", "tokens"), tk.optInt("d", 18), body);
                }
            }
            snap.put(addr, cur);
        }
    }

    private void notifyIncrease(Context ctx, String oldV, String newV, String sym, int dec, String body) throws Exception {
        if (oldV == null || newV == null) return;
        BigInteger d = new BigInteger(newV).subtract(new BigInteger(oldV));
        if (d.signum() <= 0) return;
        post(ctx, "incoming", "Received " + format(d, dec) + " " + sym, body, null);
    }

    private void checkJackpot(Context ctx, JSONObject cfg, Set<String> mine) throws Exception {
        String hub = cfg.optString("hub", "");
        if (hub.isEmpty()) return;
        String r = ethCall(hub, SEL_ROUND_INFO);
        String h = r.startsWith("0x") ? r.substring(2) : r;
        if (h.length() < 64 * 4) return;
        BigInteger round = new BigInteger(h.substring(0, 64), 16);
        BigInteger pot = new BigInteger(h.substring(64, 128), 16);
        String leader = "0x" + h.substring(128 + 24, 192).toLowerCase(Locale.ROOT);
        long end = new BigInteger(h.substring(192, 256), 16).longValue();
        JSONObject prev = cfg.optJSONObject("jp");
        JSONObject cur = new JSONObject();
        cur.put("round", round.toString());
        cur.put("leader", leader);
        cur.put("endWarn", prev == null ? "" : prev.optString("endWarn", ""));
        cur.put("wonWarn", prev == null ? "" : prev.optString("wonWarn", ""));
        String zero = "0x0000000000000000000000000000000000000000";
        String potS = format(pot, cfg.optInt("kaviDec", 18)) + " " + cfg.optString("kaviSym", "KAVI");
        if (prev != null && prev.has("round")) {
            String pr = prev.optString("round");
            String pl = prev.optString("leader", "");
            if (pr.equals(cur.getString("round")) && mine.contains(pl) && !pl.equals(leader) && !leader.equals(zero) && !mine.contains(leader)) {
                post(ctx, "jackpot", "Someone overtook you in the jackpot", "Pot " + potS + ". Make a transaction to lead again.", null);
            }
            if (round.compareTo(new BigInteger(pr)) > 0 && mine.contains(pl) && !pr.equals(prev.optString("wonWarn"))) {
                post(ctx, "jackpot", "You won jackpot round " + pr + "! 🏆", "Your prize was sent to your wallet.", null);
            }
        }
        long now = System.currentTimeMillis() / 1000;
        if (!leader.equals(zero) && end <= now && mine.contains(leader) && !round.toString().equals(cur.optString("wonWarn"))) {
            post(ctx, "jackpot", "You won jackpot round " + round + "! 🏆", "Open Kavi Wallet and tap Settle to receive your prize.", null);
            cur.put("wonWarn", round.toString());
        }
        cfg.put("jp", cur);
        sp.edit().putString("jp", cur.toString()).apply();
    }

    private void checkAlerts(Context ctx, JSONObject cfg) throws Exception {
        JSONArray alerts = cfg.optJSONArray("alerts");
        String gecko = cfg.optString("gecko", "");
        if (alerts == null || alerts.length() == 0 || gecko.isEmpty()) return;
        String wbnb = cfg.optString("wbnb", "").toLowerCase(Locale.ROOT);
        Set<String> addrs = new HashSet<>();
        for (int i = 0; i < alerts.length(); i++) {
            String tk = alerts.getJSONObject(i).optString("token", "");
            addrs.add(tk.isEmpty() ? wbnb : tk.toLowerCase(Locale.ROOT));
        }
        String url = "https://api.geckoterminal.com/api/v2/simple/networks/" + gecko + "/token_price/" + String.join(",", addrs);
        JSONObject j = new JSONObject(http("GET", url, null));
        JSONObject prices = j.getJSONObject("data").getJSONObject("attributes").getJSONObject("token_prices");
        JSONArray keep = new JSONArray();
        for (int i = 0; i < alerts.length(); i++) {
            JSONObject a = alerts.getJSONObject(i);
            String tk = a.optString("token", "");
            String key = tk.isEmpty() ? wbnb : tk.toLowerCase(Locale.ROOT);
            String ps = null;
            if (prices.has(key)) ps = prices.optString(key, null);
            else {
                java.util.Iterator<String> it = prices.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (k.equalsIgnoreCase(key)) ps = prices.optString(k, null);
                }
            }
            if (ps == null || ps.equals("null")) {
                keep.put(a);
                continue;
            }
            double p = Double.parseDouble(ps);
            double target = a.optDouble("price", 0);
            boolean hit = "above".equals(a.optString("dir")) ? p >= target : p <= target;
            if (hit) {
                String title = a.optString("sym", "Token") + " is " + a.optString("dir") + " $" + strip(target);
                post(ctx, "price", title, "Price now $" + strip(p), a.optString("id"));
            } else {
                keep.put(a);
            }
        }
        cfg.put("alerts", keep);
    }

    private void post(Context ctx, String kind, String title, String body, String alertId) throws Exception {
        int id = sp.getInt("nid", 1000) + 1;
        sp.edit().putInt("nid", id).apply();
        NotifHelper.post(ctx, title, body, id);
        JSONObject e = new JSONObject();
        e.put("kind", kind);
        e.put("title", title);
        e.put("body", body);
        e.put("ts", System.currentTimeMillis());
        if (alertId != null) e.put("alertId", alertId);
        events.put(e);
    }

    private static String strip(double d) {
        return new BigDecimal(d).round(new java.math.MathContext(6)).stripTrailingZeros().toPlainString();
    }

    private static String format(BigInteger v, int dec) {
        BigDecimal b = new BigDecimal(v).movePointLeft(dec);
        int scale = b.compareTo(BigDecimal.ONE) >= 0 ? 4 : 8;
        b = b.setScale(Math.min(Math.max(b.scale(), 0), scale), RoundingMode.DOWN).stripTrailingZeros();
        return b.toPlainString();
    }

    private static String pad(String addr) {
        String a = addr.startsWith("0x") ? addr.substring(2) : addr;
        StringBuilder sb = new StringBuilder();
        for (int i = a.length(); i < 64; i++) sb.append('0');
        return sb.append(a.toLowerCase(Locale.ROOT)).toString();
    }

    private static String hexToDec(String hex) {
        String h = hex.startsWith("0x") ? hex.substring(2) : hex;
        if (h.isEmpty()) return "0";
        return new BigInteger(h, 16).toString();
    }

    private String ethCall(String to, String data) throws Exception {
        JSONObject tx = new JSONObject().put("to", to).put("data", data);
        return rpc("eth_call", new JSONArray().put(tx).put("latest"));
    }

    private String rpc(String method, JSONArray params) throws Exception {
        String body = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", method).put("params", params).toString();
        Exception last = null;
        for (int i = 0; i < rpcs.length(); i++) {
            try {
                JSONObject r = new JSONObject(http("POST", rpcs.getString(i), body));
                if (r.has("error")) throw new Exception(r.getJSONObject("error").optString("message"));
                return r.getString("result");
            } catch (Exception e) {
                last = e;
            }
        }
        throw last == null ? new Exception("No RPC") : last;
    }

    private static String http(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "KaviWallet/2.0 Android");
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(b.length);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(b);
                }
            }
            int st = c.getResponseCode();
            if (st < 200 || st >= 300) throw new Exception("HTTP " + st);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 2 * 1024 * 1024) throw new Exception("Too large");
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            c.disconnect();
        }
    }
}
