package app.kaviwallet;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String WALLET_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final String WALLET_HOST = "appassets.androidplatform.net";
    private static final int BG = Color.parseColor("#0B0E11");
    private static final int BAR = Color.parseColor("#151A1F");
    private static final int TEXT = Color.parseColor("#EAECEF");
    private static final int MUTED = Color.parseColor("#8B949E");

    private WebView wallet;
    private WebView dapp;
    private LinearLayout dappBox;
    private TextView urlView;
    private ProgressBar progress;
    private WebViewAssetLoader assetLoader;

    private final Map<String, JavaScriptReplyProxy> proxies = new HashMap<>();
    private JavaScriptReplyProxy lastProxy;
    private int seq = 0;
    private boolean bridgeReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(WALLET_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        dappBox = buildDappBox();
        dappBox.setVisibility(View.GONE);
        root.addView(dappBox, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        wallet = new WebView(this);
        wallet.setBackgroundColor(BG);
        root.addView(wallet, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);

        setupWallet();
        setupDapp();

        if (savedInstanceState == null) {
            wallet.loadUrl(WALLET_URL);
        } else {
            wallet.restoreState(savedInstanceState);
            if (wallet.getUrl() == null) wallet.loadUrl(WALLET_URL);
        }
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView barButton(String label, View.OnClickListener click) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(click);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private LinearLayout buildDappBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(BAR);
        bar.setPadding(dp(4), 0, dp(4), 0);

        bar.addView(barButton("✕", v -> closeDapp()));
        bar.addView(barButton("‹", v -> {
            if (dapp.canGoBack()) dapp.goBack();
        }));

        urlView = new TextView(this);
        urlView.setTextColor(MUTED);
        urlView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        urlView.setTypeface(Typeface.DEFAULT_BOLD);
        urlView.setSingleLine(true);
        urlView.setEllipsize(TextUtils.TruncateAt.END);
        urlView.setGravity(Gravity.CENTER);
        bar.addView(urlView, new LinearLayout.LayoutParams(0, dp(52), 1f));

        bar.addView(barButton("↻", v -> dapp.reload()));
        bar.addView(barButton("⌂", v -> showWalletHome()));

        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        box.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        dapp = new WebView(this);
        dapp.setBackgroundColor(Color.WHITE);
        box.addView(dapp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWallet() {
        WebSettings s = wallet.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setTextZoom(100);
        wallet.addJavascriptInterface(new Bridge(), "KaviNative");
        wallet.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (WALLET_HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });
        wallet.setWebChromeClient(new WebChromeClient());
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupDapp() {
        WebSettings s = dapp.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString(s.getUserAgentString() + " KaviWallet/1.0");
        CookieManager.getInstance().setAcceptThirdPartyCookies(dapp, true);

        Set<String> all = Collections.singleton("*");
        boolean canInject = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        boolean canMessage = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER);
        if (canInject && canMessage) {
            WebViewCompat.addWebMessageListener(dapp, "kaviBridge", all, new WebViewCompat.WebMessageListener() {
                @Override
                public void onPostMessage(WebView view, WebMessageCompat message, Uri sourceOrigin, boolean isMainFrame, JavaScriptReplyProxy replyProxy) {
                    onDappMessage(message.getData(), sourceOrigin.toString(), replyProxy);
                }
            });
            WebViewCompat.addDocumentStartJavaScript(dapp, readAsset("kavi-provider.js"), all);
            bridgeReady = true;
        }

        dapp.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                if (scheme.equals("https") || scheme.equals("http")) return false;
                if (scheme.equals("about") || scheme.equals("data") || scheme.equals("blob") || scheme.equals("javascript")) return false;
                openExternal(u.toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                setUrl(url);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                setUrl(url);
                progress.setVisibility(View.GONE);
                if (url != null && url.startsWith("http")) {
                    wallet.evaluateJavascript("window.KaviHost&&KaviHost.onDappUrl(" + JSONObject.quote(url) + ")", null);
                }
            }
        });
        dapp.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
    }

    private void setUrl(String url) {
        if (url == null) return;
        Uri u = Uri.parse(url);
        String host = u.getHost();
        urlView.setText(host != null ? host : url);
        urlView.setTextColor("https".equals(u.getScheme()) ? TEXT : MUTED);
    }

    private void onDappMessage(String data, String origin, JavaScriptReplyProxy reply) {
        if (data == null) return;
        String id = "n" + (++seq);
        proxies.put(id, reply);
        lastProxy = reply;
        String js = "window.KaviHost&&KaviHost.onDappRequest(" + JSONObject.quote(id) + "," + JSONObject.quote(data) + "," + JSONObject.quote(origin) + ")";
        wallet.evaluateJavascript(js, null);
    }

    private void openDapp(String url) {
        if (!bridgeReady) {
            Toast.makeText(this, "Please update Android System WebView from the Play Store to use dApps", Toast.LENGTH_LONG).show();
            return;
        }
        proxies.clear();
        lastProxy = null;
        dappBox.setVisibility(View.VISIBLE);
        wallet.setVisibility(View.GONE);
        setUrl(url);
        dapp.loadUrl(url);
    }

    private void closeDapp() {
        dapp.stopLoading();
        dapp.loadUrl("about:blank");
        dapp.clearHistory();
        proxies.clear();
        lastProxy = null;
        dappBox.setVisibility(View.GONE);
        wallet.setVisibility(View.VISIBLE);
    }

    private void showWalletHome() {
        wallet.setVisibility(View.VISIBLE);
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.goHome&&KaviHost.goHome()", null);
        closeDapp();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void openDapp(final String url) {
            runOnUiThread(() -> MainActivity.this.openDapp(url));
        }

        @JavascriptInterface
        public void closeDapp() {
            runOnUiThread(MainActivity.this::closeDapp);
        }

        @JavascriptInterface
        public void showWallet() {
            runOnUiThread(() -> wallet.setVisibility(View.VISIBLE));
        }

        @JavascriptInterface
        public void showDapp() {
            runOnUiThread(() -> {
                if (dappBox.getVisibility() == View.VISIBLE) wallet.setVisibility(View.GONE);
            });
        }

        @JavascriptInterface
        public void dappReply(final String id, final String json) {
            runOnUiThread(() -> {
                JavaScriptReplyProxy p = proxies.remove(id);
                if (p != null) {
                    try {
                        p.postMessage(json);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void dappEvent(final String json) {
            runOnUiThread(() -> {
                if (lastProxy != null) {
                    try {
                        lastProxy.postMessage(json);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            runOnUiThread(() -> MainActivity.this.openExternal(url));
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Kavi Wallet", text));
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (dappBox.getVisibility() == View.VISIBLE && wallet.getVisibility() != View.VISIBLE) {
            if (dapp.canGoBack()) dapp.goBack();
            else closeDapp();
            return;
        }
        wallet.evaluateJavascript("window.KaviHost?KaviHost.onBack():false", value -> {
            if (!"true".equals(value)) {
                if (dappBox.getVisibility() == View.VISIBLE) closeDapp();
                else moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.onPause()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.onResume()", null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        wallet.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (dapp != null) dapp.destroy();
        if (wallet != null) wallet.destroy();
        super.onDestroy();
    }
}
