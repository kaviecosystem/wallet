package app.kaviwallet;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.app.KeyguardManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.text.TextUtils;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.Iterator;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {

    private static final String WALLET_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final String WALLET_HOST = "appassets.androidplatform.net";
    private static final int BG_DARK = Color.parseColor("#0B0E11");
    private static final int BAR_DARK = Color.parseColor("#151A1F");
    private static final int TEXT_DARK = Color.parseColor("#EAECEF");
    private static final int MUTED_DARK = Color.parseColor("#8B949E");
    private static final int BG_LIGHT = Color.parseColor("#F5F6F8");
    private static final int BAR_LIGHT = Color.parseColor("#FFFFFF");
    private static final int TEXT_LIGHT = Color.parseColor("#1E2329");
    private static final int MUTED_LIGHT = Color.parseColor("#707A8A");
    private int BG = BG_DARK, BAR = BAR_DARK, TEXT = TEXT_DARK, MUTED = MUTED_DARK;
    private boolean darkUi = true;
    private FrameLayout rootView;
    private LinearLayout dappBar;
    private final java.util.List<TextView> barButtons = new java.util.ArrayList<>();
    private static final String BIO_KEY = "kavi_bio_key_v1";
    private static final String BIO_PREFS = "kavi_bio";
    private static final int REQ_CAMERA = 7;
    private static final int REQ_FILE = 8;
    private static final int REQ_NOTIF = 9;
    static volatile boolean foreground = false;
    private static final Set<String> APP_ACTIONS = new java.util.HashSet<>(java.util.Arrays.asList(
            "wallet", "send", "receive", "scan", "swap", "discover", "jackpot", "market", "history", "refresh"));
    private String pendingAction;
    private long pendingAt;
    private static final int MAX_BODY = 4 * 1024 * 1024;

    private WebView wallet;
    private WebView dapp;
    private LinearLayout dappBox;
    private TextView urlView;
    private ProgressBar progress;
    private WebViewAssetLoader assetLoader;

    private final Map<String, JavaScriptReplyProxy> proxies = new HashMap<>();
    private JavaScriptReplyProxy topProxy;
    private String topOrigin;
    private String pageOrigin;
    private int seq = 0;
    private boolean bridgeReady = false;
    private final ExecutorService http = Executors.newFixedThreadPool(6);
    private final Handler main = new Handler(Looper.getMainLooper());
    private PermissionRequest pendingPermission;
    private ValueCallback<Uri[]> fileCallback;
    private CancellationSignal bioCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(WALLET_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        darkUi = getSharedPreferences("kavi_ui", MODE_PRIVATE).getBoolean("dark", systemDark());
        setPalette(darkUi);
        FrameLayout root = new FrameLayout(this);
        rootView = root;
        root.setBackgroundColor(BG);

        dappBox = buildDappBox();
        dappBox.setVisibility(View.GONE);
        root.addView(dappBox, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        wallet = new WebView(this);
        wallet.setBackgroundColor(BG);
        root.addView(wallet, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        applyTheme(darkUi);
        if (Build.VERSION.SDK_INT >= 31) getWindow().setHideOverlayWindows(true);
        if (savedInstanceState == null) showSplash();

        setupWallet();
        setupDapp();

        if (savedInstanceState == null) {
            wallet.loadUrl(WALLET_URL);
        } else {
            wallet.restoreState(savedInstanceState);
            if (wallet.getUrl() == null) wallet.loadUrl(WALLET_URL);
        }
        handleAction(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handleAction(intent)) {
            if (dappBox.getVisibility() == View.VISIBLE) wallet.setVisibility(View.VISIBLE);
            jsCall("window.KaviHost&&KaviHost.onAction&&KaviHost.onAction()");
        }
    }

    private boolean handleAction(Intent intent) {
        if (intent == null) return false;
        Uri u = intent.getData();
        if (u == null || !"kaviwallet".equals(u.getScheme())) return false;
        String a = u.getHost();
        intent.setData(null);
        if (a == null || !APP_ACTIONS.contains(a)) return false;
        pendingAction = a;
        pendingAt = System.currentTimeMillis();
        return true;
    }

    private synchronized String takeAction() {
        String a = pendingAction;
        pendingAction = null;
        if (a == null || System.currentTimeMillis() - pendingAt > 5 * 60 * 1000L) return "";
        return a;
    }

    private String pinWidget(String kind) {
        if (Build.VERSION.SDK_INT < 26) return "unsupported";
        try {
            android.appwidget.AppWidgetManager m = getSystemService(android.appwidget.AppWidgetManager.class);
            if (m == null || !m.isRequestPinAppWidgetSupported()) return "unsupported";
            Class<?> cls = "actions".equals(kind) ? ActionsWidget.class : "jackpot".equals(kind) ? JackpotWidget.class : WalletWidget.class;
            return m.requestPinAppWidget(new android.content.ComponentName(this, cls), null, null) ? "ok" : "unsupported";
        } catch (Exception e) {
            return "unsupported";
        }
    }

    @SuppressWarnings("deprecation")
    private String signingKeySha() {
        try {
            android.content.pm.Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.getApkContentsSigners();
            } else {
                sigs = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES).signatures;
            }
            byte[] d = java.security.MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) {
                if (i > 0) sb.append(':');
                sb.append(String.format(java.util.Locale.US, "%02X", d[i]));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private android.widget.ImageView splashView;
    private long splashAt;
    private static final int SPLASH_BG = Color.parseColor("#F0B90B");

    @SuppressWarnings("deprecation")
    private void showSplash() {
        splashView = new android.widget.ImageView(this);
        splashView.setBackgroundColor(SPLASH_BG);
        splashView.setImageResource(R.drawable.splash_kw);
        splashView.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        splashView.setClickable(true);
        rootView.addView(splashView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splashAt = android.os.SystemClock.uptimeMillis();
        getWindow().setStatusBarColor(SPLASH_BG);
        getWindow().setNavigationBarColor(SPLASH_BG);
        View decor = getWindow().getDecorView();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
        decor.setSystemUiVisibility(decor.getSystemUiVisibility() | light);
        main.postDelayed(this::hideSplash, 6000);
    }

    private void hideSplash() {
        if (splashView == null) return;
        long left = 900 - (android.os.SystemClock.uptimeMillis() - splashAt);
        if (left > 0) {
            main.postDelayed(this::hideSplash, left);
            return;
        }
        final View v = splashView;
        splashView = null;
        applyTheme(darkUi);
        v.animate().alpha(0f).setDuration(280).withEndAction(() -> rootView.removeView(v)).start();
    }

    private boolean systemDark() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void setPalette(boolean dark) {
        BG = dark ? BG_DARK : BG_LIGHT;
        BAR = dark ? BAR_DARK : BAR_LIGHT;
        TEXT = dark ? TEXT_DARK : TEXT_LIGHT;
        MUTED = dark ? MUTED_DARK : MUTED_LIGHT;
    }

    @SuppressWarnings("deprecation")
    private void applyTheme(boolean dark) {
        darkUi = dark;
        getSharedPreferences("kavi_ui", MODE_PRIVATE).edit().putBoolean("dark", dark).apply();
        setPalette(dark);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (rootView != null) rootView.setBackgroundColor(BG);
        if (wallet != null) wallet.setBackgroundColor(BG);
        if (dappBox != null) dappBox.setBackgroundColor(BG);
        if (dappBar != null) dappBar.setBackgroundColor(BAR);
        for (TextView b : barButtons) b.setTextColor(TEXT);
        if (urlView != null && dapp != null) setUrl(dapp.getUrl());
        View decor = getWindow().getDecorView();
        int f = decor.getSystemUiVisibility();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
        decor.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
    }

    private long lastTouchPing;

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        long now = System.currentTimeMillis();
        if (now - lastTouchPing > 5000) {
            lastTouchPing = now;
            jsCall("window.KaviHost&&KaviHost.touch&&KaviHost.touch()");
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        jsCall("window.KaviHost&&KaviHost.onSysTheme&&KaviHost.onSysTheme()");
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView barButton(String label, View.OnClickListener click) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(click);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        barButtons.add(b);
        return b;
    }

    private LinearLayout buildDappBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        dappBar = bar;
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(BAR);
        bar.setPadding(dp(4), 0, dp(4), 0);

        bar.addView(barButton("✕", v -> closeDapp()));
        bar.addView(barButton("‹", v -> {
            if (dapp.canGoBack()) dapp.goBack();
        }));

        urlView = new TextView(this);
        urlView.setTextColor(MUTED);
        urlView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        urlView.setTypeface(Typeface.DEFAULT_BOLD);
        urlView.setSingleLine(true);
        urlView.setEllipsize(TextUtils.TruncateAt.START);
        urlView.setGravity(Gravity.CENTER);
        bar.addView(urlView, new LinearLayout.LayoutParams(0, dp(52), 1f));

        bar.addView(barButton("↻", v -> dapp.reload()));
        final TextView more = barButton("⋮", null);
        more.setOnClickListener(v -> showDappMenu(more));
        bar.addView(more);

        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        box.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        dapp = new WebView(this);
        dapp.setBackgroundColor(Color.WHITE);
        box.addView(dapp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private void showDappMenu(View anchor) {
        final String url = dapp.getUrl();
        if (url == null) return;
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Refresh");
        m.add(0, 2, 1, "Copy link");
        m.add(0, 3, 2, "Share");
        m.add(0, 4, 3, "Open in browser");
        m.add(0, 5, 4, "Add / remove favorite");
        m.add(0, 6, 5, "Disconnect this site");
        m.add(0, 7, 6, "Back to wallet");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    dapp.reload();
                    break;
                case 2:
                    copyText(url);
                    Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show();
                    break;
                case 3:
                    shareText(url, dapp.getTitle());
                    break;
                case 4:
                    openExternal(url);
                    break;
                case 5:
                    wallet.evaluateJavascript("window.KaviHost&&KaviHost.addFavorite(" + JSONObject.quote(url) + "," + JSONObject.quote(dapp.getTitle() == null ? "" : dapp.getTitle()) + ")", null);
                    Toast.makeText(this, "Favorites updated", Toast.LENGTH_SHORT).show();
                    break;
                case 6:
                    Uri u = Uri.parse(url);
                    String origin = u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
                    wallet.evaluateJavascript("window.KaviHost&&KaviHost.disconnectSite(" + JSONObject.quote(origin) + ")", null);
                    Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show();
                    dapp.reload();
                    break;
                case 7:
                    showWalletHome();
                    break;
            }
            return true;
        });
        pm.show();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private static boolean isWalletUrl(Uri u) {
        return u != null && "https".equals(u.getScheme()) && WALLET_HOST.equals(u.getHost()) && u.getPort() == -1
                && u.getPath() != null && u.getPath().startsWith("/assets/www/") && !u.getPath().contains("..");
    }

    private static String originOf(String url) {
        try {
            Uri u = Uri.parse(url);
            if (u.getScheme() == null || u.getHost() == null) return "";
            return u.getScheme() + "://" + u.getHost() + (u.getPort() == -1 ? "" : ":" + u.getPort());
        } catch (Exception e) {
            return "";
        }
    }

    private void setupWallet() {
        WebSettings s = wallet.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        wallet.addJavascriptInterface(new Bridge(), "KaviNative");
        wallet.setFilterTouchesWhenObscured(true);
        dappBox.setFilterTouchesWhenObscured(true);
        wallet.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && isWalletUrl(Uri.parse(url))) main.postDelayed(MainActivity.this::hideSplash, 150);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                WebResourceResponse res = isWalletUrl(u) ? assetLoader.shouldInterceptRequest(u) : null;
                if (res == null && (request.isForMainFrame() || !"https".equals(u.getScheme()) || WALLET_HOST.equals(u.getHost()))) {
                    return new WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", null, null);
                }
                return res;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (isWalletUrl(u)) return false;
                String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                if (sc.equals("https") && request.hasGesture()) openExternal(u.toString());
                return true;
            }
        });
        wallet.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                boolean wantsCamera = false;
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                }
                if (!wantsCamera || !WALLET_HOST.equals(request.getOrigin().getHost())) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    pendingPermission = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose a QR code image"), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupDapp() {
        WebSettings s = dapp.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString(s.getUserAgentString() + " KaviWallet/2.0");
        CookieManager.getInstance().setAcceptThirdPartyCookies(dapp, true);

        Set<String> all = Collections.singleton("*");
        boolean canInject = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        boolean canMessage = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER);
        if (canInject && canMessage) {
            WebViewCompat.addWebMessageListener(dapp, "kaviBridge", all, new WebViewCompat.WebMessageListener() {
                @Override
                public void onPostMessage(WebView view, WebMessageCompat message, Uri sourceOrigin, boolean isMainFrame, JavaScriptReplyProxy replyProxy) {
                    String o = sourceOrigin == null ? "" : sourceOrigin.toString();
                    String d = message.getData();
                    if (!isMainFrame || !o.startsWith("https://") || d == null || d.length() > 512 * 1024) {
                        try {
                            replyProxy.postMessage("{\"event\":\"_kavi_denied\"}");
                        } catch (Exception ignored) {
                        }
                        return;
                    }
                    if (!o.equals(topOrigin)) {
                        topOrigin = o;
                    }
                    topProxy = replyProxy;
                    onDappMessage(d, o, replyProxy);
                }
            });
            WebViewCompat.addDocumentStartJavaScript(dapp, readAsset("kavi-provider.js"), all);
            bridgeReady = true;
        }

        dapp.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                if (scheme.equals("https") || scheme.equals("http")) return false;
                if (scheme.equals("about") || scheme.equals("data") || scheme.equals("blob") || scheme.equals("javascript")) return false;
                if (scheme.equals("intent") || scheme.equals("file") || scheme.equals("content") || scheme.equals("kaviwallet")) return true;
                if (!request.hasGesture()) return true;
                confirmExternal(u.toString(), scheme);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                String o = originOf(url);
                if (!o.equals(pageOrigin)) {
                    pageOrigin = o;
                    proxies.clear();
                    topProxy = null;
                    topOrigin = null;
                    wallet.evaluateJavascript("window.KaviHost&&KaviHost.onDappNav&&KaviHost.onDappNav(" + JSONObject.quote(o) + ")", null);
                }
                setUrl(url);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                setUrl(url);
                progress.setVisibility(View.GONE);
                if (url != null && url.startsWith("http")) {
                    wallet.evaluateJavascript("window.KaviHost&&KaviHost.onDappUrl(" + JSONObject.quote(url) + ")", null);
                }
            }
        });
        dapp.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.deny();
            }
        });
    }

    private void setUrl(String url) {
        if (url == null) return;
        Uri u = Uri.parse(url);
        String host = u.getHost();
        boolean secure = "https".equals(u.getScheme());
        urlView.setText((secure ? "🔒 " : "⚠ Not secure · ") + (host != null ? host : url));
        urlView.setTextColor(secure ? TEXT : Color.parseColor("#F6465D"));
    }

    private void onDappMessage(String data, String origin, JavaScriptReplyProxy reply) {
        if (data == null) return;
        String id = "n" + (++seq);
        if (proxies.size() > 50) proxies.clear();
        proxies.put(id, reply);
        String js = "window.KaviHost&&KaviHost.onDappRequest(" + JSONObject.quote(id) + "," + JSONObject.quote(data) + "," + JSONObject.quote(origin) + ")";
        wallet.evaluateJavascript(js, null);
    }

    private void openDapp(String url) {
        if (!bridgeReady) {
            Toast.makeText(this, "Please update Android System WebView from the Play Store to use dApps", Toast.LENGTH_LONG).show();
            return;
        }
        proxies.clear();
        topProxy = null;
        topOrigin = null;
        pageOrigin = null;
        dappBox.setVisibility(View.VISIBLE);
        wallet.setVisibility(View.GONE);
        setUrl(url);
        dapp.loadUrl(url);
    }

    private void closeDapp() {
        dapp.stopLoading();
        dapp.loadUrl("about:blank");
        dapp.clearHistory();
        proxies.clear();
        topProxy = null;
        topOrigin = null;
        pageOrigin = null;
        dappBox.setVisibility(View.GONE);
        wallet.setVisibility(View.VISIBLE);
    }

    private void showWalletHome() {
        closeDapp();
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.goHome&&KaviHost.goHome()", null);
    }

    private void confirmExternal(final String url, final String scheme) {
        if (isFinishing() || isDestroyed()) return;
        new android.app.AlertDialog.Builder(this)
                .setTitle("Open another app?")
                .setMessage("This site wants to open a \"" + scheme + ":\" link in another app. Only continue if you trust it.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open", (d, w) -> openExternal(url))
                .show();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
        }
    }

    private void copyText(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Kavi Wallet", text));
    }

    private void copySecretText(String text) {
        final ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || text == null) return;
        ClipData clip = ClipData.newPlainText("Kavi Wallet", text);
        android.os.PersistableBundle extras = new android.os.PersistableBundle();
        extras.putBoolean("android.content.extra.IS_SENSITIVE", true);
        clip.getDescription().setExtras(extras);
        cm.setPrimaryClip(clip);
        main.postDelayed(() -> {
            try {
                ClipData cur = cm.getPrimaryClip();
                if (cur == null || cur.getItemCount() == 0 || text.contentEquals(cur.getItemAt(0).coerceToText(MainActivity.this))) {
                    if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip();
                    else cm.setPrimaryClip(ClipData.newPlainText("", ""));
                }
            } catch (Exception ignored) {
            }
        }, 60000);
    }

    private void shareText(String text, String title) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        if (title != null) i.putExtra(Intent.EXTRA_SUBJECT, title);
        try {
            startActivity(Intent.createChooser(i, title == null ? "Share" : title));
        } catch (Exception ignored) {
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            return new String(readAll(in, MAX_BODY), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > max) throw new IOException("Response too large");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private void jsCall(final String js) {
        main.post(() -> {
            if (wallet != null) wallet.evaluateJavascript(js, null);
        });
    }

    private void doHttp(final String id, final String method, final String url, final String body) {
        http.execute(() -> {
            int status = 0;
            String text;
            HttpURLConnection c = null;
            try {
                URL u = new URL(url);
                String proto = u.getProtocol();
                if (!"https".equals(proto)) {
                    throw new IOException("Only https is allowed");
                }
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("User-Agent", "KaviWallet/2.0 Android");
                String hst = u.getHost() == null ? "" : u.getHost().toLowerCase(java.util.Locale.ROOT);
                if (hst.equals("kyberswap.com") || hst.endsWith(".kyberswap.com")) c.setRequestProperty("X-Client-Id", "KaviWallet");
                boolean post = "POST".equalsIgnoreCase(method);
                c.setRequestMethod(post ? "POST" : "GET");
                if (post) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    byte[] b = (body == null ? "" : body).getBytes(StandardCharsets.UTF_8);
                    c.setFixedLengthStreamingMode(b.length);
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(b);
                    }
                }
                status = c.getResponseCode();
                InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                text = in == null ? "" : new String(readAll(in, MAX_BODY), StandardCharsets.UTF_8);
            } catch (Exception e) {
                status = 0;
                text = e.getMessage() == null ? "Network error" : e.getMessage();
            } finally {
                if (c != null) c.disconnect();
            }
            jsCall("window.KaviHost&&KaviHost.onHttp(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(text) + ")");
        });
    }

    private void bioResult(boolean ok, String pw, String error, boolean invalidated) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (pw != null) o.put("pw", pw);
            if (error != null) o.put("error", error);
            if (invalidated) o.put("invalidated", true);
            jsCall("window.KaviHost&&KaviHost.onBio(" + JSONObject.quote(o.toString()) + ")");
        } catch (Exception ignored) {
        }
    }

    private String bioStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return "unavailable";
        boolean can;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager bm = getSystemService(BiometricManager.class);
            can = bm != null && bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            BiometricManager bm = getSystemService(BiometricManager.class);
            can = bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        } else {
            KeyguardManager km = getSystemService(KeyguardManager.class);
            can = km != null && km.isDeviceSecure() && getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
        }
        if (!can) return "unavailable";
        return getSharedPreferences(BIO_PREFS, MODE_PRIVATE).contains("ct") ? "enabled" : "available";
    }

    private SecretKey bioKey(boolean create) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(BIO_KEY)) return (SecretKey) ks.getKey(BIO_KEY, null);
        if (!create) return null;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(BIO_KEY, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        }
        kg.init(b.build());
        return kg.generateKey();
    }

    private void bioDisable() {
        getSharedPreferences(BIO_PREFS, MODE_PRIVATE).edit().clear().apply();
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(BIO_KEY)) ks.deleteEntry(BIO_KEY);
        } catch (Exception ignored) {
        }
    }

    private void bioPrompt(String subtitle, Cipher cipher, BiometricPrompt.AuthenticationCallback cb) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            bioResult(false, null, "Fingerprint needs Android 9 or newer", false);
            return;
        }
        BiometricPrompt p = new BiometricPrompt.Builder(this)
                .setTitle("Kavi Wallet")
                .setSubtitle(subtitle)
                .setNegativeButton("Use password", getMainExecutor(), (d, w) -> bioResult(false, null, "cancelled", false))
                .build();
        bioCancel = new CancellationSignal();
        p.authenticate(new BiometricPrompt.CryptoObject(cipher), bioCancel, getMainExecutor(), cb);
    }

    private void bioEnable(final String pw) {
        if (!"available".equals(bioStatus()) && !"enabled".equals(bioStatus())) {
            bioResult(false, null, "Fingerprint is not set up on this phone", false);
            return;
        }
        try {
            bioDisable();
            SecretKey key = bioKey(true);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key);
            bioPrompt("Confirm fingerprint to turn on", c, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher ci = result.getCryptoObject().getCipher();
                        byte[] ct = ci.doFinal(pw.getBytes(StandardCharsets.UTF_8));
                        getSharedPreferences(BIO_PREFS, MODE_PRIVATE).edit()
                                .putString("iv", Base64.encodeToString(ci.getIV(), Base64.NO_WRAP))
                                .putString("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
                                .apply();
                        bioResult(true, null, null, false);
                    } catch (Exception e) {
                        bioResult(false, null, "Could not save fingerprint unlock", false);
                    }
                }

                @Override
                public void onAuthenticationError(int code, CharSequence msg) {
                    bioResult(false, null, code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED ? "cancelled" : String.valueOf(msg), false);
                }
            });
        } catch (Exception e) {
            bioResult(false, null, "Fingerprint unlock is not available", false);
        }
    }

    private void bioUnlock() {
        SharedPreferences sp = getSharedPreferences(BIO_PREFS, MODE_PRIVATE);
        String ivS = sp.getString("iv", null);
        final String ctS = sp.getString("ct", null);
        if (ivS == null || ctS == null) {
            bioResult(false, null, "Fingerprint unlock is off", false);
            return;
        }
        try {
            SecretKey key = bioKey(false);
            if (key == null) throw new KeyPermanentlyInvalidatedException();
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, Base64.decode(ivS, Base64.NO_WRAP)));
            bioPrompt("Unlock with your fingerprint", c, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    try {
                        byte[] pt = result.getCryptoObject().getCipher().doFinal(Base64.decode(ctS, Base64.NO_WRAP));
                        bioResult(true, new String(pt, StandardCharsets.UTF_8), null, false);
                    } catch (Exception e) {
                        bioResult(false, null, "Fingerprint unlock failed. Use your password.", false);
                    }
                }

                @Override
                public void onAuthenticationError(int code, CharSequence msg) {
                    bioResult(false, null, code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED ? "cancelled" : String.valueOf(msg), false);
                }
            });
        } catch (KeyPermanentlyInvalidatedException e) {
            bioDisable();
            bioResult(false, null, null, true);
        } catch (Exception e) {
            bioResult(false, null, "Fingerprint unlock failed. Use your password.", false);
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void openDapp(final String url) {
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
            runOnUiThread(() -> MainActivity.this.openDapp(url));
        }

        @JavascriptInterface
        public void closeDapp() {
            runOnUiThread(MainActivity.this::closeDapp);
        }

        @JavascriptInterface
        public void showWallet() {
            runOnUiThread(() -> wallet.setVisibility(View.VISIBLE));
        }

        @JavascriptInterface
        public void showDapp() {
            runOnUiThread(() -> {
                if (dappBox.getVisibility() == View.VISIBLE) wallet.setVisibility(View.GONE);
            });
        }

        @JavascriptInterface
        public void dappReply(final String id, final String json) {
            runOnUiThread(() -> {
                JavaScriptReplyProxy p = proxies.remove(id);
                if (p != null) {
                    try {
                        p.postMessage(json);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void dappEvent(final String json, final String origin) {
            runOnUiThread(() -> {
                if (topProxy != null && origin != null && origin.equals(topOrigin)) {
                    try {
                        topProxy.postMessage(json);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            if (url == null || !url.startsWith("https://")) return;
            runOnUiThread(() -> MainActivity.this.openExternal(url));
        }

        @JavascriptInterface
        public void copySecret(final String text) {
            runOnUiThread(() -> copySecretText(text));
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> copyText(text));
        }

        @JavascriptInterface
        public void share(final String text, final String title) {
            runOnUiThread(() -> shareText(text, title));
        }

        @JavascriptInterface
        public void httpRequest(final String id, final String method, final String url, final String body) {
            doHttp(id, method, url, body);
        }

        @JavascriptInterface
        public String appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String bioStatus() {
            return MainActivity.this.bioStatus();
        }

        @JavascriptInterface
        public void bioEnable(final String pw) {
            runOnUiThread(() -> MainActivity.this.bioEnable(pw));
        }

        @JavascriptInterface
        public void bioUnlock() {
            runOnUiThread(MainActivity.this::bioUnlock);
        }

        @JavascriptInterface
        public void bioDisable() {
            MainActivity.this.bioDisable();
        }

        @JavascriptInterface
        public void setSecure(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            });
        }

        @JavascriptInterface
        public void notify(final String title, final String body, final String id) {
            NotifHelper.post(MainActivity.this, title, body, id == null ? (int) System.currentTimeMillis() : id.hashCode());
        }

        @JavascriptInterface
        public String notifStatus() {
            return NotifHelper.status(MainActivity.this);
        }

        @JavascriptInterface
        public String notifPermission() {
            return MainActivity.this.requestNotifPermission();
        }

        @JavascriptInterface
        public void bgSync(final String json) {
            MainActivity.this.bgSync(json);
        }

        @JavascriptInterface
        public String bgPull() {
            return MainActivity.this.bgPull();
        }

        @JavascriptInterface
        public boolean sysDark() {
            return MainActivity.this.systemDark();
        }

        @JavascriptInterface
        public void setTheme(final boolean dark) {
            runOnUiThread(() -> applyTheme(dark));
        }

        @JavascriptInterface
        public String signingKey() {
            return MainActivity.this.signingKeySha();
        }

        @JavascriptInterface
        public String takeAction() {
            return MainActivity.this.takeAction();
        }

        @JavascriptInterface
        public void widgetSync(final String json) {
            KaviWidgets.save(getApplicationContext(), json);
        }

        @JavascriptInterface
        public int widgetCount() {
            return KaviWidgets.count(getApplicationContext());
        }

        @JavascriptInterface
        public String widgetPin(final String kind) {
            return MainActivity.this.pinWidget(kind);
        }
    }

    private String requestNotifPermission() {
        String st = NotifHelper.status(this);
        if ("ask".equals(st)) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF));
            return "asked";
        }
        if ("denied".equals(st)) {
            openNotifSettings();
            return "settings";
        }
        return "granted";
    }

    private void openNotifSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
        }
    }

    private synchronized void bgSync(String json) {
        try {
            JSONObject cfg = new JSONObject(json);
            SharedPreferences sp = getSharedPreferences(KaviWorker.PREFS, MODE_PRIVATE);
            JSONObject snap = new JSONObject(sp.getString("snap", "{}"));
            JSONObject in = cfg.optJSONObject("snap");
            if (in != null) {
                Iterator<String> it = in.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject v = in.optJSONObject(k);
                    JSONObject old = snap.optJSONObject(k);
                    if (v != null && (old == null || v.optLong("ts") >= old.optLong("ts"))) snap.put(k, v);
                }
            }
            cfg.remove("snap");
            sp.edit().putString("cfg", cfg.toString()).putString("snap", snap.toString()).apply();
            JSONObject prefs = cfg.optJSONObject("prefs");
            boolean bg = prefs == null || prefs.optBoolean("bg", true);
            WorkManager wm = WorkManager.getInstance(getApplicationContext());
            if (bg) {
                Constraints c = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
                PeriodicWorkRequest r = new PeriodicWorkRequest.Builder(KaviWorker.class, 15, TimeUnit.MINUTES).setConstraints(c).build();
                wm.enqueueUniquePeriodicWork("kavi_bg", ExistingPeriodicWorkPolicy.KEEP, r);
            } else {
                wm.cancelUniqueWork("kavi_bg");
            }
        } catch (Exception ignored) {
        }
    }

    private synchronized String bgPull() {
        try {
            SharedPreferences sp = getSharedPreferences(KaviWorker.PREFS, MODE_PRIVATE);
            JSONObject o = new JSONObject();
            o.put("events", new JSONArray(sp.getString("events", "[]")));
            o.put("snap", new JSONObject(sp.getString("snap", "{}")));
            String jp = sp.getString("jp", null);
            if (jp != null) o.put("jp", new JSONObject(jp));
            sp.edit().putString("events", "[]").remove("jp").apply();
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            if (!(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) && Build.VERSION.SDK_INT >= 33
                    && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                openNotifSettings();
            }
            jsCall("window.KaviHost&&KaviHost.onNotifPerm&&KaviHost.onNotifPerm()");
            return;
        }
        if (requestCode == REQ_CAMERA && pendingPermission != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingPermission.deny();
            }
            pendingPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (dappBox.getVisibility() == View.VISIBLE && wallet.getVisibility() != View.VISIBLE) {
            if (dapp.canGoBack()) dapp.goBack();
            else closeDapp();
            return;
        }
        wallet.evaluateJavascript("window.KaviHost?KaviHost.onBack():false", value -> {
            if (!"true".equals(value)) {
                if (dappBox.getVisibility() == View.VISIBLE) closeDapp();
                else moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        foreground = false;
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.onPause()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        wallet.evaluateJavascript("window.KaviHost&&KaviHost.onResume()", null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        wallet.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (bioCancel != null) bioCancel.cancel();
        http.shutdownNow();
        if (dapp != null) dapp.destroy();
        if (wallet != null) wallet.destroy();
        super.onDestroy();
    }
}
