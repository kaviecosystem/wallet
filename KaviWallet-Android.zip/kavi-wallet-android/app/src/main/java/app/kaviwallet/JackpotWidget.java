package app.kaviwallet;

public class JackpotWidget extends KaviWidgetProvider {
}
