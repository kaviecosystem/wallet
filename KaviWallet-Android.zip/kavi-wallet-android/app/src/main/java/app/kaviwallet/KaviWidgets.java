package app.kaviwallet;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public final class KaviWidgets {
    static final String PREFS = "kavi_widget";
    static final String ACTION_REFRESH = "app.kaviwallet.WIDGET_REFRESH";
    static final String ACTION_TICK = "app.kaviwallet.WIDGET_TICK";
    private static final String ZERO = "0x0000000000000000000000000000000000000000";
    private static final int C_OK = Color.parseColor("#2EBD85");
    private static final int C_ERR = Color.parseColor("#F6465D");

    private KaviWidgets() {
    }

    static SharedPreferences sp(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static JSONObject data(Context ctx) {
        try {
            return new JSONObject(sp(ctx).getString("d", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static synchronized void save(Context ctx, String json) {
        try {
            JSONObject in = new JSONObject(json);
            if (in.optBoolean("clear")) {
                sp(ctx).edit().clear().apply();
            } else {
                in.put("ts", System.currentTimeMillis());
                sp(ctx).edit().putString("d", in.toString()).putBoolean("fail", false).apply();
            }
        } catch (Exception ignored) {
        }
        updateAll(ctx);
    }

    static int[] ids(Context ctx, Class<?> cls) {
        try {
            return AppWidgetManager.getInstance(ctx).getAppWidgetIds(new ComponentName(ctx, cls));
        } catch (Exception e) {
            return new int[0];
        }
    }

    static int count(Context ctx) {
        return ids(ctx, WalletWidget.class).length + ids(ctx, ActionsWidget.class).length + ids(ctx, JackpotWidget.class).length;
    }

    static boolean needsData(Context ctx) {
        return ids(ctx, WalletWidget.class).length + ids(ctx, JackpotWidget.class).length > 0;
    }

    static void updateAll(Context ctx) {
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        JSONObject d = data(ctx);
        try {
            for (int id : ids(ctx, WalletWidget.class)) m.updateAppWidget(id, walletViews(ctx, d));
            for (int id : ids(ctx, ActionsWidget.class)) m.updateAppWidget(id, actionViews(ctx));
            int[] jp = ids(ctx, JackpotWidget.class);
            for (int id : jp) m.updateAppWidget(id, jackpotViews(ctx, d));
            if (jp.length > 0) scheduleTick(ctx, d);
        } catch (Exception ignored) {
        }
    }

    static void requestRefresh(Context ctx) {
        if (!data(ctx).has("address")) {
            updateAll(ctx);
            return;
        }
        sp(ctx).edit().putLong("busy", System.currentTimeMillis()).apply();
        updateAll(ctx);
        Constraints c = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest r = new OneTimeWorkRequest.Builder(WidgetWorker.class).setConstraints(c).build();
        WorkManager.getInstance(ctx.getApplicationContext()).enqueueUniqueWork("kavi_widget", ExistingWorkPolicy.REPLACE, r);
    }

    static void refreshIfStale(Context ctx, long maxAgeMs) {
        JSONObject d = data(ctx);
        if (!d.has("address") || !needsData(ctx)) return;
        if (System.currentTimeMillis() - d.optLong("ts") > maxAgeMs) requestRefresh(ctx);
    }

    static PendingIntent open(Context ctx, String action) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("kaviwallet://" + action), ctx, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(ctx, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent broadcast(Context ctx, Class<?> cls, String action, int code) {
        Intent i = new Intent(ctx, cls).setAction(action);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static boolean busy(Context ctx) {
        return System.currentTimeMillis() - sp(ctx).getLong("busy", 0) < 60000;
    }

    static RemoteViews walletViews(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_wallet);
        v.setOnClickPendingIntent(R.id.w_open, open(ctx, "wallet"));
        v.setOnClickPendingIntent(R.id.w_send, open(ctx, "send"));
        v.setOnClickPendingIntent(R.id.w_receive, open(ctx, "receive"));
        v.setOnClickPendingIntent(R.id.w_scan, open(ctx, "scan"));
        v.setOnClickPendingIntent(R.id.w_swap, open(ctx, "swap"));
        v.setOnClickPendingIntent(R.id.w_refresh, broadcast(ctx, WalletWidget.class, ACTION_REFRESH, 1));
        String addr = d.optString("address", "");
        if (addr.isEmpty()) {
            v.setTextViewText(R.id.w_name, "Kavi Wallet");
            v.setTextViewText(R.id.w_total, "Open Kavi Wallet");
            v.setTextViewTextSize(R.id.w_total, TypedValue.COMPLEX_UNIT_SP, 18);
            v.setTextViewText(R.id.w_sub, "Tap to set up your wallet");
            return v;
        }
        v.setTextViewText(R.id.w_name, d.optString("name", "Wallet"));
        String total;
        if (d.optBoolean("hide")) {
            total = "••••••";
        } else {
            double[] t = totalUsd(d);
            if (t[1] > 0) total = money(t[0] * d.optDouble("rate", 1), d.optString("cur", "USD"), false);
            else total = amount(d.optJSONObject("bal") == null ? "0" : d.optJSONObject("bal").optString("", "0"), 18) + " " + d.optString("sym", "BNB");
        }
        v.setTextViewText(R.id.w_total, total);
        v.setTextViewTextSize(R.id.w_total, TypedValue.COMPLEX_UNIT_SP, total.length() > 14 ? 20 : 24);
        v.setTextViewText(R.id.w_sub, sub(ctx, d) + " · " + shortAddr(addr));
        return v;
    }

    private static String sub(Context ctx, JSONObject d) {
        if (busy(ctx)) return "Updating…";
        String time = DateFormat.getTimeFormat(ctx).format(new Date(d.optLong("ts", System.currentTimeMillis())));
        return (sp(ctx).getBoolean("fail", false) ? "Offline · " : "Updated ") + time;
    }

    static RemoteViews actionViews(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_actions);
        v.setOnClickPendingIntent(R.id.a_scan, open(ctx, "scan"));
        v.setOnClickPendingIntent(R.id.a_send, open(ctx, "send"));
        v.setOnClickPendingIntent(R.id.a_receive, open(ctx, "receive"));
        v.setOnClickPendingIntent(R.id.a_swap, open(ctx, "swap"));
        v.setOnClickPendingIntent(R.id.a_discover, open(ctx, "discover"));
        return v;
    }

    static RemoteViews jackpotViews(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_jackpot);
        v.setOnClickPendingIntent(R.id.j_root, open(ctx, "jackpot"));
        v.setOnClickPendingIntent(R.id.j_refresh, broadcast(ctx, JackpotWidget.class, ACTION_REFRESH, 2));
        String ks = d.optString("kaviSym", "KAVI");
        int kd = d.optInt("kaviDec", 18);
        v.setTextViewText(R.id.j_sym, ks);
        JSONObject r = d.optJSONObject("round");
        v.setViewVisibility(R.id.j_timer, View.GONE);
        if (r == null) {
            v.setTextViewText(R.id.j_title, ks + " Jackpot");
            v.setTextViewText(R.id.j_pot, "—");
            v.setTextViewText(R.id.j_state, "Open Kavi Wallet to load the jackpot");
        } else {
            v.setTextViewText(R.id.j_title, ks + " Jackpot · Round " + r.optString("no", "?"));
            v.setTextViewText(R.id.j_pot, amount(r.optString("pot", "0"), kd) + " " + ks);
            String lead = r.optString("lead", ZERO).toLowerCase(Locale.ROOT);
            long end = r.optLong("end") * 1000L;
            long now = System.currentTimeMillis();
            boolean me = lead.equalsIgnoreCase(d.optString("address", "-"));
            String state;
            if (lead.equals(ZERO)) {
                state = "Waiting for first transaction";
            } else if (end <= now) {
                state = me ? "You won! Tap to settle" : "Round over · tap to settle";
            } else {
                v.setViewVisibility(R.id.j_timer, View.VISIBLE);
                v.setChronometer(R.id.j_timer, SystemClock.elapsedRealtime() + (end - now), null, true);
                v.setChronometerCountDown(R.id.j_timer, true);
                state = me ? "You are leading 🏆" : "Leader " + shortAddr(lead);
            }
            if (busy(ctx)) state = "Updating…";
            v.setTextViewText(R.id.j_state, state);
        }
        String kavi = d.optString("kavi", "").toLowerCase(Locale.ROOT);
        JSONObject prices = d.optJSONObject("prices");
        double p = prices == null ? Double.NaN : prices.optDouble(kavi, Double.NaN);
        v.setTextViewText(R.id.j_price, Double.isNaN(p) ? "—" : money(p * d.optDouble("rate", 1), d.optString("cur", "USD"), true));
        JSONObject chg = d.optJSONObject("chg");
        double c = chg == null ? Double.NaN : chg.optDouble(kavi, Double.NaN);
        if (Double.isNaN(c)) {
            v.setTextViewText(R.id.j_chg, "");
        } else {
            v.setTextViewText(R.id.j_chg, (c >= 0 ? "+" : "") + String.format(Locale.US, "%.2f%%", c));
            v.setTextColor(R.id.j_chg, c >= 0 ? C_OK : C_ERR);
        }
        return v;
    }

    private static void scheduleTick(Context ctx, JSONObject d) {
        JSONObject r = d.optJSONObject("round");
        if (r == null) return;
        long end = r.optLong("end") * 1000L;
        if (end <= System.currentTimeMillis() || ZERO.equalsIgnoreCase(r.optString("lead", ZERO))) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.set(AlarmManager.RTC, end + 1500, broadcast(ctx, JackpotWidget.class, ACTION_TICK, 3));
    }

    static double[] totalUsd(JSONObject d) {
        double total = 0;
        int known = 0;
        JSONObject bal = d.optJSONObject("bal");
        JSONObject prices = d.optJSONObject("prices");
        if (bal == null || prices == null) return new double[]{0, 0};
        JSONArray tokens = d.optJSONArray("tokens");
        Iterator<String> it = bal.keys();
        while (it.hasNext()) {
            String k = it.next();
            int dec = 18;
            String pk = k.isEmpty() ? d.optString("wbnb", "").toLowerCase(Locale.ROOT) : k;
            if (!k.isEmpty() && tokens != null) {
                for (int i = 0; i < tokens.length(); i++) {
                    JSONObject t = tokens.optJSONObject(i);
                    if (t != null && t.optString("a").equalsIgnoreCase(k)) dec = t.optInt("d", 18);
                }
            }
            double p = prices.optDouble(pk, Double.NaN);
            if (Double.isNaN(p)) continue;
            try {
                total += new BigDecimal(new BigInteger(bal.optString(k, "0"))).movePointLeft(dec).doubleValue() * p;
                known++;
            } catch (Exception ignored) {
            }
        }
        return new double[]{total, known};
    }

    static String money(double x, String code, boolean price) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
        int digits = 2;
        try {
            Currency c = Currency.getInstance(code);
            nf.setCurrency(c);
            digits = Math.max(0, c.getDefaultFractionDigits());
        } catch (Exception ignored) {
        }
        double abs = Math.abs(x);
        if (abs > 0 && abs < (price ? 1 : 0.01)) {
            int need = (int) Math.ceil(-Math.log10(abs)) + (price ? 3 : 1);
            nf.setMinimumFractionDigits(Math.min(digits, need));
            nf.setMaximumFractionDigits(Math.max(digits, need));
        } else if (price && abs < 1000 && digits > 0) {
            nf.setMinimumFractionDigits(digits);
            nf.setMaximumFractionDigits(Math.max(digits, 4));
        } else {
            nf.setMinimumFractionDigits(digits);
            nf.setMaximumFractionDigits(digits);
        }
        return nf.format(x).replaceFirst("^([A-Za-z]{2,})(\\d)", "$1 $2");
    }

    static String amount(String wei, int dec) {
        try {
            BigDecimal b = new BigDecimal(new BigInteger(wei)).movePointLeft(dec);
            DecimalFormat f = b.compareTo(BigDecimal.ONE) >= 0 ? new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US)) : new DecimalFormat("0.######", DecimalFormatSymbols.getInstance(Locale.US));
            f.setRoundingMode(RoundingMode.DOWN);
            return f.format(b);
        } catch (Exception e) {
            return "0";
        }
    }

    static String shortAddr(String a) {
        return a.length() < 12 ? a : a.substring(0, 6) + "…" + a.substring(a.length() - 4);
    }

    static boolean refreshNow(Context ctx) {
        JSONObject d = data(ctx);
        String addr = d.optString("address", "");
        JSONArray rpcs = d.optJSONArray("rpcs");
        if (addr.isEmpty() || rpcs == null || rpcs.length() == 0) return false;
        boolean ok = true;
        try {
            JSONObject bal = d.optJSONObject("bal");
            if (bal == null) bal = new JSONObject();
            bal.put("", hexToDec(rpc(rpcs, "eth_getBalance", new JSONArray().put(addr).put("latest"))));
            JSONArray tokens = d.optJSONArray("tokens");
            List<String> want = new ArrayList<>();
            String wbnb = d.optString("wbnb", "").toLowerCase(Locale.ROOT);
            if (!wbnb.isEmpty()) want.add(wbnb);
            if (tokens != null) {
                for (int i = 0; i < tokens.length(); i++) {
                    String ta = tokens.getJSONObject(i).getString("a").toLowerCase(Locale.ROOT);
                    if (!want.contains(ta)) want.add(ta);
                    try {
                        bal.put(ta, hexToDec(call(rpcs, ta, "0x70a08231" + pad(addr))));
                    } catch (Exception ignored) {
                    }
                }
            }
            d.put("bal", bal);
            String hub = d.optString("hub", "");
            if (!hub.isEmpty()) {
                try {
                    String h = call(rpcs, hub, "0xcace12e6");
                    h = h.startsWith("0x") ? h.substring(2) : h;
                    if (h.length() >= 256) {
                        JSONObject r = new JSONObject();
                        r.put("no", new BigInteger(h.substring(0, 64), 16).toString());
                        r.put("pot", new BigInteger(h.substring(64, 128), 16).toString());
                        r.put("lead", "0x" + h.substring(152, 192).toLowerCase(Locale.ROOT));
                        r.put("end", new BigInteger(h.substring(192, 256), 16).longValue());
                        d.put("round", r);
                    }
                } catch (Exception ignored) {
                }
            }
            String gecko = d.optString("gecko", "");
            if (!gecko.isEmpty() && !want.isEmpty()) {
                try {
                    String url = "https://api.geckoterminal.com/api/v2/simple/networks/" + gecko + "/token_price/" + String.join(",", want.subList(0, Math.min(30, want.size()))) + "?include_24hr_price_change=true";
                    JSONObject a = new JSONObject(http("GET", url, null)).getJSONObject("data").getJSONObject("attributes");
                    JSONObject tp = a.optJSONObject("token_prices");
                    JSONObject ch = a.optJSONObject("h24_price_change_percentage");
                    JSONObject prices = d.optJSONObject("prices");
                    if (prices == null) prices = new JSONObject();
                    JSONObject chg = d.optJSONObject("chg");
                    if (chg == null) chg = new JSONObject();
                    if (tp != null) {
                        Iterator<String> it = tp.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            String s = tp.optString(k, null);
                            if (s != null && !s.equals("null")) prices.put(k.toLowerCase(Locale.ROOT), Double.parseDouble(s));
                        }
                    }
                    if (ch != null) {
                        Iterator<String> it = ch.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            String s = ch.optString(k, null);
                            if (s != null && !s.equals("null")) chg.put(k.toLowerCase(Locale.ROOT), Double.parseDouble(s));
                        }
                    }
                    d.put("prices", prices);
                    d.put("chg", chg);
                } catch (Exception ignored) {
                }
            }
            d.put("ts", System.currentTimeMillis());
        } catch (Exception e) {
            ok = false;
        }
        synchronized (KaviWidgets.class) {
            JSONObject cur = data(ctx);
            if (addr.equalsIgnoreCase(cur.optString("address", "")) && cur.optLong("ts") <= d.optLong("ts")) {
                if (ok) {
                    try {
                        d.put("name", cur.optString("name", d.optString("name")));
                        d.put("hide", cur.optBoolean("hide"));
                        d.put("cur", cur.optString("cur", "USD"));
                        d.put("rate", cur.optDouble("rate", 1));
                    } catch (Exception ignored) {
                    }
                    sp(ctx).edit().putString("d", d.toString()).putBoolean("fail", false).apply();
                } else {
                    sp(ctx).edit().putBoolean("fail", true).apply();
                }
            }
            sp(ctx).edit().remove("busy").apply();
        }
        updateAll(ctx);
        return ok;
    }

    private static String pad(String a) {
        String h = a.startsWith("0x") ? a.substring(2) : a;
        StringBuilder sb = new StringBuilder();
        for (int i = h.length(); i < 64; i++) sb.append('0');
        return sb.append(h.toLowerCase(Locale.ROOT)).toString();
    }

    private static String hexToDec(String hex) {
        String h = hex.startsWith("0x") ? hex.substring(2) : hex;
        return h.isEmpty() ? "0" : new BigInteger(h, 16).toString();
    }

    private static String call(JSONArray rpcs, String to, String data) throws Exception {
        return rpc(rpcs, "eth_call", new JSONArray().put(new JSONObject().put("to", to).put("data", data)).put("latest"));
    }

    private static String rpc(JSONArray rpcs, String method, JSONArray params) throws Exception {
        String body = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", method).put("params", params).toString();
        Exception last = null;
        for (int i = 0; i < rpcs.length(); i++) {
            try {
                JSONObject r = new JSONObject(http("POST", rpcs.getString(i), body));
                if (r.has("error")) throw new Exception(r.getJSONObject("error").optString("message"));
                return r.getString("result");
            } catch (Exception e) {
                last = e;
            }
        }
        throw last == null ? new Exception("No RPC") : last;
    }

    private static String http(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "KaviWallet Android");
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(b.length);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(b);
                }
            }
            int st = c.getResponseCode();
            if (st < 200 || st >= 300) throw new Exception("HTTP " + st);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 1024 * 1024) throw new Exception("Too large");
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            c.disconnect();
        }
    }
}
