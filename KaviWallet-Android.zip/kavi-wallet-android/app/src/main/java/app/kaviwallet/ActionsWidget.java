package app.kaviwallet;

public class ActionsWidget extends KaviWidgetProvider {
}
