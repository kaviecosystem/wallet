package app.kaviwallet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class WidgetActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (KaviWidgets.ACTION_REFRESH.equals(a)) {
            KaviWidgets.requestRefresh(ctx);
        } else if (KaviWidgets.ACTION_TICK.equals(a)) {
            KaviWidgets.updateAll(ctx);
            KaviWidgets.refreshIfStale(ctx, 0);
        }
    }
}
