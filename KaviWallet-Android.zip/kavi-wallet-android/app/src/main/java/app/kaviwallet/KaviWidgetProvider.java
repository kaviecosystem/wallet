package app.kaviwallet;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public abstract class KaviWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        KaviWidgets.updateAll(ctx);
        KaviWidgets.refreshIfStale(ctx, 10 * 60 * 1000L);
    }
}
