package app.kaviwallet;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

public abstract class KaviWidgetProvider extends AppWidgetProvider {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (KaviWidgets.ACTION_REFRESH.equals(a)) {
            KaviWidgets.requestRefresh(ctx);
            return;
        }
        if (KaviWidgets.ACTION_TICK.equals(a)) {
            KaviWidgets.updateAll(ctx);
            KaviWidgets.refreshIfStale(ctx, 0);
            return;
        }
        super.onReceive(ctx, intent);
    }

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        KaviWidgets.updateAll(ctx);
        KaviWidgets.refreshIfStale(ctx, 10 * 60 * 1000L);
    }
}
