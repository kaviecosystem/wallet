package app.kaviwallet;

public class WalletWidget extends KaviWidgetProvider {
}
