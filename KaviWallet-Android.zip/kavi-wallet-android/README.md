# Kavi Wallet (Android) v2.1

A self-custody wallet for BNB Chain with a built-in dApp browser. Every site opened in Discover connects to Kavi Wallet, and every transaction includes the $0.001 KAVI fee that feeds the hourly jackpot.

## Build the APK with GitHub

1. Upload this project (or just the zip file) to a GitHub repository, together with `.github/workflows/build.yml`.
2. Open the **Actions** tab. The "Build Kavi Wallet APK" workflow runs automatically (or press **Run workflow**).
3. When it finishes, download **KaviWallet-apk** under Artifacts and install `app-debug.apk`.

## Features

- Multiple wallets: create, import recovery phrase, import private key, watch-only; rename, switch, remove
- Backup: show recovery phrase, export private key, export keystore file
- Security: password vault (AES-GCM, PBKDF2 600k), fingerprint unlock, auto-lock, screenshot blocking, change password
- Send (with address book and recent recipients), receive with amount QR, QR scanner (camera or photo)
- Swap on PancakeSwap with best route, slippage, and network-fee speed (slow / standard / fast / custom)
- History with pending tracking, speed up and cancel; full on-chain history with an Etherscan API key
- Batch send, token approvals manager with revoke, token check, sign / verify message
- NFTs (ERC-721 and ERC-1155): add, view, send
- Market tab with prices and 24h change, token pages with price charts
- Currency USD / INR, hide balances, hide small balances, RPC node selection
- Discover: Kavi Ecosystem, favorites, recent, connected sites; dApp menu (refresh, copy, share, open in browser, favorite, disconnect)
- KAVI jackpot: live timer, pot, settle and claim
- Notifications: transaction updates, incoming transfers, jackpot (overtaken / won / ending soon), price alerts; notification center with badge; background checks about every 15 minutes when the app is closed

## Where things are

- `app/src/main/assets/www/` — the wallet app (`index.html`, `wallet.js`)
- `app/src/main/assets/kavi-provider.js` — the connection injected into every dApp
- `app/src/main/java/app/kaviwallet/MainActivity.java` — Android shell, dApp browser, fingerprint, camera, network
- KaviHub address and dApp list: top of `wallet.js` (`NETS`, `DAPPS`)
