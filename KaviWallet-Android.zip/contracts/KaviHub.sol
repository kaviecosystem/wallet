// SPDX-License-Identifier: MIT
pragma solidity 0.8.34;

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function approve(address spender, uint256 value) external returns (bool);
}

interface IERC20Decimals {
    function decimals() external view returns (uint8);
}

interface ITranceProtocol {
    function kavi() external view returns (IERC20);
    function pair() external view returns (address);
    function quoteToken() external view returns (address);
    function kaviIsToken0() external view returns (bool);
    function donate(uint256 amount) external;
}

interface IPancakePairLite {
    function getReserves() external view returns (uint112, uint112, uint32);
}

library SafeToken {
    error TokenCallFailed(address token);

    function _call(IERC20 token, bytes memory data) private returns (bool) {
        (bool ok, bytes memory ret) = address(token).call(data);
        if (!ok) return false;
        if (ret.length == 0) return address(token).code.length > 0;
        if (ret.length < 32) return false;
        return abi.decode(ret, (uint256)) == 1;
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
        if (!_call(token, abi.encodeCall(IERC20.transferFrom, (from, to, value)))) revert TokenCallFailed(address(token));
    }

    function trySafeTransfer(IERC20 token, address to, uint256 value) internal returns (bool) {
        return _call(token, abi.encodeCall(IERC20.transfer, (to, value)));
    }

    function tryApprove(IERC20 token, address spender, uint256 value) internal returns (bool) {
        if (_call(token, abi.encodeCall(IERC20.approve, (spender, value)))) return true;
        _call(token, abi.encodeCall(IERC20.approve, (spender, 0)));
        return _call(token, abi.encodeCall(IERC20.approve, (spender, value)));
    }
}

contract KaviHub {
    using SafeToken for IERC20;

    error ZeroAddress();
    error NoLiquidity();
    error FeeTooHigh(uint256 fee, uint256 maxFee);
    error RoundNotOver();
    error NothingToClaim();
    error ReentrantCall();

    ITranceProtocol public immutable protocol;
    IERC20 public immutable kavi;
    address public immutable pair;
    bool public immutable kaviIsToken0;
    address public immutable router;
    address public immutable feesWallet;
    uint256 public immutable feeInQuote;

    uint256 public constant ROUND_DURATION = 1 hours;
    uint256 public constant WINNER_BPS = 5000;
    uint256 public constant RESERVE_BPS = 4000;
    uint256 private constant BPS = 10_000;

    uint256 private _status = 1;

    uint256 public round = 1;
    uint256 public pot;
    address public lastPlayer;
    uint256 public roundEnd;

    uint256 public pendingReserve;
    uint256 public pendingFees;
    mapping(address => uint256) public unclaimed;

    event FeePaid(uint256 indexed round, address indexed player, uint256 kaviAmount, uint256 roundEnd);
    event RoundSettled(
        uint256 indexed round,
        address indexed winner,
        uint256 pot,
        uint256 winnerAmount,
        uint256 reserveAmount,
        uint256 feeAmount
    );
    event PayoutDeferred(address indexed to, uint256 amount);
    event Claimed(address indexed to, uint256 amount);

    modifier nonReentrant() {
        if (_status == 2) revert ReentrantCall();
        _status = 2;
        _;
        _status = 1;
    }

    constructor(address _protocol, address _router, address _feesWallet) {
        if (_protocol == address(0) || _router == address(0) || _feesWallet == address(0)) revert ZeroAddress();
        ITranceProtocol p = ITranceProtocol(_protocol);
        protocol = p;
        kavi = p.kavi();
        pair = p.pair();
        kaviIsToken0 = p.kaviIsToken0();
        router = _router;
        feesWallet = _feesWallet;
        feeInQuote = (10 ** uint256(IERC20Decimals(p.quoteToken()).decimals())) / 1000;
    }

    function quoteFee() public view returns (uint256) {
        (uint112 r0, uint112 r1,) = IPancakePairLite(pair).getReserves();
        (uint256 rKavi, uint256 rQuote) = kaviIsToken0 ? (uint256(r0), uint256(r1)) : (uint256(r1), uint256(r0));
        if (rKavi == 0 || rQuote == 0) revert NoLiquidity();
        uint256 fee = (feeInQuote * rKavi + rQuote - 1) / rQuote;
        return fee == 0 ? 1 : fee;
    }

    function payFee(uint256 maxFee) external nonReentrant returns (uint256 paid) {
        if (lastPlayer != address(0) && block.timestamp >= roundEnd) _settle();

        uint256 fee = quoteFee();
        if (fee > maxFee) revert FeeTooHigh(fee, maxFee);

        uint256 balBefore = kavi.balanceOf(address(this));
        kavi.safeTransferFrom(msg.sender, address(this), fee);
        paid = kavi.balanceOf(address(this)) - balBefore;

        pot += paid;
        lastPlayer = msg.sender;
        roundEnd = block.timestamp + ROUND_DURATION;

        emit FeePaid(round, msg.sender, paid, roundEnd);
    }

    function settleRound() external nonReentrant {
        if (lastPlayer == address(0) || block.timestamp < roundEnd) revert RoundNotOver();
        _settle();
    }

    function _settle() private {
        uint256 amount = pot;
        address winner = lastPlayer;
        uint256 r = round;

        pot = 0;
        lastPlayer = address(0);
        roundEnd = 0;
        round = r + 1;

        uint256 winnerAmt = (amount * WINNER_BPS) / BPS;
        uint256 reserveAmt = (amount * RESERVE_BPS) / BPS;
        uint256 feeAmt = amount - winnerAmt - reserveAmt;

        if (winnerAmt != 0 && !kavi.trySafeTransfer(winner, winnerAmt)) {
            unclaimed[winner] += winnerAmt;
            emit PayoutDeferred(winner, winnerAmt);
        }
        pendingReserve += reserveAmt;
        pendingFees += feeAmt;
        _flush();

        emit RoundSettled(r, winner, amount, winnerAmt, reserveAmt, feeAmt);
    }

    function _flush() private {
        uint256 res = pendingReserve;
        if (res != 0 && kavi.tryApprove(address(protocol), res)) {
            try protocol.donate(res) {
                pendingReserve = 0;
            } catch {
                kavi.tryApprove(address(protocol), 0);
            }
        }
        uint256 f = pendingFees;
        if (f != 0 && kavi.trySafeTransfer(feesWallet, f)) pendingFees = 0;
    }

    function flushPending() external nonReentrant {
        _flush();
    }

    function claim() external nonReentrant {
        uint256 amt = unclaimed[msg.sender];
        if (amt == 0) revert NothingToClaim();
        unclaimed[msg.sender] = 0;
        if (!kavi.trySafeTransfer(msg.sender, amt)) revert SafeToken.TokenCallFailed(address(kavi));
        emit Claimed(msg.sender, amt);
    }

    function timeLeft() external view returns (uint256) {
        if (lastPlayer == address(0) || block.timestamp >= roundEnd) return 0;
        return roundEnd - block.timestamp;
    }

    function roundInfo()
        external
        view
        returns (uint256 currentRound, uint256 currentPot, address currentLeader, uint256 endsAt, bool settleable)
    {
        return (round, pot, lastPlayer, roundEnd, lastPlayer != address(0) && block.timestamp >= roundEnd);
    }
}
