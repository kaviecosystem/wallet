// SPDX-License-Identifier: MIT
pragma solidity 0.8.34;

interface IERC20Ref {
    function balanceOf(address) external view returns (uint256);
    function allowance(address, address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
}

contract KaviReferral {
    IERC20Ref public immutable kavi;
    address public immutable hub;
    address public owner;
    address public pendingOwner;

    uint256 public reward;
    uint256 public minKavi;
    uint256 public holdTime;
    uint256 public dailyCap;
    bool public paused;
    bool public requireHubUse;
    address public appSigner;

    uint256 public day;
    uint256 public paidToday;
    uint256 public totalPaid;
    uint256 public totalReferrals;

    mapping(address => address) public referrerOf;
    mapping(address => uint256) public referralCount;
    mapping(address => uint256) public earned;

    struct Pending {
        address referrer;
        uint64 readyAt;
        uint256 need;
    }
    mapping(address => Pending) public pendingOf;
    uint256 public totalPending;

    uint256 private locked = 1;

    event Referred(address indexed referee, address indexed referrer, uint256 reward);
    event RewardSkipped(address indexed referee, address indexed referrer);
    event HoldStarted(address indexed referee, address indexed referrer, uint256 need, uint256 readyAt);
    event SettingsChanged(uint256 reward, uint256 minKavi, uint256 holdTime, uint256 dailyCap, bool paused, bool requireHubUse);
    event Withdrawn(address indexed to, uint256 amount);
    event AppSignerChanged(address signer);
    event OwnershipTransferStarted(address indexed from, address indexed to);
    event OwnershipTransferred(address indexed from, address indexed to);

    error NotOwner();
    error Paused();
    error AlreadyRegistered();
    error BadReferrer();
    error NotWallet();
    error NotReady();
    error NothingPending();
    error NeedMoreKavi();
    error UseKaviWalletFirst();
    error NotFromApp();
    error Reentrant();
    error TransferFailed();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier nonReentrant() {
        if (locked != 1) revert Reentrant();
        locked = 2;
        _;
        locked = 1;
    }

    constructor(address _kavi, address _hub, uint256 _reward) {
        if (_kavi == address(0) || _hub == address(0)) revert BadReferrer();
        kavi = IERC20Ref(_kavi);
        hub = _hub;
        owner = msg.sender;
        reward = _reward;
        requireHubUse = true;
        holdTime = 7 days;
        emit OwnershipTransferred(address(0), msg.sender);
        emit SettingsChanged(_reward, 0, 7 days, 0, false, true);
    }

    /// Step 1: the friend enters a code in the Kavi Wallet app. If a hold time is set,
    /// the friend must keep at least `need` KAVI in the wallet until `readyAt`, then call claim().
    function register(address referrer, bytes calldata sig) external nonReentrant {
        if (paused) revert Paused();
        if (msg.sender != tx.origin || msg.sender.code.length != 0) revert NotWallet();
        if (referrerOf[msg.sender] != address(0) || pendingOf[msg.sender].referrer != address(0)) revert AlreadyRegistered();
        if (
            referrer == address(0) || referrer == msg.sender || referrerOf[referrer] == msg.sender
                || pendingOf[referrer].referrer == msg.sender
        ) revert BadReferrer();
        uint256 need = minKavi;
        if (need != 0 && kavi.balanceOf(msg.sender) < need) revert NeedMoreKavi();
        if (requireHubUse && kavi.allowance(msg.sender, hub) == 0) revert UseKaviWalletFirst();
        if (appSigner != address(0) && _recover(appDigest(msg.sender, referrer), sig) != appSigner) revert NotFromApp();

        uint256 h = holdTime;
        if (h == 0) {
            _complete(msg.sender, referrer);
        } else {
            uint64 readyAt = uint64(block.timestamp + h);
            pendingOf[msg.sender] = Pending(referrer, readyAt, need);
            totalPending += 1;
            emit HoldStarted(msg.sender, referrer, need, readyAt);
        }
    }

    /// Step 2: after the hold time, the friend finishes the referral. The wallet must still hold the KAVI.
    function claim() external nonReentrant {
        Pending memory p = pendingOf[msg.sender];
        if (p.referrer == address(0)) revert NothingPending();
        if (paused) revert Paused();
        if (block.timestamp < p.readyAt) revert NotReady();
        if (p.need != 0 && kavi.balanceOf(msg.sender) < p.need) revert NeedMoreKavi();
        delete pendingOf[msg.sender];
        totalPending -= 1;
        _complete(msg.sender, p.referrer);
    }

    function _complete(address referee, address referrer) private {
        referrerOf[referee] = referrer;
        referralCount[referrer] += 1;
        totalReferrals += 1;

        uint256 r = reward;
        uint256 today = block.timestamp / 1 days;
        if (today != day) {
            day = today;
            paidToday = 0;
        }
        bool capOk = dailyCap == 0 || paidToday + r <= dailyCap;
        if (r != 0 && capOk && kavi.balanceOf(address(this)) >= r) {
            paidToday += r;
            totalPaid += r;
            earned[referrer] += r;
            if (!kavi.transfer(referrer, r)) revert TransferFailed();
            emit Referred(referee, referrer, r);
        } else {
            emit RewardSkipped(referee, referrer);
            emit Referred(referee, referrer, 0);
        }
    }

    function appDigest(address referee, address referrer) public view returns (bytes32) {
        bytes32 h = keccak256(abi.encode("KaviReferral", block.chainid, address(this), referee, referrer));
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", h));
    }

    function _recover(bytes32 digest, bytes calldata sig) private pure returns (address) {
        if (sig.length != 65) return address(0);
        bytes32 r = bytes32(sig[0:32]);
        bytes32 s = bytes32(sig[32:64]);
        uint8 v = uint8(sig[64]);
        if (v < 27) v += 27;
        if (v != 27 && v != 28) return address(0);
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) return address(0);
        return ecrecover(digest, v, r, s);
    }

    function setAppSigner(address signer) external onlyOwner {
        appSigner = signer;
        emit AppSignerChanged(signer);
    }

    function poolBalance() external view returns (uint256) {
        return kavi.balanceOf(address(this));
    }

    function info(address user) external view returns (address referrer, uint256 count, uint256 earnedTotal, uint256 rewardNow, bool isPaused, uint256 pool) {
        return (referrerOf[user], referralCount[user], earned[user], reward, paused, kavi.balanceOf(address(this)));
    }

    function setSettings(uint256 _reward, uint256 _minKavi, uint256 _holdTime, uint256 _dailyCap, bool _paused, bool _requireHubUse) external onlyOwner {
        if (_holdTime > 365 days) revert NotReady();
        reward = _reward;
        minKavi = _minKavi;
        holdTime = _holdTime;
        dailyCap = _dailyCap;
        paused = _paused;
        requireHubUse = _requireHubUse;
        emit SettingsChanged(_reward, _minKavi, _holdTime, _dailyCap, _paused, _requireHubUse);
    }

    function canRegister(address user) external view returns (bool) {
        if (paused || referrerOf[user] != address(0) || pendingOf[user].referrer != address(0) || user.code.length != 0) return false;
        if (minKavi != 0 && kavi.balanceOf(user) < minKavi) return false;
        if (requireHubUse && kavi.allowance(user, hub) == 0) return false;
        return true;
    }

    function withdraw(address to, uint256 amount) external onlyOwner nonReentrant {
        if (to == address(0)) revert BadReferrer();
        if (!kavi.transfer(to, amount)) revert TransferFailed();
        emit Withdrawn(to, amount);
    }

    function transferOwnership(address to) external onlyOwner {
        pendingOwner = to;
        emit OwnershipTransferStarted(owner, to);
    }

    function acceptOwnership() external {
        if (msg.sender != pendingOwner) revert NotOwner();
        emit OwnershipTransferred(owner, msg.sender);
        owner = msg.sender;
        pendingOwner = address(0);
    }
}
