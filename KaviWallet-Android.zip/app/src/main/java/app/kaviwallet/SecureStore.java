package app.kaviwallet;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Keeps the wallet vault (already encrypted with the user's password) inside a second layer of
 * AES-256-GCM encryption whose key lives in the Android Keystore (phone hardware, TEE).
 * The key never leaves the phone, so a copy of the app data cannot be opened anywhere else,
 * and the password cannot be guessed offline on a computer.
 */
final class SecureStore {
    static final String ERR = "!ERR";
    private static final String ALIAS = "kavi_vault_wrap_v1";
    private static final String PREFS = "kavi_secure";
    private static final Set<String> KEYS = new HashSet<>(Arrays.asList("kw_vault", "kw_keystore", "kw_pwfail"));
    private static final Object LOCK = new Object();

    private SecureStore() {
    }

    private static SecretKey key(boolean create) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return (SecretKey) ks.getKey(ALIAS, null);
        if (!create) return null;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build());
        return kg.generateKey();
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Returns "" when nothing is stored, ERR when the data exists but cannot be opened. */
    static String get(Context c, String name) {
        if (name == null || !KEYS.contains(name)) return ERR;
        synchronized (LOCK) {
            String s = sp(c).getString(name, null);
            if (s == null) return "";
            try {
                int i = s.indexOf(':');
                if (i <= 0) return ERR;
                byte[] iv = Base64.decode(s.substring(0, i), Base64.NO_WRAP);
                byte[] ct = Base64.decode(s.substring(i + 1), Base64.NO_WRAP);
                SecretKey k = key(false);
                if (k == null) return ERR;
                Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
                ci.init(Cipher.DECRYPT_MODE, k, new GCMParameterSpec(128, iv));
                ci.updateAAD(name.getBytes(StandardCharsets.UTF_8));
                return new String(ci.doFinal(ct), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return ERR;
            }
        }
    }

    static boolean put(Context c, String name, String value) {
        if (name == null || value == null || !KEYS.contains(name)) return false;
        synchronized (LOCK) {
            try {
                Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
                ci.init(Cipher.ENCRYPT_MODE, key(true));
                ci.updateAAD(name.getBytes(StandardCharsets.UTF_8));
                byte[] ct = ci.doFinal(value.getBytes(StandardCharsets.UTF_8));
                String s = Base64.encodeToString(ci.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
                return sp(c).edit().putString(name, s).commit();
            } catch (Exception e) {
                return false;
            }
        }
    }

    static boolean del(Context c, String name) {
        if (name == null || !KEYS.contains(name)) return false;
        synchronized (LOCK) {
            return sp(c).edit().remove(name).commit();
        }
    }

    static boolean clearAll(Context c) {
        synchronized (LOCK) {
            boolean ok = sp(c).edit().clear().commit();
            try {
                KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                ks.load(null);
                if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
            } catch (Exception ignored) {
            }
            return ok;
        }
    }

    /** "hardware" when the key is inside secure hardware (TEE/StrongBox), "software" otherwise, "" if no key yet. */
    static String level() {
        try {
            SecretKey k = key(false);
            if (k == null) return "";
            javax.crypto.SecretKeyFactory f = javax.crypto.SecretKeyFactory.getInstance(k.getAlgorithm(), "AndroidKeyStore");
            android.security.keystore.KeyInfo info = (android.security.keystore.KeyInfo) f.getKeySpec(k, android.security.keystore.KeyInfo.class);
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                int sl = info.getSecurityLevel();
                return sl == KeyProperties.SECURITY_LEVEL_SOFTWARE ? "software" : "hardware";
            }
            //noinspection deprecation
            return info.isInsideSecureHardware() ? "hardware" : "software";
        } catch (Exception e) {
            return "";
        }
    }
}
