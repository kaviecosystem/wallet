# Kavi Wallet (Android) v3.7

A self-custody wallet for BNB Chain with a built-in dApp browser. Every site opened in Discover connects to Kavi Wallet, and every transaction includes the $0.001 KAVI fee that feeds the hourly jackpot.

## Build the APK with GitHub

1. Upload this project (or just the zip file) to a GitHub repository, together with `.github/workflows/build.yml`.
2. Open the **Actions** tab. The "Build Kavi Wallet APK" workflow runs automatically (or press **Run workflow**).
3. When it finishes, download **KaviWallet-apk** under Artifacts and install `KaviWallet.apk`. It is signed with your permanent key (the 4 `KAVI_` secrets), so new versions install over the old one without uninstalling.

## Features

- Multiple wallets: create, import recovery phrase, import private key, watch-only; rename, switch, remove
- Backup: show recovery phrase, export private key, export keystore file
- Security: password vault (AES-GCM, PBKDF2 600k), fingerprint unlock, auto-lock, recovery phrase / private key / keystore screens are blurred until tapped and cannot be screenshotted (all other screens can), change password
- Send (with address book and recent recipients), receive with amount QR, QR scanner (camera or photo)
- Swap on PancakeSwap with best route, slippage, and network-fee speed (slow / standard / fast / custom)
- History with pending tracking, speed up and cancel; full on-chain history with an Etherscan API key
- Batch send, token approvals manager with revoke, token check, sign / verify message
- NFTs (ERC-721 and ERC-1155): add, view, send
- Market tab with prices and 24h change, token pages with price charts
- 36 currencies (USD, INR, EUR, GBP, JPY, CNY, AED, SAR, and more) with search; hide balances, hide small balances
- Node settings: latency and block height for every node, pick fastest, automatic mode, add / remove custom nodes
- Refresh: pull down on the wallet screen or tap the refresh icon next to the balance
- Discover: Kavi Ecosystem, favorites, recent, connected sites; dApp menu (refresh, copy, share, open in browser, favorite, disconnect)
- KAVI jackpot: live timer, pot, settle and claim
- Appearance: Day, Night or System (follows the phone's dark mode), including the status bar and dApp browser bar
- Home screen widgets: wallet balance (with Send, Receive, Scan, Swap and refresh), quick actions (Scan, Send, Receive, Swap, Discover) and KAVI Jackpot (pot, live countdown, KAVI price). Add them from Me → Home screen widgets or from the home screen's Widgets list. "Show balance on widget" can be turned off
- App shortcuts: long-press the app icon for Scan, Send, Receive and Swap
- Notifications: transaction updates, incoming transfers, jackpot (overtaken / won / ending soon), price alerts; notification center with badge; background checks about every 15 minutes when the app is closed

## Refer a friend (v3.6, app check v3.8, 7-day hold v3.9)

- Me → Refer a friend: each user's code is their wallet address; Share invite sends it to friends
- A friend enters the code when creating/importing a wallet (or later on the same page) and taps Use code; the referrer instantly receives the reward (default 10 KAVI) from the KaviReferral contract
- Admin (the wallet that deployed KaviReferral) sees an Admin section on the same page: reward per referral, minimum KAVI the friend must hold and for how many days, daily cap, pause, add KAVI to the pool, withdraw
- The friend must first make one transaction in Kavi Wallet (it approves the KAVI fee to KaviHub)
- 7-day hold (v3.9): when the friend uses a code the referral starts as "in progress". The friend must have the minimum KAVI then and still have it after the hold time (default 7 days); then the friend taps Finish referral and the referrer is paid. The friend gets a reminder notification when it is ready. Admin can change the minimum KAVI and the number of days (0 days = reward at once). There is no BNB rule any more
- Contract: `contracts/KaviReferral.sol` (constructor: KAVI token address, KaviHub address, reward in wei e.g. 10000000000000000000 for 10 KAVI). After deploying, add the GitHub secret `KAVI_REFERRAL_ADDRESS`
- App check (v3.8): the contract can require a signature from a secret app key that is only inside the Kavi Wallet app, so codes cannot be used from BscScan, MetaMask or other wallets. Add the GitHub secret `KAVI_APP_SIGNER_KEY` (value: 7-KAVI_APP_SIGNER_KEY.txt), rebuild, then as admin tap Refer a friend → Require Kavi Wallet app
- New wallets are named KW (then KW 2, KW 3…); rename any time in Manage wallets

## Kavi Swap aggregator (v3.1)

- Every swap compares prices from PancakeSwap, KyberSwap (100+ DEXs) and OpenOcean, and picks the best automatically (tap another route to choose it)
- Safety: transactions only go to the official KyberSwap / OpenOcean router contracts; the wallet decodes each route and checks tokens, amount, that the output goes to your own address and the minimum received; approvals are exact (never unlimited); gas is capped; if the price drops after you viewed it, the swap stops
- Price impact is shown for the selected route (green under 1%, orange 1–5%, red 5%+). At 15% or more a warning appears and Swap must be tapped twice
- The KAVI fee applies to every swap as usual
- Swap fee: 0.3% of the amount swapped goes to the KaviHub fees wallet (read from the KaviHub contract). Change it in `SWAP_FEE` at the top of the aggregator code in `wallet.js` (`bps:30n` = 0.3%; set `receiver` to pin a different address)

## Token transaction history (v2.7)

- Every coin/token page shows its transactions with All / In / Out tabs
- Without a key: transactions made in Kavi Wallet (sends, swaps, KAVI fees) plus deposits the wallet noticed
- Full history of every token from the blockchain: add a free NodeReal key in Me → Transaction history (nodereal.io → MegaNode → Create API key). Etherscan's API is paid-only for BNB Chain.
- To give every user full history automatically, put your own NodeReal key in `HISTORY_KEYS.nodereal` in `app/src/main/assets/www/wallet.js`

## Transaction confirmation (v2.6)

- Every transaction (send, swap, batch, NFT, revoke, jackpot, speed up / cancel) opens a simple confirmation popup: amount, from, to, network, network fee and KAVI fee
- After Confirm, your password or fingerprint is required (Me → Security → Password for transactions)
- dApp transactions and signatures also ask for password or fingerprint after you approve them
- The recovery phrase is shown clearly when creating a wallet (screenshots stay blocked)

## Security (v2.5 audit)

- dApp requests are strictly validated; code hidden in transaction data, signature requests or token names cannot run (plus a Content-Security-Policy)
- Signatures for another network, disguised Permit signatures, NFT "approve all" and unlimited approvals are blocked or clearly warned
- Only secure (https) sites, main page only; events go only to the connected site
- Pending requests are cancelled on lock, wallet switch, network switch or when the site changes
- Secrets are wiped from the screen after use and on lock; the wallet locks after inactivity even while open
- KAVI fee approval is capped (not unlimited) and the fee is sanity-checked; swaps always use the official PancakeSwap router
- No phone-to-phone transfer or cloud backup of wallet data; overlay (tap-jacking) protection; copied private keys are marked sensitive and cleared after 60 seconds

## Where things are

- `app/src/main/assets/www/` — the wallet app (`index.html`, `wallet.js`)
- `app/src/main/assets/kavi-provider.js` — the connection injected into every dApp
- `app/src/main/java/app/kaviwallet/MainActivity.java` — Android shell, dApp browser, fingerprint, camera, network
- `app/src/main/java/app/kaviwallet/KaviWidgets.java` — home screen widgets (layouts in `res/layout/widget_*.xml`, shortcuts in `res/xml/shortcuts.xml`)
- KaviHub address and dApp list: top of `wallet.js` (`NETS`, `DAPPS`)
